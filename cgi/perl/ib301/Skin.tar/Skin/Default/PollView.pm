package PollView;

use strict;




sub ShowPoll_header {
my $data = shift;
    
return qq~
    <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION" method="post">
    <input type='hidden' name='act' value='Poll'>
    <input type='hidden' name='s' value='$iB::SESSION'>
    <input type='hidden' name='CODE' value='02'>
    <input type='hidden' name='f'    value='$iB::IN{'f'}'>
    <input type='hidden' name='t'    value='$iB::IN{'t'}'>
    <br>
    <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='5' cellspacing='1' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' valign='left' colspan='3' id='titlemedium'>$iPoll::lang->{'poll_s_q'}: <b>$data->{'POLL_TITLE'}</b> :: $iPoll::lang->{'poll_s_total'}:$data->{'TOTAL_VOTES'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='middle' align='left' width='50%'><b>$iPoll::lang->{'poll_s_choices'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='middle' align='left' width='10%'><b>$iPoll::lang->{'poll_s_votes'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='middle' align='left' width='40%'><b>$iPoll::lang->{'poll_s_stats'}</b></td>
~;

}


sub Render_row_results {
my ($votes, $id, $answer, $percentage, $width) = @_;


return qq~
    <tr>
    <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><b>$answer</b></td>
    <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><b>$votes</b></td>
    <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><img src='$iB::INFO->{'IMAGES_URL'}/images/bar_left.gif' border='0' width='4' height='11' align='middle' alt=''><img src='$iB::INFO->{'IMAGES_URL'}/images/bar.gif' border='0' width='$width' height='11' align='middle' alt=''><img src='$iB::INFO->{'IMAGES_URL'}/images/bar_right.gif' border='0' width='4' height='11' align='middle' alt=''>&nbsp;[$percentage%]</td>
    </tr>
~;
}


sub Render_row_form {
    my ($votes, $id, $answer) = @_;


return qq~ 
    <tr>
    <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='3'><INPUT type="radio" name="poll_vote" value="$id">&nbsp;<b>$answer</b></td>
    </tr>
~;
}



sub ShowPoll_footer {
  my $vote_button = shift;

return qq~ 
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='center' colspan='3'>
                $vote_button
                </td></tr></table>
                </td></tr></table>
                </form>
~;
}

1;
