package BoardWords;


sub new {
  my $pkg = shift;
  my $obj = {
   
#+----------------------------------------------------------------------
#| Do Not remove or edit anything above this line!
#| Only Edit the words on the right of the => arrow
#+----------------------------------------------------------------------

total_forums => "Total Forums:",

#+---------
# Added by Infection

calendar                => "View Calendar",
birth_user              => "member is celebrating his/her birthday today",
birth_users             => "members are celebrating their birthday today",
no_birth_users          => "No members are celebrating a birthday today",

#
#+--------

public_forums           => "Public Forums",
protected_forums        => "Protected Forums",
restricted_forums       => "Restricted Forums",

most_online             => "Most users ever online was <#NUM#> on <#DATE#>",

new_posts               => q|New Posts|,
no_new                  => q|No New Posts|,
forum_off               => q|Read Only|,

browser_user_list       => "View Complete List",
cat_name                => q|Forum|,
info                    => q|Information|,
topics                  => q|Topics|,
replies                 => q|Replies|,
last_post_info          => q|Last Post Info|,
forums                  => q|Forums|,
forum_leader            => q|Forum Led by: |,
by                      => q|By|,
in                      => q|In|,
active_users            => q|user(s) active in the past 15 minutes|,
guests                  => q|guests|,
public_members          => q|Public Members and|,
anon_members            => q|Anonymous Members|,
forum_users             => "User(s) active in this forum",

board_stats             => q|Board Statistics|,
newest_member           => q|welcomes our newest member|,
making_total            => q|making a total of|,
registered_mems         => q|registered members|,

total_of                => q|has a total of|,
posts                   => q|posts|,
replies_to              => q|replies to|,

last_post               => q|was the last to post on|,


invite_friend           => q|Invite a friend to this forum|,
invite_txt_a            => q|Do you know someone who you would like to invite to|,
complete_form           => q|? Simply complete the form below!|,

your_name               => q|Your Name|,
email_addy_from         => q|Your Email Address|,
email_addy_to           => q|Your Friends Email Address|,

invite_submit           => q|Go!|,

all_times               => q|All Times|,
forum_icons             => q|Forum Icons|,
forum_icons_txt         => q|The forum markers show which forums have new posts in since your last visit/log in.|,


d_delete_cookies  => "Delete cookies set by this board",
d_post_read       => "Mark all posts as read",

f_none                  => "----",
f_protected             => "Protected Forum",
new_posts               => "View New Posts",














#+----------------------------------------------------------------------
#| Do Not remove or edit anything below this line!
#+----------------------------------------------------------------------
  };

  bless $obj, $pkg;
  return $obj;
}




1;
