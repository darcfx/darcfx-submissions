package ModCPWords;


sub new {
  my $pkg = shift;
  my $obj = {


## Added RC2

s_prune_perpage => "Number of topics to process per refresher page?<br>If there is a lot of information to remove, Ikonboard will add a refresh page to save server resources",
s_refresh       => "Pruning forums: Processed <#NUM#> of <#TOTAL#>, processing next batch...",
s_pstart        => "Pruning forums: Found <#TOTAL#> topics to delete, starting to prune...",
##

title   => "Your Moderators Control Panel",
home    => "Moderators Control Panel Home",
menu_off  => "Menu Off<br>Please select a forum",

menu  => "Options",

display => "Display",

mod_forum_t  => "Choose a forum to moderate",
mod_forum    => "Simply click on one of the forum links below to begin your moderating session",

forum_name  => "Forum Name",
forum_topics => "Topics",
forum_posts  => "Posts",
last_post    => "Last Post",
topic_to_mod => "Topics awaiting approval:",

f_moderate => "Moderating in forum:",

f_moderate_t => "<# FORUM NAME #> has <# POSTS #> posts in <# TOPICS #> topics",
q_topics   => "Number of queued topics:",
q_posts    => "Number of queued posts:",

q_t_n => "There are no topics awaiting approval",
q_p_n => "There are no posts awaiting approval",

define_search  => "Please define your search parameters",
s_topics_cutoff   => "Search for topics posted within the last (x) days<br>Replace (x) with the number of days",
s_posts_cutoff   => "Search for topics posted within the last (x) days<br>Replace (x) with the number of days",
s_sort          => "Sort results in...",
s_topics_asc    => "ascending order (oldest first)",
s_topics_desc    => "descending order (newest first)",
s_limit          => "Maximum number of records to display",

submit_topics   => "Search for topics",
submit_posts    => "Search for posts",

m_moderate  => "Moderate",
m_approve    => "Approve Topics/Posts",
m_prune      => "Prune forum",
m_delete     => "Delete Topics",
m_open       => "Open/Close topics",
m_move       => "Move topics",

m_prefs  => "Preferences",
m_email     => "Email settings",

no_matches  => "Your Search didn't produce any matches",
your_search_r => "Your search results",
ss_topics => "Topics",
ss_posts => "Posts",

tt_details => "Details",
tt_action  => "Action",

ss_topic_title => "Topic Title:",
ss_posted_on   => "Posted on:",

c_approve  => "Approve",
c_delete   => "Delete",
c_leave    => "Leave",

ss_read_more  => "Read the full post",

process_records  => "Process these records",

a_topic_results => "Topic results",
a_topic_deleted => "Topics deleted from the queue:",
a_topic_approved => "Topics approved from the queue:",
a_topic_left     => "Topics left in the queue:",
a_topic_moved    => "Topics moved:",
a_post_results => "Post approval results",
a_post_deleted => "Posts deleted from the queue:",
a_post_approved => "Posts approved from the queue:",
a_post_left     => "Posts left in the queue:",

a_topic_open => "Topics opened/left open:",
a_topic_close => "Topics closed/left closed:",
a_topic_d_left => "Topics left:",
a_topic_d_delete => "Topics deleted:",

search_openclose  => "You are searching for topics to open or close.",
search_delete     => "You are searching for topics to delete",
search_prune      => "You are pruning this forum",
search_move       => "You are searching for topics to move",
prune_forum => "Prune this forum",


s_prune_cutoff => "Please specify (in days) the topic cut off point.<br>For example: Entering '30' will prune all topics that haven't been replied to in 30 days and over", 

prune_confirm => "Topic cut off point (in days):",
prune_confirm_b => "Do you wish to proceed?",
move_topics_from => "Move topics from",

st_open  => 'Open',
st_close => 'Close',
st_move  => 'Move',

st_topic  => "Topic",
st_posts  => "Posts",
st_last   => "Last Post info",
st_by  => "By:",

#+----------------------------------------------------------------------
#| Do Not remove or edit anything below this line!
#+----------------------------------------------------------------------
  };

  bless $obj, $pkg;
  return $obj;
}




1;

__END__
