#################################################################
#
# iDatabase::Admin::SQL
#
# Administration functions for iDatabase.
#
# Author: Matthew Mecham <matt@ikonboard.com>
#
#################################################################
package iDatabase::Admin::SQL;
use strict;

use vars qw/$SQL @ISA/;


BEGIN { 
        if (eval "require DBI") {
            $SQL->{DBI} = 'Yes';
            require DBI;
        }
 }


#-----------------------------------------------
# Our constructor
#-----------------------------------------------

sub new {
    my $pkg = shift;
    my $obj = { '_output' => undef, errors => [], success => 0 };
    bless $obj, $pkg;
    return $obj;
}

#-----------------------------------------------
# Check and create tables.
# 
# 'success'  => 1 or 0
# 'errors'   => [ @errors ]  An array of errors
#-----------------------------------------------


sub install_database {
    my $obj = shift;
    my $IN  = { 'schema_dir' => "/usr/local/mySQL/schema",   # Path to the directory containing the table schema
                'return_err' => "",                          # Boolean, return errors?
                'create_tbl' => "",                          # Boolean, create tables?
                'attr'       => {},                          # DB attributes, such as DB_USER, etc
                @_,
              };

    # We have nothing to do!

    $obj->{success}++;

    return;

    
}







1;
