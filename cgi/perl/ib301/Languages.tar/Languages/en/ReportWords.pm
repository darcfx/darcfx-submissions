package ReportWords;


sub new {
  my $pkg = shift;
  my $obj = {
   
    title  => "Report a post to a moderator",
    in_forum => "Reported in forum",
    in_topic => "Topic Title",
    name     => "Your name",
    email    => "Your email",
    send     => "Send report now",
    message  => "Your message",
    warn     => "This form is for reporting abusive behaviour (spamming, rude posts, etc) ONLY.<br>DO NOT use this form just to contact a moderator - these messages will be ignored!",

    subject  => "Mailer from Ikonboard: Reporting post",

    ibauto   => "Ikonboard Bot",
redirect => "Report sent, returning you to the topic you came from",



  };

  bless $obj, $pkg;
  return $obj;
}




1;