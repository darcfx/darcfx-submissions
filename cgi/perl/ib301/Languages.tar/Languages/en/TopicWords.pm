package TopicWords;


sub new {
  my $pkg = shift;
  my $obj = {
   
#+----------------------------------------------------------------------
#| Do Not remove or edit anything above this line!
#| Only Edit the words on the right of the => arrow
#+----------------------------------------------------------------------

js_del_1 => "Are you sure you want to delete this message?",
js_del_2 => "Ok, no action has been taken",
posted_on => "Posted:",
RECOUNT => "Rebuild Topic",

topic_moved  => "This topic has moved, taking you to the correct forum",

## added for RC 2

snitch_geezer_to_a_copper => "Report this post to a moderator",

## Added for RC 1

topic_page_h     => "Topic",

topic_stats       =>  "<#POSTS#> replies since <#START#>",
topic             =>  "Topic",
ip                =>  "IP",
m_joined          =>  "Joined:",
m_group           =>  "Group:",
m_posts           =>  "Posts:",
member_warn_level => 'Member Warn Level',
adjust_level      => 'Adjust Warn Level',


t_new  => "Next Newest",
t_old  => "Next Oldest",

forum_jump        => 'Forum Jump',

attach_dl         => "Download attachment",
attach_hits       => "Number of downloads",
pic_attach        => "Attached Image",

track_topic       =>  "Track this topic",
forward           =>  "Email this topic",
print             =>  "Print this topic",

start_new_topic   => "Start a new topic",
reply_to_topic    => "Reply to this topic",
start_new_poll    => "Start a new poll",

MOVE_TOPIC        =>  "Move this topic",
DELETE_POST       =>  "Delete Posts",
OPEN_TOPIC        =>  "Open this topic",
DELETE_TOPIC      =>  "Delete this topic",
CLOSE_TOPIC       =>  "Close this topic",
PIN_TOPIC         =>  "Pin this Topic",
UNPIN_TOPIC       =>  "Unpin this Topic",
EDIT_TOPIC        =>  "Edit this Topic",

moderation_ops       =>  "Topic Options",
please_log_in       =>  "You are not logged into this forum.",
single_page_topic   =>  "&nbsp;",
multi_page_topic    =>  "Pages:",

mod_cp  => "Moderators Control Panel",

#+----------------------------------------------------------------------
#| Do Not remove or edit anything below this line!
#+----------------------------------------------------------------------
  };

  bless $obj, $pkg;
  return $obj;
}




1;

__END__
