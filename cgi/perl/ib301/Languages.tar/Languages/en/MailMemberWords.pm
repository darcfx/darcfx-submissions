package MailMemberWords;


sub new {
  my $pkg = shift;
  my $obj = {
   
#+----------------------------------------------------------------------
#| Do Not remove or edit anything above this line!
#| Only Edit the words on the right of the => arrow
#+----------------------------------------------------------------------



member_address_title        => "Members Email Address",
send_email_to               => "Send an email to",
show_address_text           => "You can send this member an email by clicking on the link below. Ikonboard does not show email addresses in the HTML code to prevent email addresses being harvested by 'spam bots'.",
send_header                 => ", please fill in this form fully to send an email to",
subject                     => "Subject",
message                     => "Message",
submit_send                 => "Send Email",
send_title                  => "Email Form",
msg_txt                     => "Note: By using this form, the recipient will be able to view your email address",

email_sent                  => "The email has been sent",
email_sent_txt              => "Thanks, the email has been successfully sent to",












#+----------------------------------------------------------------------
#| Do Not remove or edit anything below this line!
#+----------------------------------------------------------------------
  };

  bless $obj, $pkg;
  return $obj;
}




1;

__END__
