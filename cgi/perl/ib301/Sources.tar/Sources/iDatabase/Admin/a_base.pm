#################################################################
#
# iDatabase::Admin::SQL
#
# Administration functions for iDatabase.
#
# Author: Matthew Mecham <matt@ikonboard.com>
#
# a_base.pm : Base class for admin functions
#
#################################################################
package iDatabase::Admin::a_base;
use strict;

use vars qw/$SQL/;

#-----------------------------------------------
# Our constructor
#-----------------------------------------------

sub new {
    my $pkg = shift;
    my $obj = { '_output' => undef, errors => [], success => 0 };
    bless $obj, $pkg;
    return $obj;
}

#-----------------------------------------------
# Check and create tables.
# 
# 'success'  => 1 or 0
# 'errors'   => [ @errors ]  An array of errors
#-----------------------------------------------


sub install_database {
    my $obj = shift;
    my $IN  = { 'schema_dir' => "/usr/local/mySQL/schema",   # Path to the directory containing the table schema
                'return_err' => "",                          # Boolean, return errors?
                'create_tbl' => "",                          # Boolean, create tables?
                'attr'       => {},                          # DB attributes, such as DB_USER, etc
                @_,
              };

    # Methods go here
    
    return;
    
}







1;
