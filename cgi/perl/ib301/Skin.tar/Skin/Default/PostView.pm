package PostView;
use strict;


my $img_button = $iB::INFO->{'ALLOW_IMAGES'}
                           ? qq[<input type='button' accesskey='p' value=' Image ' onClick='IBCimage()' class='forminput' title="Picture: [Control or Alt] + p">&nbsp;]
                           : '';


my $ibc_flash = $iB::INFO->{'ALLOW_FLASH'}
                           ? qq[<input type='button'accesskey='f' value=' Flash ' onClick='IBCflash("$iB::INFO->{'MAX_W_FLASH'}","$iB::INFO->{'MAX_H_FLASH'}")' class='forminput'  title="FLASH: [Control or Alt] + f">&nbsp;]
                           : '';

#+-------------------------------------------------------------------------------------------------------------
#+-------------------------------------------------------------------------------------------------------------



sub preview  {
    my $data = shift;

return qq~
 
     <table cellpadding='0' cellspacing='1' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='5' cellspacing='1' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'POST_COL_ONE'}' valign='top' align='left'><b>$Post::lang->{'post_preview'}</b><hr noshade size='1' color='$iB::SKIN->{'TABLE_BORDER_COL'}'><span id='postcolor'>$data</span></td>
                </tr>
                </table>
            </td>
        </tr>
    </table>
    <br>
~;
}



sub Upload_field {
    my $data = shift;

return qq~

                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' align='left' colspan='2' id='titlelarge'>$Post::lang->{'upload_title'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left' valign='top'>$Post::lang->{'upload_text'} $data</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='file' size='30' name='FILE_UPLOAD'></td>
                </tr>

~;
}




sub errors  {
    my $data = shift;

return qq~
 
     <table cellpadding='0' cellspacing='1' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='5' cellspacing='1' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'POST_COL_ONE'}' valign='top' align='left' id='highlight'><b>$Post::lang->{'errors_found'}</b></font><hr noshade size='1' color='$iB::SKIN->{'TABLE_BORDER_COL'}'>$data</td>
                </tr>
                </table>
            </td>
        </tr>
    </table>
    <br>
~;

}



sub table_top  {
my $data = shift;

return qq~
  
 
     <table cellpadding='0' cellspacing='1' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='5' cellspacing='1' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' valign='left' colspan='2' id='titlemedium'>$data</td>
                </tr>

~;

}



#+-------------------------------------------------------------------------------------------------------------


sub nameField_unreg  {
my $data = shift;

return qq~

                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='30%'>$Post::lang->{'guest_name'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='70%'><input type='text' size='40' maxlength='40' name='UserName' value='$data' onMouseOver="this.focus()" onFocus="this.select()"></td>
                </tr>

~;
}


#+-------------------------------------------------------------------------------------------------------------

sub nameField_reg {

return qq~

                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='30%'><b>$Post::lang->{'reg_username'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='70%'><b>$iB::MEMBER->{'MEMBER_NAME'}</b></td>
                </tr>

~;
}

#+-------------------------------------------------------------------------------------------------------------


sub topictitle_fields {
my ($data) = @_;

return qq~

                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><b>$Post::lang->{'topic_title'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' size='40' maxlength='50' name='TopicTitle' value='$data->{'TITLE'}' tabindex='1' class='forminput' onMouseOver="this.focus()"></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><b>$Post::lang->{'topic_desc'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' size='40' maxlength='40' name='TopicDesc' value='$data->{'DESC'}' tabindex='2' class='forminput'></td>
                </tr>

~;
}


#+-------------------------------------------------------------------------------------------------------------

sub poll_box {
my $data = shift;

return qq~
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' valign='top'>$Post::lang->{'poll_choices'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'><textarea cols='60' rows='12' wrap='soft' name='PollAnswers' class='textinput'>$data</textarea></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='top'>$Post::lang->{'poll_only'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='checkbox' size='40' value='1' name='allow_disc' class='forminput'></td>
                </tr>
~;
}

#+-------------------------------------------------------------------------------------------------------------

sub postbox_buttons {
my $data = shift;

return qq~
<script language="javascript">
<!--

var MessageMax  = "$Post::lang->{'the_max_length'}";
var Override    = "$Post::lang->{'override'}";

function CheckLength() {
    MessageLength  = document.REPLIER.Post.value.length;
    message  = "";

        if (MessageMax !=0) {
            message = "$Post::lang->{'js_post'}:\\n$Post::lang->{'js_max_length'} " + MessageMax + " $Post::lang->{'js_characters'}.";
        } else {
            message = "";
        }
        alert(message + "\\n$Post::lang->{'js_used'} " + MessageLength + " $Post::lang->{'js_characters'}.");
}

function ValidateForm() {
    
    MessageLength  = document.REPLIER.Post.value.length;
    errors = "";

    if (MessageLength < 2) {
         errors = "$Post::lang->{'js_no_message'}";
    }
    if (MessageMax !=0) {
        if (MessageLength > MessageMax) {
            errors = "Post:\\n$Post::lang->{'js_max_length'} " + MessageMax + " $Post::lang->{'js_characters'}.\\n$Post::lang->{'js_current'}: " + MessageLength;
        }
    }
    if (errors != "" && Override == "") {
        alert(errors);
        return false;
    } else {
        document.REPLIER.submit.disabled = true;
        return true;
    }
}

function emoticon(theSmilie) {
    document.REPLIER.Post.value += ' ' + theSmilie + ' ';
    document.REPLIER.Post.focus();
}

// Start the subroutines.

var Quote = 0;
var Bold  = 0;
var Italic = 0;
var Underline = 0;
var Code = 0;


// IBC Code stuff
var text_enter_url      = "$Post::lang->{'jscode_text_enter_url'}";
var text_enter_url_name = "$Post::lang->{'jscode_text_enter_url_name'}";
var text_enter_image    = "$Post::lang->{'jscode_text_enter_image'}";
var text_enter_email    = "$Post::lang->{'jscode_text_enter_email'}";
var text_enter_flash    = "$Post::lang->{'jscode_text_enter_flash'}";
var text_flash_width    = "$Post::lang->{'jscode_text_flash_width'}";
var text_flash_height   = "$Post::lang->{'jscode_text_flash_height'}";
var text_code           = "$Post::lang->{'jscode_text_code'}";
var text_quote          = "$Post::lang->{'jscode_text_quote'}";
var error_no_url        = "$Post::lang->{'jscode_error_no_url'}";
var error_no_title      = "$Post::lang->{'jscode_error_no_title'}";
var error_no_email      = "$Post::lang->{'jscode_error_no_email'}";
var error_no_width      = "$Post::lang->{'jscode_error_no_width'}";
var error_no_height     = "$Post::lang->{'jscode_error_no_height'}";


function PostWrite(NewCode) {
    document.REPLIER.Post.value+=NewCode;
    document.REPLIER.Post.focus();
    return;
}

function IBCurl() {
    var FoundErrors = '';
    var enterURL   = prompt(text_enter_url, "http://");
    var enterTITLE = prompt(text_enter_url_name, "My Webpage");
    if (!enterURL)    {
        FoundErrors += "\\n" + error_no_url;
    }
    if (!enterTITLE)  {
        FoundErrors += "\\n" + error_no_title;
    }
    if (FoundErrors)  {
        alert("Error!"+FoundErrors);
        return;
    }
    var ToAdd = "[URL="+enterURL+"]"+enterTITLE+"[/URL]";
    document.REPLIER.Post.value+=ToAdd;
	document.REPLIER.Post.focus();
}

function IBCimage() {
    var FoundErrors = '';
    var enterURL   = prompt(text_enter_image, "http://");
    if (!enterURL) {
        FoundErrors += "\\n" + error_no_url;
    }
    if (FoundErrors) {
        alert("Error!"+FoundErrors);
        return;
    }
    var ToAdd = "[IMG]"+enterURL+"[/IMG]";
    document.REPLIER.Post.value+=ToAdd;
	document.REPLIER.Post.focus();
}

function IBCemail() {
    var emailAddress = prompt(text_enter_email,"");
    if (!emailAddress) { alert(error_no_email); return; }
    var ToAdd = "[EMAIL]"+emailAddress+"[/EMAIL]";
    PostWrite(ToAdd);
}

function IBCflash(maxWidth, maxHeight) {
   var FoundErrors = '';
   var FlashURL    = prompt(text_enter_flash, "http://");
   var FlashWidth  = prompt(text_flash_width +" "+ maxWidth, "");
   var FlashHeight = prompt(text_flash_height +" "+ maxHeight, "");
   if (!FlashURL)    { FoundErrors+="\\n"+error_no_url;      }
   if (!FlashWidth)  { FoundErrors+="\\n"+error_no_width;    }
   if (!FlashHeight) { FoundErrors+="\\n"+error_no_height;   }
   if (FoundErrors)  { alert("Error!"+FoundErrors); return; }
   var ToAdd = "[FLASH="+FlashWidth+","+FlashHeight+"]"+FlashURL+"[/FLASH]";
   PostWrite(ToAdd);
}


function IBCcode() {
   if (Code == 0) {
      ToAdd = "[CODE]";
      document.REPLIER.code.value = " Code*";
      Code = 1;
   } else {
      ToAdd = "[/CODE]";
      document.REPLIER.code.value = " Code ";
      Code = 0;
   }
   PostWrite(ToAdd);
}

function IBCquote() {
   if (Quote == 0) {
      ToAdd = "[QUOTE]";
      document.REPLIER.quote.value = " Quote*";
      Quote = 1;
   } else {
      ToAdd = "[/QUOTE]";
      document.REPLIER.quote.value = " Quote ";
      Quote = 0;
   }
   PostWrite(ToAdd);
}


function IBCbold() {
   if (Bold == 0) {
      ToAdd = "[B]";
      document.REPLIER.bold.value = " B*";
      Bold = 1;
   } else {
      ToAdd = "[/B]";
      document.REPLIER.bold.value = " B ";
      Bold = 0;
   }
   PostWrite(ToAdd);
}

function IBCitalic() {
   if (Italic == 0) {
      ToAdd = "[I]";
      document.REPLIER.italic.value = " I*";
      Italic = 1;
   } else {
      ToAdd = "[/I]";
      document.REPLIER.italic.value = " I ";
      Italic = 0;
   }
   PostWrite(ToAdd);
}


function IBCunder() {
   if (Underline == 0) {
      ToAdd = "[U]";
      document.REPLIER.under.value = " U*";
      Underline = 1;
   } else {
      ToAdd = "[/U]";
      document.REPLIER.under.value = " U ";
      Underline = 0;
   }
   PostWrite(ToAdd);
}

//-->
</script>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='top'><b>$Post::lang->{'ib_code_buttons'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>
                <input type='button' accesskey='b' value=' B '       onClick='IBCbold()'   class='forminput' title="BOLD: [Control / Alt] + b"      name='bold'   style="font-weight:bold">
                <input type='button' accesskey='i' value=' I '       onClick='IBCitalic()' class='forminput' title="ITALIC: [Control / Alt] + i"    name='italic' style="font-style:italic">
                <input type='button' accesskey='u' value=' U '       onClick='IBCunder()'  class='forminput' title="UNDERLINE: [Control / Alt] + u" name='under' style="text-decoration:underline">&nbsp;
                <input type='button' accesskey='h' value=' http:// ' onClick='IBCurl()'    class='forminput' title="HYPERLINK: [Control / Alt] + h" style="text-decoration:underline;color:blue">&nbsp;
                <input type='button' accesskey='e' value='  @  '     onClick='IBCemail()'  class='forminput' title="EMAIL: [Control / Alt] + e"     style="text-decoration:underline;color:blue">&nbsp;
                <input type='button' accesskey='q' value=' Quote '   onClick='IBCquote()'  class='forminput' title="QUOTE: [Control / Alt] + q" name='quote'>&nbsp;
                <input type='button' accesskey='c' value=' Code '    onClick='IBCcode()'   class='forminput' title="CODE: [Control / Alt] + c"  name='code'>&nbsp;
                $img_button $ibc_flash<br><font class='misc'>$Post::lang->{'buttons_js'}</font>
                </td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='top'>
                    <table cellspacing='0' cellpadding='0' border='0' bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left' width='100%'>
                        <tr>
                         <td valign='top' align='left'><b>$Post::lang->{'post'}</b><br>(<a href='javascript:CheckLength();'>$Post::lang->{'check_length'}</a>)<br>&nbsp;</td>
                        </tr>
                        <tr>
                         <td align='left' valign='middle'><!--SMILIE TABLE--></td>
                        </tr>
                    </table>
                </td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><textarea cols='60' rows='12' wrap='soft' name='Post' tabindex='3' class='textinput'>$data</textarea><br><b>$Post::lang->{'help_cards'}</b> [ <a href="javascript:PopUp('$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION&act=Legends&CODE=emoticons','HelpCard','200','400','0','1','1','1')">Emoticons</a> :: <a href="javascript:PopUp('$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION&act=Legends&CODE=ibcode','HelpCard','250','400','0','1','1','1')">iB Code</a> ]<br>$Post::lang->{'max_length'} $Post::lang->{'the_max_length'}</td>
                </tr>

~;
}


sub smilie_table {

return qq~
    <table cellspacing='1' cellpadding='3' border='0' bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' style="border-width:1px; border-style:inset; width:125px" align='left'>
    <tr>
        <td colspan='$iB::INFO->{'EMO_PER_ROW'}' align='center'>$Post::lang->{'click_smilie'}</td>
    </tr>
    <!--THE SMILIES-->
    </table>
~;

}

#+-------------------------------------------------------------------------------------------------------------


sub quote_box {
my $data = shift;

return qq~

                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' align='left' colspan='2' id='titlelarge'>$Post::lang->{'original_post'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left' valign='top'><b>$Post::lang->{'post_to_quote'}</b><br>$Post::lang->{'post_to_quote_txt'}</td>
                <td bgcolor=$iB::SKIN->{'MISCBACK_ONE'} width='70%'>
                <textarea cols='60' rows='12' wrap='soft' name='QPost' class='textinput'>$data->{'POST'}</textarea><input type='hidden' name='QAuthor' value='$data->{'AUTHOR'}'><input type='hidden' name='QDate'   value='$data->{'POST_DATE'}'></td>
                </tr>

~;
}


#+-------------------------------------------------------------------------------------------------------------


sub CheckBoxes {

return qq~
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' align='left' colspan='2' id='titlelarge'>$Post::lang->{'options'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='30%' valign='top'>$Post::lang->{'post_options'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='checkbox' name='enableemo' value='yes' checked>&nbsp;$Post::lang->{'enable_emo'}<br><input type='checkbox' name='enablesig' value='yes' checked>&nbsp;$Post::lang->{'enable_sig'}</td>
                </tr>
~;
}


#+-------------------------------------------------------------------------------------------------------------



sub PostIcons {
  
return qq~
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left' valign='top'>$Post::lang->{'post_icon'}<br>$Post::lang->{'post_icon_txt'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='70%'>
                <INPUT type="radio" name="iconid" value="1">&nbsp;&nbsp;<IMG SRC="$iB::INFO->{'IMAGES_URL'}/PostIcons/icon1.gif" HEIGHT='15' WIDTH='15' ALIGN='center' alt=''>&nbsp;&nbsp;&nbsp;&nbsp; <INPUT type="radio" name="iconid" value="2" >&nbsp;&nbsp;<IMG SRC="$iB::INFO->{'IMAGES_URL'}/PostIcons/icon2.gif" HEIGHT='15' WIDTH='15' ALIGN='center' alt=''>&nbsp;&nbsp;&nbsp;&nbsp; <INPUT type="radio" name="iconid" value="3" >&nbsp;&nbsp;<IMG SRC="$iB::INFO->{'IMAGES_URL'}/PostIcons/icon3.gif" HEIGHT='15' WIDTH='15' ALIGN='center' alt=''>&nbsp;&nbsp;&nbsp;&nbsp; <INPUT type="radio" name="iconid" value="4" >&nbsp;&nbsp;<IMG SRC="$iB::INFO->{'IMAGES_URL'}/PostIcons/icon4.gif" HEIGHT='15' WIDTH='15' ALIGN='center' alt=''>&nbsp;&nbsp;&nbsp;&nbsp; <INPUT type="radio" name="iconid" value="5" >&nbsp;&nbsp;<IMG SRC="$iB::INFO->{'IMAGES_URL'}/PostIcons/icon5.gif" HEIGHT='15' WIDTH='15' ALIGN='center' alt=''>&nbsp;&nbsp;&nbsp;&nbsp; <INPUT type="radio" name="iconid" value="6" >&nbsp;&nbsp;<IMG SRC="$iB::INFO->{'IMAGES_URL'}/PostIcons/icon6.gif" HEIGHT='15' WIDTH='15' ALIGN='center' alt=''>&nbsp;&nbsp;&nbsp;&nbsp; <INPUT type="radio" name="iconid" value="7" >&nbsp;&nbsp;<IMG SRC="$iB::INFO->{'IMAGES_URL'}/PostIcons/icon7.gif" HEIGHT='15' WIDTH='15' ALIGN='center' alt=''>&nbsp;&nbsp;&nbsp;&nbsp; <br>
                <INPUT type="radio" name="iconid" value="8">&nbsp;&nbsp;<IMG SRC="$iB::INFO->{'IMAGES_URL'}/PostIcons/icon8.gif" HEIGHT='15' WIDTH='15' ALIGN='center' alt=''>&nbsp;&nbsp;&nbsp;&nbsp; <INPUT type="radio" name="iconid" value="9" >&nbsp;&nbsp;<IMG SRC="$iB::INFO->{'IMAGES_URL'}/PostIcons/icon9.gif" HEIGHT='15' WIDTH='15' ALIGN='center' alt=''>&nbsp;&nbsp;&nbsp;&nbsp; <INPUT type="radio" name="iconid" value="10" >&nbsp;&nbsp;<IMG SRC="$iB::INFO->{'IMAGES_URL'}/PostIcons/icon10.gif" HEIGHT='15' WIDTH='15' ALIGN='center' alt=''>&nbsp;&nbsp;&nbsp;&nbsp; <INPUT type="radio" name="iconid" value="11" >&nbsp;&nbsp;<IMG SRC="$iB::INFO->{'IMAGES_URL'}/PostIcons/icon11.gif" HEIGHT='15' WIDTH='15' ALIGN='center' alt=''>&nbsp;&nbsp;&nbsp;&nbsp; <INPUT type="radio" name="iconid" value="12" >&nbsp;&nbsp;<IMG SRC="$iB::INFO->{'IMAGES_URL'}/PostIcons/icon12.gif" HEIGHT='15' WIDTH='15' ALIGN='center' alt=''>&nbsp;&nbsp;&nbsp;&nbsp; <INPUT type="radio" name="iconid" value="13" >&nbsp;&nbsp;<IMG SRC="$iB::INFO->{'IMAGES_URL'}/PostIcons/icon13.gif" HEIGHT='15' WIDTH='15' ALIGN='center' alt=''>&nbsp;&nbsp;&nbsp;&nbsp; <INPUT type="radio" name="iconid" value="14" >&nbsp;&nbsp;<IMG SRC="$iB::INFO->{'IMAGES_URL'}/PostIcons/icon14.gif" HEIGHT='15' WIDTH='15' ALIGN='center' alt=''>&nbsp;&nbsp;&nbsp;&nbsp; 
                <BR>
                <INPUT type="radio" name="iconid" value="0" CHECKED>&nbsp;&nbsp;<IMG SRC="$iB::INFO->{'IMAGES_URL'}/PostIcons/icon0.gif" HEIGHT=15 WIDTH=15 ALIGN=ABSCENTER alt="Default">
                </td>
                </tr>

~;
}


#+-------------------------------------------------------------------------------------------------------------


sub EndForm {
my $data = shift;

return qq~

                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='center' colspan='2'>
                <input type="submit" name="submit" value="$data" tabindex='4' class='forminput'>&nbsp;
                <input type="submit" name="preview" value="$Post::lang->{'button_preview'}" tabindex='5' class='forminput'>
                </td>
                </tr>
            </table>
            </td>
          </tr>
       </table>
   </form>

~;
}


sub post_stats {

return qq~
    <br>
    <table cellpadding='3' cellspacing='1' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
        <tr>
          <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left' style='border-bottom:1px solid black;border-top:1px solid black'><b>$Post::lang->{'posting_cond'}</b></td>
        </tr>
           <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left' style='padding-left: 10px'>
            <br>$Post::lang->{'ib_state'}
            <br>$Post::lang->{'html_state'}
            <br>$Post::lang->{'stat_allow_img'}
            <br>$Post::lang->{'stat_max_img'}
            <br>$Post::lang->{'stat_max_emo'}
            <br>$Post::lang->{'stat_flash'}<br>$Post::lang->{'stat_flash_w'}<br>$Post::lang->{'stat_flash_h'} <br>$Post::lang->{'stat_dyn_img'}
          </td>
        </tr>
    </table>
~;
}


#+-------------------------------------------------------------------------------------------------------------

sub TopicSummary_top {

return qq~

    <a name="top">
    <!-- Cgi-bot TopicSummaryTop -->
    <br>
     <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
       <tr>
         <td>
            <table cellpadding='3' cellspacing='1' border='0' width='100%'>
             <tr>
               <td bgcolor='$iB::SKIN->{'TITLEBACK'}' valign='left' colspan='2' id='titlelarge'>$Post::lang->{'last_posts'}</td>
             </tr>  
        <!-- Cgi-bot End TopicSummaryTop -->

~;

}


sub TopicSummary_body {
    my $data = shift;

return qq~
             <tr id='postdetails'>
               <td bgcolor='$iB::SKIN->{'POST_COL_ONE'}' align='left' valign='top' width='20%'><b>$data->{'POSTER'}->{'MEMBER_NAME'}</b></td>
               <td bgcolor='$iB::SKIN->{'POST_COL_ONE'}' align='left' valign='top' width='80%'>$Post::lang->{'posted_on'} $data->{'POST_DATE'}<hr noshade size='1'><span id='postcolor'>$data->{'POST'}</span></td>
             </tr>  

~;
   
}


sub TopicSummary_bottom {
return qq~

           <!-- Cgi-bot TopicSummaryBottom -->
        <tr>
           <td bgcolor='$iB::SKIN->{'TITLEBACK'}' valign='left' colspan='2' id='titlemedium'><a href="javascript:PopUp('ikonboard.$iB::INFO->{'CGI_EXT'}?act=ST;f=$iB::IN{'f'};t=$iB::IN{'t'}','TopicSummary',700,450,1,1)">$Post::lang->{'review_topic'}</a></td>
        </tr>
        </table>
      </td>
     </tr>
    </table>
    <!-- Cgi-bot End TopicSummaryBottom -->

~;

}





1;
