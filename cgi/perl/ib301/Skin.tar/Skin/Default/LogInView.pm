package LogInView;

use strict;


sub ShowForm {
my $message = shift;

return qq~
    <script language='JavaScript'>
    <!--
    function ValidateForm() {
        var Check = 0;
        if (document.LOGIN.UserName.value == '') { Check = 1; }
        if (document.LOGIN.PassWord.value == '') { Check = 1; }

        if (Check == 1) {
            alert("$LogInOut::lang->{'blank_fields'}");
            return false;
        } else {
            document.LOGIN.submit.disabled = true;
            return true;
        }
    }
    //-->
    </script>     

     <br>
     <table cellpadding='3' cellspacing='1' border='0' align='center' width='$iB::SKIN->{'TABLE_WIDTH'}'>
     <tr>
     <td align='left'><b>$LogInOut::lang->{'not_registered'} <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Reg;CODE=00'>$LogInOut::lang->{'reg_link'}</a></b></td>
     </tr>
     <tr>
     <td align='left'><b>$LogInOut::lang->{'forgot_pass'} <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=LostPass;CODE=00'>$LogInOut::lang->{'pass_link'}</a></b></td>
     </tr>
     </table>
     <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='LOGIN' onSubmit='return ValidateForm()'>
     <input type='hidden' name='act' value='Login'>
     <input type='hidden' name='CODE' value='01'>
     <input type='hidden' name='s' value='$iB::SESSION'>
     <input type='hidden' name='referer' value="$iB::IN{'REFERER'}">
     <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='3' cellspacing='1' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='left' colspan='2' id='titlelarge'>$message</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%'>$LogInOut::lang->{'enter_name'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' size='20' maxlength='64' name='UserName' class='forminput'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%'>$LogInOut::lang->{'enter_pass'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='password' size='20' name='PassWord' class='forminput'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' align='left' colspan='2' id='titlelarge'>$LogInOut::lang->{'options'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%' align='left' valign='top'>$LogInOut::lang->{'cookies'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%'><input type="radio" name="CookieDate" value="1" checked>$LogInOut::lang->{'cookie_yes'}<br><input type="radio" name="CookieDate" value="0">$LogInOut::lang->{'cookie_no'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%' align='left' valign='top'>$LogInOut::lang->{'privacy'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%'><input type="checkbox" name="Privacy" value="1">$LogInOut::lang->{'anon_name'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='center' colspan='2'>
                <input type="submit" name='submit' value="$LogInOut::lang->{'log_in_submit'}" class='forminput'>
                </td></tr></table>
                </td></tr></table>
                </form>

~;
}

sub ShowLogOutForm {

return qq~  
     <br>
     <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION" method="post">
     <input type='hidden' name='act' value='Login'>
     <input type='hidden' name='CODE' value='03'>
     <input type='hidden' name='s' value='$iB::SESSION'>
     <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='3' cellspacing='1' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' valign='left' colspan='2' id='titlelarge'>$LogInOut::lang->{'log_out'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2' valign='middle'><br>$LogInOut::lang->{'log_out_txt'}<br></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='center' colspan='2'>
                <input type="submit" value="$LogInOut::lang->{'log_out_submit'}" class='forminput'>
                </td></tr></table>
                </td></tr></table>
                </form>
~;
}

sub errors {
    my $data = shift;

return qq~
 
     <table cellpadding='0' cellspacing='1' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='5' cellspacing='1' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'POST_COL_ONE'}' valign='top' align='left' id='highlight'><b>$LogInOut::lang->{'errors_found'}</b><hr noshade size='1' color='$iB::SKIN->{'TABLE_BORDER_COL'}'>$data</td>
                </tr>
                </table>
            </td>
        </tr>
    </table>
    <br>
~;

}





1;

__END__
