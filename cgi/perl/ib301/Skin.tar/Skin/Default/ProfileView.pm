package ProfileView;

use strict;




sub ShowProfile {
my $Profile = shift;


return qq~
  
     <br>
     <table cellpadding='0' cellspacing='1' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='5' cellspacing='1' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}'  colspan='2' id='titlelarge'>$Profile->{'MEMBER_NAME'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2' align='center' valign='middle'>$Profile->{'PHOTO'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2' width='100%' align='center' valign='middle'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Msg;CODE=04;MID=$Profile->{'MEMBER_ID'}'><b>$Profile::lang->{'send_pm'}</b></a></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2' width='100%' align='center' valign='middle'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Msg;CODE=02;MID=$Profile->{'MEMBER_ID'}'><b>$Profile::lang->{'add_book'}</b></a></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' colspan='2' id='titlelarge'><b>$Profile::lang->{'personal_header'}</b></td>
                </tr>
$Profile->{'BIRTHDAY'}
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='50%'><b>$Profile::lang->{'registration_date'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left' width='50%'>$Profile->{'MEMBER_JOINED'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='50%'><b>$Profile::lang->{'last_modification'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left' width='50%'>$Profile->{'LAST_UPDATE'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='50%'><b>$Profile::lang->{'total_posts'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left' width='50%'>$Profile->{'MEMBER_POSTS'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='50%'><b>$Profile::lang->{'post_average'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left' width='50%'>$Profile->{'POST_AVERAGE'} $Profile::lang->{'per_day'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='50%'><b>$Profile::lang->{'member_level'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left' width='50%'>$Profile->{'MEMBER_TITLE'} $Profile->{'MEMBER_PIPS_IMG'}</td>
                </tr>     
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='50%'><b>$Profile::lang->{'home_page'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left' width='50%'>$Profile->{'WEBSITE'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='50%'><b>$Profile::lang->{'location'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left' width='50%'>$Profile->{'LOCATION'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='50%' valign='top'><b>$Profile::lang->{'interests'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left' width='50%'>$Profile->{'INTERESTS'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='50%' valign='top'><b>$Profile::lang->{'signature'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left' width='50%'>$Profile->{'SIGNATURE'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' colspan='2'id ='titlelarge'><b>$Profile::lang->{'contact_header'}</b></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='50%'><b>$Profile::lang->{'email_address'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left' width='50%'>$Profile->{'MEMBER_EMAIL'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='50%'><b>$Profile::lang->{'icq_number'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left' width='50%'>$Profile->{'ICQNUMBER'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='50%'><b>$Profile::lang->{'aol_name'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left' width='50%'>$Profile->{'AOLNAME'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='50%'><b>$Profile::lang->{'yahoo_name'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left' width='50%'>$Profile->{'YAHOONAME'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='50%'><b>$Profile::lang->{'msn_name'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left' width='50%'>$Profile->{'MSNNAME'}</td>
                </tr>
                </table>
                </td></tr></table>
~;
}

sub show_authorise {
my ($member, $new_email) = @_;

return qq~
     <table cellpadding=0 cellspacing=0 border=0 width=$iB::SKIN->{'TABLE_WIDTH'} bgcolor=$iB::SKIN->{'TABLE_BORDER_COL'} align=center>
        <tr>
            <td>
                <table cellpadding=3 cellspacing=1 border=0 width=100%>
                <tr>
                <td bgcolor=$iB::SKIN->{'TITLEBACK'} valign='left'><font class='titlelarge'>$Profile::lang->{'registration_process'}</font></td>
                </tr>
                <tr>
                <td bgcolor=$iB::SKIN->{'MISCBACK_ONE'}><font class='misc'>$Profile::lang->{'thank_you'} $member->{'MEMBER_NAME'}. $Profile::lang->{'auth_text'}  $new_email</font></td>
                </tr>
                </table>
            </td>
        </tr>
    </table>

~;
}

1;

__END__
