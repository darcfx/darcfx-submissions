package UserCPWords;


sub new {
  my $pkg = shift;
  my $obj = {
   
#+----------------------------------------------------------------------
#| Do Not remove or edit anything above this line!
#| Only Edit the words on the right of the => arrow
#+----------------------------------------------------------------------

#+---------
# Added by Infection

birthday    => "Your Birthday Date",
month1      => "January",
month2      => "February",
month3      => "March",
month4      => "April",
month5      => "May",
month6      => "June",
month7      => "July",
month8      => "August",
month9      => "September",
month10     => "October",
month11     => "November",
month12     => "December",

#
#+--------

## Added RC 1 -------------------------

member_title => "Custom member title",
email_text_lp  => "Lost Password request at",
lp_redirect    => "Email dispatched",

js_location  => "Location",
js_interests => "Interests",
js_signature => "Signature",
js_characters => "characters",
js_max        => "The maximumm allowed length is",
js_used       => "You have used",
js_so_far     => "characters so far",


##-------------------------------------

splash         => q|Summary|,
personal       => q|Personal Info|,
email          => q|Email Settings|,
subs           => q|Topic Tracker|,
settings       => q|Account Options|,
account        => q|Modify Account|,

welcome        => q|Welcome to your control panel |,
welcome_text   => q| this is where you'll be able to control all of your personal and board options to make your visit to our forums more enjoyable. Please select an option from one of the menu tabs above. If this is your first visit you may wish to look at the Control Panel overview below.|,

stats_header   => q|Here is a brief summary of your user account|,
messenger_header    => q|Your Messenger Status|,


subs_title      => q|Your Topic Subscriptions|,
subs_text       => q| this is where you can control all the topics you've subscribed to. You can <b>cancel</b> any subscriptions from this panel. Or just see how many days a topic has left on it's subscription|,
subs_header     => q|Current Subscriptions|,
subs_none       => q|You are not subscribed to any topics|,
subs_deleted    => q|The subscription has been deleted|,
subs_forum      => q|Forum|,
subs_topic      => q|Topic|,
subs_options    => q|Options|,
subs_start      => q|Subscribed on|,
subs_left       => q|Days Left|,
subs_cancel     => q|Cancel|,

subs_view        => "Views",
subs_replies     => "Replies",
subs_last_post   => "Last Post",
subs_by          => "By:",

account_title    => q|Modify Your Account|,
account_text     => q|You may change your account email address and password from here. Both of these details are required to verify your log in information.|,

account_email_title => q|Your registered email address|,
account_email_txt   => q|Your Email Address|,
account_email_req   => q|You will receive an email asking you to verify this change|,

account_pass_title  => q|Your Password|,
account_pass_old    => q|Enter your OLD password|,
account_pass_new    => q|Enter your NEW password|,
account_pass_new2   => q|Please confirm your NEW password|,

account_pass_submit => q|Change my Password|,
account_email_submit    => q|Change my Email Address|,


settings_hour   => q|Hours|,
settings_skin   => q|Board 'Skin'|,
settings_skin_txt   => q|You may choose a 'skin' to use.<br>This will change the way the board looks|,

settings_display    => "Board Display Settings",
settings_viewsig    => "Do you wish to view members signatures when reading threads?",
settings_viewimg    => "Do you wish to view images in posts, such as smilies and posted images?",
settings_viewava    => "Do you wish to view members avatars when reading threads?",

settings_title  => q|Your Account Options|,
settings_text   => q| this is where you can change the board interface settings to help make your visit to our forums more comfortable|,

settings_time   => q|Time Zone|,
settings_time_txt  => q|You may adjust the base time zone<br>The time (including your current adjustment) is:|,

settings_lang   => q|Board Interface Language|,
settings_lang_txt => q|Please select a language for the board interface|,
settings_dopopup  => 'Do you wish to get a pop up notification when you get a new private message?',

settings_submit     => q|Change my Account Options|,


msg_new        => q|You have new messages!|,
msg_no_new     => q|You have no new messages|,
messenger_url  => q|Go to your messenger|,


email_address  => q|Your registered email address|,
number_posts   => q|Total number of posts to date|,
daily_average  => q|Average number of posts per day|,
registered     => q|You registered on |,

email_title    => q|Your email settings|,
email_header   => q|, you may amend your personal email settings here. This will allow you to keep your email address hidden and you'll also be able to specify your preferences on any emails sent to you via this board|,

privacy_settings    => q|Privacy Settings|,
board_prefs         => q|Board Preferences|,


hide_email      => q|<b>Hide my email address from other members</b>|,
admin_send      => q|<b>Send me any updates sent by the board administrator</b>|,
send_full_msg   => q|<b>Include a copy of the post when emailing me from a subscribed topic</b>|,
pm_reminder     => q|<b>Send a confirmation email when I receive a new private message</b>|,
end_subs        => q|<b>Number of days a topic subscription lasts</b><br>(This is useful to automatically unsubscribe from a subscription after the number of days entered have passed)|,
submit_email    => q|Amend my email settings|,


profile_title  => q|Your personal profile|,
profile_header => q|, you may create and/or amend your personal profile. This will be viewable by everyone. All of this information is optional|,
website        => q|<b>Your website url</b>|,
icq            => q|<b>Your ICQ UIN</b>|,
aol            => q|<b>Your AOL identity</b>|,
yahoo          => q|<b>Your Yahoo identity</b>|,
msn            => q|<b>Your MSN Messenger identity</b>|,
location       => q|<b>Your Location</b>|,
interests      => q|<b>Your interests</b>|,
signature      => q|<b>Your Signature</b>|,
photo          => q|<b>You may enter a URL for a personal photograph</b><br>[This will only be displayed on your profile - not with your posts]|,

avatar_title        => q|Your avatar options|,
avatar_sub          => q|this is where you can choose to use an avatar under yourname when you post a message on these boards.|,
avatar_url_allowed  => q|<br>You can either select an avatar already installed on this board, or enter a URL for an image you've got uploaded on your website. Please choose which you'd prefer.|,
avatar              => q|<b>Your avatar</b>|,
avatar_click        => q|Click on one of the avatars in this list to add it into the 'Your Avatar' box.|,
avatar_dims         => q|<b>Avatar Dimensions</b>|,
width               => q|Width|,
height              => q|Height|,
maximum             => q|Maximum|,
pixels              => q|pixels|,
avatar_dims_txt     => q|You may enter the width and height of your avatar. Please note that any value over the maximum allowed size in pixels will be resized to the maximum size. Leaving them blank will resize the image to the maxiumum size.|,
avatar_url_ext      => q|The following file types are allowed: |,
avatar_pre_title    => q|Pre-installed avatars|,
avatar_url_title    => q|Your image avatars|,
avatar_url_txt      => q|You may enter a URL to choose an avatar that is on your own website. The URL <b>MUST</b> begin with <font class='highlight'>http://</font>|,
avatar_pre_txt      => q|Please select an avatar from the list below, simply click on the avatar's name to view it.|,
avatar_show_all     => q|<br><u>[ Help Cards: Show all avatars ]|,
avatar_pre_submit   => q|Add this avatar to my profile|,
avatar_url_submit   => q|Add my own image as my avatar|,
current_avatar      => q|Avatar Preview|,
av_current         => q|Your Current Avatar|,
av_none_selected    => '[ No Avatar Selected ]',
av_personal         => 'You are currently using a personal avatar',
av_preset           => 'You are currently using a pre-installed avatar',


personal_ops      => q|Your personal options|,
personal_ops_txt  => q|this is where you can modify your personal information to allow others to find out a little more about you. This is also where you can set up your avatar. An avatar is a little image that is displayed under your name when you make a post.|,
edit_profile      => q|Edit your profile|,
edit_profile_txt  => q|This is where you can edit or create your personal profile. It'll allow you to create a signature to leave under each message you post. It'll also allow you to enter any contact information, such as your website address, ICQ number, etc.|,
avatar_ops        => q|Avatar Options|,
avatar_ops_txt    => q|This is where you can choose your avatar to use when making a post. This is completely optional, but many members use them as a fun way to express themselves.|,

yes => "Yes",
no  => "No",


submit_profile => q|Amend my profile|,

no_posts       => q|You've yet to post|,

check_length  => "Check Length",

quick_help     => q|An overview of your personal Control Panel|,
personal_help  => q|This is where you can amend your personal profile for other visitors to view|,
email_help     => q|This is where you can change your email settings|,
subs_help      => q|This is where you can view and/or change which topics you have added to your email notify list|,
settings_help  => q|This is where you can change the way the board looks, which language to view the interface with and other board functions|,
account_help   => q|This is where you can change the details you signed up with, such as your email address and password|,

t_welcome => "Welcome to your control panel",
t_title => "Your control panel",
#+----------------------------------------------------------------------
#| Do Not remove or edit anything below this line!
#+----------------------------------------------------------------------
  };

  bless $obj, $pkg;
  return $obj;
}




1;

__END__
