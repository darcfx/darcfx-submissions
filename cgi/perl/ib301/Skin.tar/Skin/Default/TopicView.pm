package TopicView;



sub PageTop {
my $data = shift;


return qq~

    <script language='javascript'>
    <!--
    function delete_post(theURL) {
       if (confirm("$Topic::lang->{js_del_1}")) {
          window.location.href=theURL;
       }
       else {
          alert ("$Topic::lang->{js_del_2}");
       } 
    }
    //-->
    </script>
    <a name="top"></a>
    <!-- Cgi-bot Start Forum page unique top -->
     <table cellpadding='0' cellspacing='4' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
      <tr>
         <td valign='middle' width='50%' nowrap align='left'>$data->{'TOPIC'}->{'SHOW_PAGES'}</td>
         <td valign='middle' width='50%' nowrap align='right'>$data->{'TOPIC'}->{'REPLY_BUTTON'}&nbsp;<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Post;CODE=00;f=$data->{'FORUM'}->{'FORUM_ID'}" title='$Topic::lang->{'start_new_topic'}'>$iB::SKIN->{'A_POST'}</a>&nbsp;$data->{'TOPIC'}->{'POLL_BUTTON'}</td>
      </tr>
     </table>
     <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
              <table cellpadding='0' cellspacing='1' border='0' width='100%'>
                <tr>
                  <td bgcolor='$iB::SKIN->{'TITLEBACK'}'>
                    <table border='0' width='100%' cellspacing='0' cellpadding='0' bgcolor='$iB::SKIN->{'TITLEBACK'}'>
                      <tr>
                        <td valign='middle' align='left' id='titlemedium'>&nbsp;&nbsp;<b>$Topic::lang->{'topic'}</b>: $data->{'TOPIC'}->{'TOPIC_TITLE'}$data->{'TOPIC'}->{'TOPIC_DESC'}</td><td valign='middle' align='right' id='titlemedium'>&lt; <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ST;f=$data->{'FORUM'}->{'FORUM_ID'};t=$data->{'TOPIC'}->{'TOPIC_ID'};view=old'>$Topic::lang->{'t_old'}</a> | <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ST;f=$data->{'FORUM'}->{'FORUM_ID'};t=$data->{'TOPIC'}->{'TOPIC_ID'};view=new'>$Topic::lang->{'t_new'}</a> &gt;&nbsp;&nbsp;</td>
                      </tr>
                     </table>
                  </td>
                </tr>
              </table>
           </td>
        </tr>
     </table> 
     <!-- Cgi-bot End Forum page unique top -->

~;
}


#-------------------------------------------------------------
#
# Topic Entry :: This slice of HTML is used to display each
# topic entry
#
#-------------------------------------------------------------



sub RenderRow {
my $data = shift;

return qq~

    
    <!--Begin Msg Number $data->{'POST'}->{'POST_ID'}-->
    <table cellpadding='0' cellspacing='1' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
    <tr>
        <td bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}'>
            <table width='100%' cellpadding='4' cellspacing='0' bgcolor='$data->{'POST'}->{'POST_BACK_COL'}' border='0'>
                <tr>
                    <td bgcolor='$data->{'POST'}->{'POST_BACK_COL'}' valign='top' width='175'  rowspan='2' nowrap><span id='$data->{'POST'}->{'NAME_CSS'}'>$data->{'POSTER'}->{'MEMBER_NAME'}</span><br>$data->{'POSTER'}->{'MEMBER_AVATAR'}<br><span id="membertitle">$data->{'POSTER'}->{'MEMBER_TITLE'}</span><br>$data->{'POSTER'}->{'MEMBER_PIPS_IMG'}<span id='postdetails'><br>$data->{'POSTER'}->{'MEMBER_GROUP'}<br>$data->{'POSTER'}->{'MEMBER_POSTS'}<br>$data->{'POSTER'}->{'MEMBER_JOINED'}</span><br>$data->{'POSTER'}->{'WARN_GFX'}</td>
                    <td bgcolor='$data->{'POST'}->{'POST_BACK_COL'}' valign='top' width='100%' height='100%'>
                        <table width='100%' border='0'>
                            <tr>
                                <td valign='middle' align='left'><img src="$data->{'POST'}->{'POST_ICON'}" border='0' width='15' height='15' align='middle' alt=''></td>
                                <td valign='middle' align='left' width='100%' id='postdetails'><b>$Topic::lang->{'posted_on'}</b> $data->{'POST'}->{'POST_DATE'}</td>
                                <td align='right' valign='bottom' nowrap>$data->{'POST'}->{'DELETE_ICON'}&nbsp;$data->{'POST'}->{'EDIT_ICON'}&nbsp;<a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Post;CODE=06;f=$iB::IN{'f'};t=$iB::IN{'t'};p=$data->{'POST'}->{'POST_ID'}'>$iB::SKIN->{'P_QUOTE'}</a></td>
                            </tr>
                        </table>
                        <hr size='1' width='100%' color='$iB::SKIN->{'TABLE_BORDER_COL'}'><a name="entry$data->{'POST'}->{'POST_ID'}"></a>
                        <span id='postcolor'>$data->{'POST'}->{'POST'} $data->{'POST'}->{'RENDER_ATTACHMENT'} $data->{'POST'}->{'SIGNATURE'}</span>
                    </td>
                </tr>
                <tr>
                <td class='bottom' bgcolor='$data->{'POST'}->{'POST_BACK_COL'}'>
                    <hr size='1' width='100%' color='$iB::SKIN->{'TABLE_BORDER_COL'}'>
                    <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                        <tr>
                            <td valign='middle' align='left'>$data->{'POSTER'}->{'PROFILE_ICON'}$data->{'POSTER'}->{'MESSAGE_ICON'}$data->{'POSTER'}->{'EMAIL_ICON'}$data->{'POSTER'}->{'WEBSITE_ICON'}$data->{'POSTER'}->{'ICQ_ICON'}$data->{'POSTER'}->{'AOL_ICON'}$data->{'POSTER'}->{'YAHOO_ICON'}$data->{'POSTER'}->{'MSN_ICON'}</td>
                            <td valign='middle' align='right'>$data->{'POST'}->{'USER_IP'} $data->{'POST'}->{'REPORT_POST'}</td>
                        </tr>
                    </table>
                </td>
                </tr>
            </table>
        </td>
    </tr>
   </table>
  <!-- end Message -->

~;
}


sub ip_show {
my $data = shift;
return qq~<span id='highlight'>$Topic::lang->{'ip'}: $data</span>~;
}


sub report_link {
my $data = shift;
return qq~&nbsp;&nbsp;&nbsp;<span id='highlight'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Report;f=$data->{'FORUM_ID'};t=$data->{'TOPIC_ID'};p=$data->{'POST_ID'}'>$Topic::lang->{'snitch_geezer_to_a_copper'}</a></span>~;
}

sub Show_attachments {
    my $data = shift;

    return qq~
    <br><br><img src="$iB::INFO->{'MIME_IMG'}/$data->{'IMG'}" border='0' alt=''><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Attach;ID=$data->{'ID'};f=$data->{'FORUM'};t=$data->{'TOPIC'};p=$data->{'POST'}" target='_blank'>$Topic::lang->{'attach_dl'} [ $data->{'NAME'} ]</a>
    <br>$Topic::lang->{'attach_hits'}: $data->{'HITS'}
    ~;
}

sub Show_attachments_img {
    my $data = shift;

    return qq~<br><br>$Topic::lang->{'pic_attach'}<br><img src="$iB::INFO->{'UPLOAD_URL'}/$data->{'NAME'}" border='0' alt="$Topic::lang->{'pic_attach'}">~;
}


sub Mod_Panel {
my $data = shift;

return qq~
    <br>
    <table cellpadding='3' cellspacing='1' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
        <tr>
          <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='center'><b>$Topic::lang->{'moderation_ops'}</b><br>$data</td>
        </tr>
    </table>
~;
}

sub mod_cp_link {
my $data = shift;
return qq~
<br>[ <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModCP;f=$data'>$Topic::lang->{'mod_cp'}</a> ]
~;
}


sub TableFooter {
my $data = shift;

return qq~
 <a name="bottom"></a>
   <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
      <tr>
          <td>
            <table cellpadding='0' cellspacing='1' border='0' width='100%'>
              <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}'>
                  <table border='0' width='100%' cellspacing='0' cellpadding='0' bgcolor='$iB::SKIN->{'TITLEBACK'}'>
                    <tr>
                      <td valign='middle' align='left' id='titlemedium'>&nbsp;&nbsp;$Topic::lang->{'topic_stats'}</td>
                      <td valign='middle' align='right' id='titlemedium'>&lt; <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ST;f=$data->{'FORUM'}->{'FORUM_ID'};t=$data->{'TOPIC'}->{'TOPIC_ID'};view=old' class='titlemedium'>$Topic::lang->{'t_old'}</a> | <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ST;f=$data->{'FORUM'}->{'FORUM_ID'};t=$data->{'TOPIC'}->{'TOPIC_ID'};view=new' class='titlemedium'>$Topic::lang->{'t_new'}</a> &gt;&nbsp;&nbsp;</td>
                    </tr>
                   </table>
                </td>
              </tr>
            </table>
         </td>
      </tr>
</table> 
<br>
<table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
  <tr>
    <td valign='middle' width='50%' nowrap align='left'>$data->{'TOPIC'}->{'SHOW_PAGES'}</td>
    <td valign='middle' width='50%' nowrap align='right'>$data->{'TOPIC'}->{'REPLY_BUTTON'}&nbsp;<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Post;CODE=00;f=$data->{'FORUM'}->{'FORUM_ID'}" title='$Topic::lang->{'start_new_topic'}'>$iB::SKIN->{'A_POST'}</a>&nbsp;$data->{'TOPIC'}->{'POLL_BUTTON'}</td>
  </tr>
 </table>
<br>
<table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
  <tr>
    <td valign='middle' align='right'>$data->{'FORUM'}->{'JUMP'}</td>
  </tr>
 </table>
<br>
<table cellpadding='0' cellspacing='0' border='0' width='50%' align='center'>
  <tr>
    <td valign='middle' align='center'><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Subs;f=$data->{'FORUM'}->{'FORUM_ID'};t=$data->{'TOPIC'}->{'TOPIC_ID'}">$iB::SKIN->{'A_SUBSCRIBE'}</a></td>
    <td valign='middle' align='center'><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Forward;f=$data->{'FORUM'}->{'FORUM_ID'};t=$data->{'TOPIC'}->{'TOPIC_ID'}">$iB::SKIN->{'A_FORWARD'}</a></td>
    <td valign='middle' align='center'><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Print;f=$data->{'FORUM'}->{'FORUM_ID'};t=$data->{'TOPIC'}->{'TOPIC_ID'}">$iB::SKIN->{'A_PRINT'}</a></td>
  </tr>
  <tr>
    <td valign='middle' align='center'><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Subs;f=$data->{'FORUM'}->{'FORUM_ID'};t=$data->{'TOPIC'}->{'TOPIC_ID'}">$Topic::lang->{'track_topic'}</a></td>
    <td valign='middle' align='center'><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Forward;f=$data->{'FORUM'}->{'FORUM_ID'};t=$data->{'TOPIC'}->{'TOPIC_ID'}">$Topic::lang->{'forward'}</a></td>
    <td valign='middle' align='center'><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Print;f=$data->{'FORUM'}->{'FORUM_ID'};t=$data->{'TOPIC'}->{'TOPIC_ID'}">$Topic::lang->{'print'}</a></td>
  </tr>
</table>
~;

}


1;
