package ProfileWords;


sub new {
  my $pkg = shift;
  my $obj = {
   
#+----------------------------------------------------------------------
#| Do Not remove or edit anything above this line!
#| Only Edit the words on the right of the => arrow
#+----------------------------------------------------------------------

# RC 3
M_1 => 'Jan.',
M_2 => 'Feb.',

M_3 => 'Mar.',
M_4 => 'April',

M_5 => 'May',
M_6 => 'June',

M_7 => 'July',
M_8 => 'Aug.',

M_9 => 'Sep.',
M_10=> 'Oct.',

M_11=> 'Nov.',
M_12=> 'Dec.',

D_0 => 'Sun',
D_1 => 'Mon',
D_2 => 'Tue',
D_3 => 'Wed',
D_4 => 'Thur',
D_5 => 'Fri',
D_6 => 'Sat',
#


#+---------
# Added by Infection

b_date                  => "Birthday Date",

#
#+--------


registration_process    => "Email address change request",
thank_you               => "Thank you",
auth_text               => "Your Email address change request has been processed.<br><br>The board administrator has chosen to require validation for all email addresses. Within the next 10 minutes (usually instantly) you'll receive an email with instructions on the next step.<br>The email has been sent to",

no_photo            => "[ No Personal Photograph ]",
change_email        => "Email Address Change request",
send_email          => "Send <# NAME #> an email",
personal_header     => "Statistics and Personal Information for <# NAME #>",
contact_header      => "Contact Details",

send_pm             => "Click here to send <# NAME #> a Private Message",
add_book            => "Click here to add <# NAME #> to your contact book",

hidden_email        => "<# NAME #> has chosen to keep his/her email address private",

no_information      => "<i>No Information Entered</i>",

registration_date   => "Registration Date",
member_level        => "Member Level",
total_posts         => "Total Posts",
post_average        => "Post Average",
per_day             => "posts per day",
last_modification   => "Last Profile Update",

location            => "Location",
interests           => "Interests",
home_page           => "Home Page",
signature           => "Signature",

email_address       => "Email Address",
yahoo_name          => "Yahoo Identity",
msn_name            => "MSN Identity",
icq_number          => "ICQ Number",
aol_name            => "AOLAIM Name",


no_posts            => "Member has yet to post",
profile_edited      => "Your profile has been edited",

viewing_profile     => "Viewing member profile",




#+----------------------------------------------------------------------
#| Do Not remove or edit anything below this line!
#+----------------------------------------------------------------------
  };

  bless $obj, $pkg;
  return $obj;
}




1;

__END__
