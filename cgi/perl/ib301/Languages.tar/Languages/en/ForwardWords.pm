package ForwardWords;


sub new {
  my $pkg = shift;
  my $obj = {
   
#+----------------------------------------------------------------------
#| Do Not remove or edit anything above this line!
#| Only Edit the words on the right of the => arrow
#+----------------------------------------------------------------------



to_name                     => "Send to (Person's Name):",
to_email                    => "Send to (Email Address):",
subject                     => "Subject",
message                     => "Message",
submit_send                 => "Send Email",
logged_in                   => "Logged in as:",

send_text                   => "I thought you might be interested in reading this web page: <#THE LINK#>\n\nFrom,\n\n<#USER NAME#>",
title                       => "Send a page to a friend",

redirect                    => "The email has been sent",












#+----------------------------------------------------------------------
#| Do Not remove or edit anything below this line!
#+----------------------------------------------------------------------
  };

  bless $obj, $pkg;
  return $obj;
}




1;

__END__
