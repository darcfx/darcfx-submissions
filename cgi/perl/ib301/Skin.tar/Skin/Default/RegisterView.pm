package RegisterView;


sub ShowForm {
my $data = shift;


return qq~

    <script language='javascript'>
    <!--
    function Validate() {
        // Check for Empty fields
    
        if (document.REG.UserName.value == "" || document.REG.PassWord.value == "" || document.REG.PassWord_Check.value == "" || document.REG.EmailAddress.value == "") {
            alert ("$Register::lang->{'js_blanks'}");
            return false;
        }

        // Have we checked the checkbox?

        if (document.REG.agree.checked == true) {
            return true;
        } else {
            alert ("$Register::lang->{'js_no_check'}");
            return false;
        }
    }
    //-->
    </script>
     <br>
     <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='REG' onSubmit='return Validate()'>
     <input type='hidden' name='act' value='Reg'>
     <input type='hidden' name='CODE' value='02'>
     <table cellpadding='0' cellspacing='4' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
     <tr>
        <td valign='middle' align='left'>$Register::lang->{'reg_header'}</b><br><br>$data->{'TEXT'}</td>
     </tr>
     </table>
     <br>
     <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='3' cellspacing='1' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' valign='left' colspan='2' id='titlelarge'>$Register::lang->{'complete_form'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%'>$Register::lang->{'user_name'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' size='32' maxlength='64' name='UserName' class='forminput'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='40%'>$Register::lang->{'pass_word'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'><input type='password' size='32' maxlength='32' name='PassWord' class='forminput'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%'>$Register::lang->{'re_enter_pass'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='password' size='32' maxlength='32' name='PassWord_Check' class='forminput'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='40%'>$Register::lang->{'email_address'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'><input type='text' size='32' maxlength='50' name='EmailAddress' class='forminput'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%' valign='top'>$Register::lang->{'terms_service'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>
                    <textarea cols='50' rows='12' wrap='soft' name='Post' class='textinput' style='font-size:10px'>$data->{'RULES'}</textarea>
                    <br><br><b>$Register::lang->{'agree_submit'}</b>&nbsp;<input type='checkbox' name='agree' value='1'>
                </td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='center' colspan='2'>
                <input type="submit" value="$Register::lang->{'submit_form'}" class='forminput'>
                </td></tr></table>
                </td></tr></table>
                </form>
~;
}


sub show_dumb_form {
my $data = shift;


return qq~

    <script language='javascript'>
    <!--
    function Validate() {
        // Check for Empty fields
    
        if (document.REG.EmailAddress.value == "" || document.REG.SID.value == "") {
            alert ("$Register::lang->{'js_blanks'}");
            return false;
        }

    }
    //-->
    </script>
     <br>
     <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='REG' onSubmit='return Validate()'>
     <input type='hidden' name='act' value='Reg'>
     <input type='hidden' name='CODE' value='03'>
     <table cellpadding='0' cellspacing='4' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
     <tr>
        <td valign='middle' align='left'><b>$Register::lang->{'dumb_header'}</b><br><br>$Register::lang->{'dumb_text'}</td>
     </tr>
     </table>
     <br>
     <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='3' cellspacing='1' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'} valign='left' colspan='2' id='titlelarge'>$Register::lang->{'complete_form'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%'>$Register::lang->{'dumb_code'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='password' size='32' maxlength='32' name='SID' class='forminput'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='40%'>$Register::lang->{'dumb_email'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'><input type='text' size='32' maxlength='50' name='EmailAddress' class='forminput'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='center' colspan='2'>
                <input type="submit" value="$Register::lang->{'dumb_submit'}" class='forminput'>
                </td></tr></table>
                </td></tr></table>
                </form>
~;
}



sub show_rules {
my $rules = shift;

return qq~

   <!-- Show Board Rules -->
    <br>
     <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='3' cellspacing='1' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' valign='left' id='titlelarge'>$Register::lang->{'board_rules'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$rules->{'RULES_TEXT'} <br><br>&gt;&gt;<a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Login;CODE=00'>$Register::lang->{'intro_proceed'}</a></td>
               </tr>
               </table>
            </td>
      </tr>
   </table>
   <!-- End Board Rules -->

~;

}

sub show_preview {
my $member = shift;

return qq~
     <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='3' cellspacing='1' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' valign='left' id='titlelarge'>$Register::lang->{'registration_process'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$Register::lang->{'thank_you'} $member->{'MEMBER_NAME'}. $Register::lang->{'preview_reg_text'}</td>
                </tr>
                </table>
            </td>
        </tr>
    </table>

~;
}


sub show_authorise {
my $member = shift;

return qq~
     <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='3' cellspacing='1' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' valign='left' id='titlelarge'>$Register::lang->{'registration_process'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$Register::lang->{'thank_you'} $member->{'MEMBER_NAME'}. $Register::lang->{'auth_text'}  $member->{'MEMBER_EMAIL'}</td>
                </tr>
                </table>
            </td>
        </tr>
    </table>

~;
}

1;
