package LostpassWords;


sub new {
  my $pkg = shift;
  my $obj = {
   
#+----------------------------------------------------------------------
#| Do Not remove or edit anything above this line!
#| Only Edit the words on the right of the => arrow
#+----------------------------------------------------------------------

nav_title   => "Request Log in details",
dont_email  => "Please don't email the board administrator requesting to email you your password",
title       => "Please read the following instructions carefully",
text_a      => "As this bulletin board encrypts all user passwords upon registration, no one apart from you knows your 'real' password. Therefor you must follow these steps to have your password reset and emailed to you.",

step_a      => "Enter the member name you registered with now",
step_a_txt  => "Your registered member name",

step_b      => "Check your mail",
step_b_txt  => "An email will be sent asking for confirmation to reset your password. This is a security measure to ensure that no one is trying to gain access to your account",

step_c      => "Validate the email",
step_c_txt  => "In the email you'll receive a link a code to cut and paste into a form to validate the request.",

step_d      => "Check your mail, again",
step_d_txt  => "If the unlock code validates, then you'll be emailed your login name and new password. After this step you may change your password in your control panel under 'Modify Account'",

submit_form => "Send the confirmation email",
submit_b    => "Process",

unlock_text => "Please enter the unlock code you received in the email",

email_subject => "Request Login Details (Part One)",

email_subject_b => "Request Login Details (Part Two)",

first_email  =>  "The first email has been sent",

first_email_txt => "The email has been sent containing the link that will validate your request. Please check your email account now before proceeding",

second_email  =>  "Your details have been sent!",

second_email_txt => "The validation process was successful. An email has been sent containing your new password and original Log-in name.",



#+----------------------------------------------------------------------
#| Do Not remove or edit anything below this line!
#+----------------------------------------------------------------------
  };

  bless $obj, $pkg;
  return $obj;
}




1;

__END__
