package MessengerWords;


sub new {
  my $pkg = shift;
  my $obj = {
   
#+----------------------------------------------------------------------
#| Do Not remove or edit anything above this line!
#| Only Edit the words on the right of the => arrow
#+----------------------------------------------------------------------

# Added GOLD

read_rec_title    => "Read Receipt:",
read_rec_text     => "Original message sent on:",
posted            => "Posted",
read_rec_notify   => "Get notified when this message is read",
c_msg_total       => "You have <#NUM#> total messages in all your folders.",
c_msg_info        => "<br>You can receive and store another <#NUM#> messages until your folders are full.",
c_msg_full        => "<br><b>WARNING: YOUR FOLDERS ARE FULL<b><br>You MUST delete some saved messages in your inbox or folders before you can receive any more private messages",
mem_read_msg      => "has read this message",

##

splash          => q|Summary|,
in_box          => q|Inbox|,
out_box         => q|Outbox|,
contact         => q|Address Book|,
prefs           => q|Preferences|,
send            => q|Send New Message|,

member_name     => q|Member Name|,
member_options  => q|Options|,
member_added    => q|Member has been added to your address book|,
member_add      => q|Add a member|,
submit_address  => q|Add this member to my address book|,
submit_address_edit => "Edit this entry",
add_to_book     => "Add to Address Book",
saved_sent_msg  => "Sent: ",

auto_sent_add   => "Add a copy of this message to my sent items folder",

can_contact     => "This member can message you",
cannot_contact  => "This member cannot message you",

yes             => q|Yes|,
no              => q|No|,
enter_block     => q|Options|,
delete          => q|Delete|,
edit            => "Edit",
enter_a_name    => q|Members name|,
enter_desc      => q|Enter a short description|,
member_edit     => "You may edit this address book entry.",

address_title   => q|Your Address Book|,
address_text    => q| this is where you can add/delete and edit members to your address book, to make it easier to send messages to your favourite members, you can also choose which members to block from sending you private messages.|,
address_current => q|Members already in your list|,
address_none    => q|You have no members in your address book at the moment|,
allow_msg       => "Allow this member to message you?",
prefs_title     => q|Your Preferences|,
prefs_text      => q|This is where you can set up your messenger preferences|,
cannot_remove   => "Cannot Remove",
sent_title      => q|Your Message has been sent|,

sent_text       => q|Thanks <#FROM_MEMBER#>, your message "<#MESSAGE_TITLE#>" has been sent to <#TO_MEMBER#>. They will now be informed that they have a new message.|,
sent_url        => q|Click here to return to your messenger|,

send_title      => q|Send a new message|,
send_header     => q| you can choose from the list of stored names from your address book, or enter the name of the member you wish to message|,
to_whom         => q|Recipients Name|,

address_list    => q|<b>Choose from your address book<b>|,
enter_name      => q|<b><u>OR</u> Enter the members name here</b>|,
enter_message   => q|Enter your message|,

button_spell    => q|Spell Check|,
button_preview  => q|Preview|,
submit_send     => q|Send Message|,

max_msg         => q|Maximum message size is <#MAX_MSG_SIZE#> k|,
msg_title       => q|<b>Message Title</b>|,
msg_body        => q|<b>Message</b>|,

goto_folder     => "Go to folder:",
goto_submit     => "Go!",

dir_title     => q|Current Messenger Folder:|,
dir_header    => q| this is where all your messages are stored. You can read, delete, reply and save messages here.|,

message_title   => q|Message Title|,
message_from    => q|From|,
message_date    => q|Date|,
message_options => q|Options|,
message_read_state      => q|Read?|,

your_options    => q|Your Options|,

msg_deleted     => q|That message has been deleted|,

icon_title      => q|Icon Legend|,
icon_save       => q|Save Message|,
icon_unread     => q|Unread messages|,
icon_read       => q|Read messages|,
icon_delete     => q|Delete message|,
icon_addmem     => q|Add member to address book|,
icon_reply      => q|Reply to this message|,

sort_by         => q|Sort Messages by|,
sort_submit     => q|Sort Messages!|,

viewing_message => q|Viewing Message:|,
no_reply        => q|You haven't replied to this message|,
message_from    => q|This message is from|,
#+-----------------------
# Added by Infection
message_to      => q|This message was sent to|,
#+-----------------------
sent_on         => q|Sent on|,


current_sort    => q|Messages are currently sorted by: |,
from_name       => q|Member|,
from_date       => q|Date (oldest first)|,
from_date_new       => q|Date (newest first)|,
from_title      => q|Message Title|,

inbox_no_msg    => q|This folder is currently empty|,


move_button     => "move to",
delete_button   => "delete",
move_or_delete  => "or",
selected_msg    => "the selected messages",
no_msg_chosen   => "You did not select any messages. You select them by clicking on the checkbox on the far right of each entry",



other           => q|Other|,
address_list_empty   => q|Address list empty|,

inbox_url       => q|Go to your inbox...|,

last_txt        => q|The newest message is from <#LAST_FROM_NAME#> entitled <#LAST_MSG_TITLE#>, which was sent on <#LAST_SENT#>|,

in_box_help     => q|This is where all your messages go when they are sent to you, it works just the same as your email 'inbox'|,
contact_help    => q|This is where you can add/delete and edit members in your Address book. This allows you to store your friends membernames for quick reference|,
prefs_help      => q|You may set up your messenger preferences from here.|,
send_help       => q|This is where you can send private messages to other members from.|,

welcome         => q|Welcome to your messenger|,
welcome_txt     => q| this is your private communications center. All of your messages sent and received are private. Not even the board administrator has direct access to your messages. Please respect the privacy of other members at all times.|,
msg_no_new      => q|You have no new messages|,
msg_new         => q|<b>You have <#NEW_MESSAGES#> new messages!</b>|,
new_message     => q|New Message Status|,

quick_help      => q|A brief overview of you messenger|,



prefs_title     => "Messenger Preferences",

prefs_text      => " you can set up your messenger preferences from here. You can edit the names of your current virtual directories and add more.",
prefs_text_a    => "You may edit the names, or delete the name to delete this virtual directory. Please note, that all messages in this directory will be lost if you delete this directory",
prefs_text_b    => "You may add extra directories. You do not have to use all the input boxes.",

prefs_current   => "Current Virtual Directories",

prefs_new   => "Add New Virtual Directories",

prefs_submit => "Submit Changes",

t_welcome    => "Welcome to your messenger",
t_title      => "Your Messenger",
t_book => "Address Book",

m_joined          =>  "Joined:",
m_group           =>  "Group:",
m_posts           =>  "Posts:",

#+----------------------------------------------------------------------
#| Do Not remove or edit anything below this line!
#+----------------------------------------------------------------------
  };

  bless $obj, $pkg;
  return $obj;
}




1;

__END__
