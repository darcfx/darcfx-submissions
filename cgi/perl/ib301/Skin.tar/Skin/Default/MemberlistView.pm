package MemberlistView;

sub start {

return qq~
          <table cellpadding='0' cellspacing='4' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
            <tr>
              <td valign='middle' align='center'>
              <form action='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Members' method='POST'>
              <input type='hidden' name='act' value='Members'>
              <input type='hidden' name='s'   value='$iB::SESSION'>
              $Memberlist::lang->{'sorting_text'}&nbsp;&nbsp;<input type='submit' value='$Memberlist::lang->{'sort_submit'}' class='forminput'>
              </form>
              </td>
            </tr>
          </table>
          <br>
~;
}

sub Page_header {
my $links = shift;

return qq~

          <table cellpadding='0' cellspacing='4' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
            <tr>
              <td valign='middle' align='left'>$links->{'SHOW_PAGES'}</td>
            </tr>
          </table>
          <br>
       <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
              <table cellpadding='4' cellspacing='1' border='0' width='100%'>
                <tr id='titlemedium'>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' width='13%' align='left'>$Memberlist::lang->{'member_name'}</td>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' align='left' width='10%'>$Memberlist::lang->{'member_level'}</td>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' align='left' width='10%'>$Memberlist::lang->{'member_group'}</td>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' align='left' width='12%'>$Memberlist::lang->{'member_joined'}</td>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' align='center' width='10%'>$Memberlist::lang->{'member_posts'}</td>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' width='10%' align='left'>$Memberlist::lang->{'member_email'}</td>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' align='left' width='10%'>$Memberlist::lang->{'member_aol'}</td>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' align='left' width='10%'>$Memberlist::lang->{'member_icq'}</td>
                </tr>
~;

}


sub show_row {
my $member = shift;

return qq~
              <!-- Entry for $member->{'MEMBER_NAME'} -->
              <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><b><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Profile;CODE=03;MID=$member->{'MEMBER_ID'}">$member->{'MEMBER_NAME'}</a></b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$member->{'MEMBER_PIPS_IMG'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$member->{'MEMBER_GROUP'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$member->{'MEMBER_JOINED'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='center'>$member->{'MEMBER_POSTS'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='center'>$member->{'MEMBER_EMAIL'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='center'>$member->{'AOLNAME'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='center'>$member->{'ICQNUMBER'}</td>
              </tr>
              <!-- End of Entry -->
~;
        

}

sub Page_end {

return qq~

            <!-- End content Table -->
            <tr>
            <td bgcolor='$iB::SKIN->{'TITLEBACK'}' colspan='8'>&nbsp;</td>
            </tr>
            </table>
            </td>
            </tr>
            </table>
        ~;
            


}

sub no_results {

return qq~No results~;

}

sub end {
my $links = shift;

return qq~
          <br>
          <table cellpadding='0' cellspacing='4' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
            <tr>
              <td valign='middle' align='left'>$links->{'SHOW_PAGES'}</td>
            </tr>
          </table>
        ~;
}


# ====== Do not touch anything below this line ====== #

1;

