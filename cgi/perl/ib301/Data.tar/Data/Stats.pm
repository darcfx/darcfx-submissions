package Stats;


sub new {
  my $pkg = shift;
  my $obj = {
   TOTAL_REPLIES        => '0',
   TOTAL_TOPICS         => '0',
   TOTAL_MEMBERS        => '0',
   LAST_REG_MEMBER_ID   => '',
   LAST_REG_MEMBER_N    => '',

  };

  bless $obj, $pkg;
  return $obj;
}




1;
