package ModerateWords;


sub new {
  my $pkg = shift;
  my $obj = {
   
#+----------------------------------------------------------------------
#| Do Not remove or edit anything above this line!
#| Only Edit the words on the right of the => arrow
#+----------------------------------------------------------------------

## RC 3

final_rebuild => "<#DELETE_COUNT#> duplicate posts removed. The new reply counter has been set to <#REPLY_COUNT#>",

## ADDED FOR RC 1

p_deleted => "Topic Deleted",
p_pdeleted => "Post Deleted",
p_pinned   => "Topic Pinned",
p_unpinned => "Topic Unpinned",
p_opened   => "Topic Opened",
p_closed   => "Topic Closed",
p_edited   => "Topic Edited",
p_moved    => "Topic Moved",

##




t_move  => "Move Topic",
t_close => "Close Topic",
t_open  => "Open Topic",
t_edit  => "Edit Topic",
t_delete => "Delete Topic",

top_move            => "Move Topic ",
top_edit            => "Editing Topic ",
top_close           => q|Closing a topic in |,
top_open            => q|Opening a topic in |,
top_delete          => q|Deleting Topic |,
close_topic         => "<b>NOTE:</b> You do not have to post a message - it is optional",
open_topic          => "<b>NOTE:</b> You do not have to post a message - it is optional",
delete_topic        => q|Deleting Topic, only continue if you wish to delete this topic, there will be no other confirmation screens.|,
edit_topic          => "Editing Topic Details",
move_topic          => "<b>NOTE:</b> You do not have to post a message - it is optional",

post_optional       => "<b>NOTE:</b> You do not have to post a message - it is optional",

edit_f_title        => "Topic Title",
edit_f_desc         => "Topic Description",

leave_empty         => "Leave just the topic linking to the new destination",
leave_locked        => "Leave all posts w/locked topic in the source forum",
dont_leave          => "Remove the topic entry and posts from the source forum",

leave_msg           => q|Do you want to leave a message before carrying out this action? If so, add your message below. If you do not wish to leave a message and carry out this action anonymously, leave this field blank|,
leave_msg_txt       => q|Enter post here, this will be added to the topic.<br>[ Optional ]|,

enable_emo          => q|Do you wish to enable emoticons in this post?|,
enable_sig          => q|Do you wish to enable your signature in this post?|,
post_options        => q|Posting Options|,

submit_close        => q|Close this topic|,
submit_open         => q|Open this topic|,
submit_delete       => q|Delete this topic|,
submit_edit         => "Edit this topic",
submit_move         => "Move this topic",
post_icon           => q|<b>Post Icons</b>|,
post_icon_txt       => q|You may choose a post icon|,

move_from           => "Move this topic from",
delete_old          => "Source forum option:",

to                  => "to",




MOVE_TOPIC         =>  "Move this topic",
DELETE_POST        =>  "Delete Posts",
OPEN_TOPIC        =>  "Open this topic",
DELETE_TOPIC       =>  "Delete this topic",
CLOSE_TOPIC        =>  "Close this topic",
PIN_TOPIC         =>  "Pin Topics",
UNPIN_TOPIC        =>  "UnPin Topics",

moderation_ops       =>  "here are your authorised moderation options",


#+----------------------------------------------------------------------
#| Do Not remove or edit anything below this line!
#+----------------------------------------------------------------------
  };

  bless $obj, $pkg;
  return $obj;
}




1;

__END__
