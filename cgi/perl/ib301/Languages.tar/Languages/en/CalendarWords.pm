package CalendarWords;


sub new {
  my $pkg = shift;
  my $obj = {
   
#+----------------------------------------------------------------------
#| Do Not remove or edit anything above this line!
#| Only Edit the words on the right of the => arrow
#+----------------------------------------------------------------------


page_title              => "Welcome to board calendar",
page_titles             => "Board Calendar",

show                    => "Show",

prev                    => "Previous Month",
next                    => "Next Month",

mon                     => "Monday",
tue                     => "Tuesday",
wed                     => "Wednesday",
thu                     => "Thursday",
fri                     => "Friday",
sat                     => "Saturday",
sun                     => "Sunday",


#+----------------------------------------------------------------------
#| Do Not remove or edit anything below this line!
#+----------------------------------------------------------------------
  };

  bless $obj, $pkg;
  return $obj;
}




1;
