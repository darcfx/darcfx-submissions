package ForumWords;


sub new {
  my $pkg = shift;
  my $obj = {
   
#+----------------------------------------------------------------------
#| Do Not remove or edit anything above this line!
#| Only Edit the words on the right of the => arrow
#+----------------------------------------------------------------------

# RC 1 additions

mark_as_read  => "Mark this forum as read",
topic_started_on => "This topic was started:",
topic_sp_pages => "Pages",

# end additions






pm_open_new => "Open Topic (new replies)",
pm_hot_new  => "Hot Topic (new replies)",
pm_poll     => "Poll (new votes)",
pm_locked   => "Locked Topic",
pm_open_no  => "Open Topic (no new replies)",
pm_hot_no   => "Hot Topic (no new replies)",
pm_poll_no  => "Poll (no new votes)",
pm_moved    => "Moved Topic",

forum_jump  => "Forum Jump",

need_password       => "Please enter the Forum Password",
need_password_txt   => "This forum is protected by a password. Please do not attempt to enter a password unless you are authorised. All failed attempts are logged and you may have your posting rights removed upon repetitive failure.<br><br>Please ensure that your browser is capable of storing temporary cookies",
enter_pass          => "Forum Password",
f_pass_submit       => "Check my authorisation",
logged_in           => "You have been authorised to access this forum",

single_page_forum   => "&nbsp;",
multi_page_forum    => "Pages:",

showing_text        => "Showing <#MATCHED_TOPICS#> of <#TOTAL_TOPICS#> topics ",
sort_text           => "sorted by <#SORT_KEY_HTML#> in <#ORDER_HTML#> from <#PRUNE_HTML#>",

no_topics           => "No topics were found. This is either because there are no topics in this forum, or the topics are older than the current age cut-off.",

sort_by_date        => "last post date",
sort_by_poster      => "topic starter",
sort_by_replies     => "number of replies",
sort_by_views       => "number of views",
sort_by_start       => "topic start date",
sort_by_topic       => "topic title",
sort_by_last_poster => "last poster",

ascending_order     => "ascending order",
descending_order    => "descending order",


show_today          => "today",
show_5_days         => "the last 5 days",
show_7_days         => "the last week",
show_10_days        => "the last 10 days",
show_15_days        => "the last 15 days",
show_20_days        => "the last 20 days",
show_25_days        => "the last 25 days",
show_30_days        => "the last 30 days",
show_60_days        => "the last 60 days",
show_90_days        => "the last 90 days",
show_year           => "the last year",
show_all            => "the beginning",

sort_submit         => "Go!",
re_order_forum      => "Reorder this forum",

back_to_forum       => "Go back to the forum",
last_updated        => "Last Updated:",


last_post_by        => "Last Post by:",


h_topic_title       => "Topic Title",
h_topic_starter     => "Topic Starter",
h_replies           => "Replies",
h_hits              => "Views",
h_last_action       => "Last Action",





mod_cp  => "Moderators Control Panel",


#+----------------------------------------------------------------------
#| Do Not remove or edit anything below this line!
#+----------------------------------------------------------------------
  };

  bless $obj, $pkg;
  return $obj;
}




1;

__END__
