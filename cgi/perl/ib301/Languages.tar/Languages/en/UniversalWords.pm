package UniversalWords;


sub new {
  my $pkg = shift;
  my $obj = {
   
#+----------------------------------------------------------------------
#| Do Not remove or edit anything above this line!
#| Only Edit the words on the right of the => arrow
#+----------------------------------------------------------------------

#added for RC3

you_last_visit   => "You last visited on:",
you_running_time => "Your last action was on:",


## added for RC 2

code_sample  => 'Code Sample',
quote_text   => 'Quote',



## Added for RC 1
admin_login       => "Administrators Log in",
name              => "Name",
pass              => "Password",
submit_li         => "Log in",
forum_read        => "The forum has been marked as read",
cookies_flushed   => "Your ikonboard cookies have been flushed",
thanks  => "Thanks",
transfer_you   => "Please wait while we transfer you...",
stand_by  => "Please stand by...",
dont_wait  => "Or click here if you do not wish to wait",

offline_title => "Ikonboard Offline Mode",

## end additions


msg_new             => q|<#NEW_MESSAGES#> new|,
your_messenger      => q|Your messenger|,
admin_cp            => "Admin CP",
offline          => "Sorry, the boards are offline at the moment",
popup_one        => 'You have a new private message. Click OK to go to your messenger, or CANCEL to remove this prompt',
popup_two        => 'Open your messenger in a new window?\nClick OK to open a new window\nClick CANCEL to open in this window',
welcome          => 'Welcome',
your_cp           => 'Your Control Panel',
log_out           => 'Log Out',
guest_stuff       => 'Welcome Guest',
log_in            => 'Log In',
register          => 'Register',


new_posts => "New Posts",

M_1 => 'Jan.',
M_2 => 'Feb.',

M_3 => 'Mar.',
M_4 => 'April',

M_5 => 'May',
M_6 => 'June',

M_7 => 'July',
M_8 => 'Aug.',

M_9 => 'Sep.',
M_10=> 'Oct.',

M_11=> 'Nov.',
M_12=> 'Dec.',

D_0 => 'Sun',
D_1 => 'Mon',
D_2 => 'Tue',
D_3 => 'Wed',
D_4 => 'Thur',
D_5 => 'Fri',
D_6 => 'Sat',

#+----------------------------------------------------------------------
#| Do Not remove or edit anything below this line!
#+----------------------------------------------------------------------
  };

  bless $obj, $pkg;



  return $obj;
}




1;

__END__
