package Makelog;

use Carp;
use iDatabase;
use Boardinfo;

my $INFO  = Boardinfo->new();
my $db    = iDatabase->new();


sub new {
    my $pkg = shift;
    my $obj = {};
    bless $obj, $pkg;
    $obj->{'ARGS'} = { INDEX=>"",DATA=>"",@_, };
    return $obj;
}



sub add_log ($) {
    my $obj = shift;
    $db->connect('Logging/'.$obj->{'ARGS'}->{'INDEX'},$obj->{'ARGS'}->{'INDEX'});
    my $sth = $db->prepare(INSERT=>$obj->{'ARGS'}->{'DATA'},WHERE=>'at bottom');
    $sth->execute();
    $sth->done();
    $db->disconnect($sth);
}



1;

__END__
