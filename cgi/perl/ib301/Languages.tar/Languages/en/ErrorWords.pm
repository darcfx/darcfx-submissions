package ErrorWords;


sub new {
  my $pkg = shift;
  my $obj = {
   
#+----------------------------------------------------------------------
#| Do Not remove or edit anything above this line!
#| Only Edit the words on the right of the => arrow
#+----------------------------------------------------------------------

## Added GOLD

no_usepm_member  =>  "This message can not be sent because the recipient does not have permission to use the private messenger.",
calendar_not_all => "Either complete all the birthdate fields, or leave them all blank - we cannot process partial birthdates",
max_message_from => "Your Private Messenger box is full. You have reached the limit set for this board. You will need to delete some of your currently saved messages from either your inbox, or your saved items folder.",
max_message_to   => "That member's Private Messenger box is full and is unable to accept any new messages.",
too_many_emoticons => "You have posted a message with more emoticons that this board allows. Please reduce the number of emoticons you've added to the message",

## Added RC2

rp_nomsg   => "You must enter a message to the moderators",
rp_noname  => "You must enter your name before we can send this report",
rp_noemail => "You must enter a valid email address before we can send this report",


##

## ADDED FOR THE RC 1

too_many_img            => "Sorry, but you have posted more images than you are allowed to",
no_dynamic              => "Sorry, dynamic pages in the [IMG] tags are not allowed",
invalid_ext             => "You are not allowed to use that image extension on this board. A valid format is: http://www.domain.com/picture.gif, an invalid format is: http://www.domain.com/picture.one.gif",

flash_too_big           => "Please reduce the size of the flash movie you are posting",
flash_number            => "The width and height attributes of the flash movie must be numeric in value",
flash_url               => "The URL you posted for the flash movie is not valid",
no_start_polls          => "You cannot start a poll",
no_reply_polls          => "You cannot vote in this poll",

##

no_attach  => "Attachments are not allowed for this forum",

# /* Poll Errors */

poll_you_voted      => "You have already voted in this poll",
poll_none_found     => "We could not find that poll",
poll_you_created    => "You created this poll",
poll_no_guests      => "Guests cannot vote",
poll_add_vote       => "Vote!",

# /* System + Error Stuff */

error_title          => "Ikonboard Message",
error_txt            => "An error has occured",
error_back           => "Go Back",
error_not_registered => "Not Registered? ",
reg_link             => "Register Now!",
forgot_pass          => "Forgotten your password?",
pass_link            => "Click here!",
log_in               => "Not Logged in?",
log_in_now           => "Log in Now!",
log_in_yes           => "You are currently logged in as ",
log_in_no            => "You are NOT logged in",


#+----------------------------------------------------------
# /* Moderation Errors */

moderate_no_permission  => "You do not have permission to carry out that function",
forum_no_access         => "You do not have access to this forum. Are you logged in?",
move_no_forum           => "You did not choose a destination forum",
move_already_moved      => "This is the original moved topic and it can't be moved again, if you want to move it again, please choose the topic that was moved into the previous destination forum",
move_same_forum         => "You cannot move this topic into the same forum, well, you could but there wouldn't be a lot of point",
move_no_source          => "No source forum was chosen",
move_no_topic           => "That Topic is not in our Database, it's possible it was deleted",


#+----------------------------------------------------------
# /* Invite Friend Errors */

invite_no_name          =>  "You must enter your name",
invite_no_email         =>  "You must enter your email address",
invite_no_email_f       =>  "You must enter an email address for your friend",
ikonboard_error         =>  "Ikonboard Error",
go_back                 =>  "Please go back and correct this error",

#+----------------------------------------------------------
# /* Send topic to friend */

stf_no_name             => "You must enter the name of the person you are sending this page to",
stf_no_email            => "You must enter the email address of the person you are sending this page to",
stf_no_subject          => "You must enter a subject for the email",
stf_no_msg              => "You must enter a message to send",
stf_invalid_email       => "The email address you entered was of an incorrect format",



#+----------------------------------------------------------
# /* User CP Errors (Profile, Messenger, etc) */

no_msg_chosen   => "You did not select any messages. You select them by clicking on the checkbox on the far right of each entry",

no_use_messenger  =>  "You are not allowed to use the messenger feature on this board",

member_in_add_book      =>  "You already have that member stored in your address book",
end_subs_value          =>  "You must enter a numeric value for the 'End Subscription' field",
no_avatar_selected      =>  "No avatar was selected, please go back and correct this error",
incorrect_avatar        =>  "Sorry, but that is not a valid avatar",
avatar_invalid_url      =>  "Sorry, but the URL you entered for your avatar was incorrectly formatted.",
avatar_invalid_ext      =>  "Sorry, that is not a valid file extension",
no_avatar               =>  "The administrator has disabled avatars on this board",

no_msg_title            =>  "You must enter a message title",
no_msg                  =>  "You must enter a message",
no_to_member            =>  "We could not find that member in our database, please check the spelling of the name",
no_chosen_member        =>  "You didn't enter or choose a name to send the message to!",
no_such_msg             =>  "That message does not exist",
msg_blocked             =>  "This member has chosen not to be contactable by the Ikonboad Messenger",

sig_too_long            => "Your signature is too long.",
int_too_long            => "Your Interests entry is too long.",
loc_too_long            => "Your Location entry is too long.",
web_too_long            => "Your website entry is too long.",
photo_too_long          => "Your Photo field is too long.",
not_icq_number          => "That is not a valid ICQ number",
not_aol_name            => "That is not a valid AOL Identity",
not_yahoo_name          => "That is not a valid YAHOO name",
not_url_photo           => "That is not a valid URL for your Photo. We do not allow dynamic pages in the IMG tags",
cannot_remove_dir       => "You cannot remove that virtual directory",

no_sub_id               => "Sorry, we could find that topic subscription",

cant_use_feature        => "You are not allowed to use this part of the board",

#+----------------------------------------------------------
# /* Authentication Errors */

no_username             =>  "You must enter a username",
username_short          =>  "The username you entered was too short",
username_long           =>  "The username you entered was too long",
pass_blank              =>  "Your password field was not complete",
pass_no_match           =>  "The Two New Passwords do not match",
pass_too_long           =>  "The password entered was too long",
pass_too_short          =>  "The password entered was too short",
memid_blank             =>  "Your member Id field was not complete",
memid_too_short         =>  "Your member Id field was too short",
memid_too_long          =>  "Your member Id field was too long",
name_too_long           =>  "The username you entered was too long",
name_too_short          =>  "The username you entered was too short",
referrer_fail           =>  "Ikonboard does not allow offsite posting.",
you_are_banned          =>  "Sorry, you are not permitted to use this board",
server_too_busy         =>  "Sorry, the server is too busy to handle your request, please try again in a moment",

#+----------------------------------------------------------
# /* Registration Errors - Email Verification Errors - Log in Errors */

membername_none         =>  "Sorry, we could not find an account with that membername",
email_exists            =>  "That email address cannot be used as it is already in our records",
already_sub             =>  "You are already subscribed to this topic",
no_email                =>  "You must enter an email address to request your log-in details",
no_email_stored         =>  "Sorry, but we could not find that email address in our records",
request_hack            =>  "Some of the data did not match our records, we are treating this as a possible hack attempt!",
request_passed          =>  "Sorry, we could not validate that request. If it was made more than 90 minutes ago, please start the procedure over again.",
request_error           =>  "An error occured, not all of the required fields were sent from the validation link. Please ensure that they whole link was entered, it's possible that your email clients auto-wrapper cut the link in half. Please try again.",
no_register             =>  "Sorry, the board administrator has switched off Registrations",
invalid_email           =>  "You must enter a VALID email address",
already_logged_in       =>  "That user is already logged in!",
not_logged_in           =>  "You are not logged in",
user_exists             =>  "We already have a member by that name, please choose another",
data_incorrect          =>  "One of the data fields contained the incorrect type of data, please double check the URL",
not_authorised          =>  "Sorry, but you have yet to validate your user account. Please check the email account you registered with.",

#+----------------------------------------------------------
# /* Posting Errors */

posting_off             =>  "Your posting permissions have been removed",
no_topic_title          =>  "You must enter a topic title",
topictitle_too_long     =>  "The topic title you entered is too long",
no_post                 =>  "You must enter a post",
no_guest_posting        =>  "Sorry, but the board administrator has disabled guest posting in this forum, if you are a registered member - please log in",
locked_topic            =>  "Sorry, this topic has been locked",
forum_off               =>  "Sorry, but this forum has been disabled",
no_guest_new_topics     =>  "sorry, but the board administrator does not allow guests to start new posts in this forum. If you are a registered member please log in",
not_op                  =>  "Sorry, you do not have permission to edit that message",
no_replies              =>  "Sorry, you do not have permission to reply to that topic",
no_starting             =>  "Sorry, you do not have permission to start a topic in this forum",
no_poll_reply           =>  "The poll creator has created this as a vote-only topic",
illegal_img_ext         =>  "Sorry, but you cannot use that file extension for an image tag",
too_many_images         =>  "Sorry, but your post contains more the allowed number of images",
flash_number            =>  "The height and width attributes of the flash tag have to be a number",
flash_url               =>  "That is not a valid Flash URL",
flash_too_big           =>  "Sorry, but the flash movie you posted was either too large in height, width or both",
flood_control           =>  "Sorry, the board administrator has flood controlled activated. Please wait at least <#VAR#> seconds before posting again",
forum_no_access         =>  "Sorry, you do not have reading permissions on this forums",
post_too_long           =>  "Sorry, your post was too long, please reduce it",
#+----------------------------------------------------------
# /*   Session.pm  */

user_agent_no_match     =>  "You are using a different computer than the one you logged in under.",
session_id_no_match     =>  "The Session ID saved is not the same as the one in your cookie",
mem_id_no_match         =>  "The member ID cookie is not the same as the data entered",
password_no_match       =>  "The password is not the same as the data entered",
invalid_login           =>  "Invalid log in. Either your password or your username was not correct. Please go back and double check the information you entered. Please remember that usernames and passwords are case sensitive, so 'PaSSwOrD' is different from 'password'",
ip_no_match             =>  "Your IP address has changed, please log back in again",
mem_id_wrong            =>  "Sorry, but your Member ID is not in the correct format",
session_id_no_match     => "Fatal Error, your session ID cookie does not match any of the data!",
session_id_error        =>  "Sorry, we could not validate your session, please try re-logging  back in",
wrong_name              =>  "Sorry, we could not find a membername matching your input (this could have been from a log in form, or a session authentication).",
wrong_pass              =>  "The password you entered does not match the password we have for that member. Remember that passwords are case sensitive",

#+----------------------------------------------------------
# /* General Errors */

missing_files           =>  "Sorry, some required files are missing, if you intended to view a topic, it's possible that it's been moved or deleted. Please go back and try again.",
cookie_error            =>  "Sorry, there is a cookie error, please re-log in",
incorrect_use           =>  "Incorrect use of one of the Ikonboard files",
no_action               =>  "Please don't adjust the generated URLs. If you came here in error, please go back and try again",
wrong_pass              =>  "Sorry, that was the incorrect password",
no_user                 =>  "Sorry, we could not find that member",
poss_hack_attempt       =>  "We are treating that action as a possible hack attempt, this action will be logged and the board administrator will be informed via email",
no_permission           =>  "Permission denied",
no_such_user            =>  "There isn't a member with that name or ID number",
private_email           =>  "That member has chosen to keep their email address private",
no_subject              =>  "You did not enter a subject for the email",
no_message              =>  "You did not enter a message for the email",
subject_long            =>  "The email subject was too long",

no_view_board           =>  "You do not have permission to view this board",
no_view_topic           =>  "You do not have permission to view this topic",

no_newer                =>  "There are no topics newer than this one",
no_older                =>  "There are no topics older than this one",

no_icq                  =>  "That member does not have a valid ICQ Number",
no_aol                  =>  "That member does not have a valid AOL Name",
flood_control           =>  "Flood control is enabled on this board, please wait 25 seconds before replying or posting a new topic",

please_complete_form  => "Please complete the form fully before submitting it",

#+----------------------------------------------------------
# /* Guest Errors */

not_registered          =>  "Guests cannot peform this action, if you are a registered member, please log-in",
guest_abuse             =>  "We could not determine your posting status. Please try logging back in, or if you are a guest - please try again",
no_guests               =>  "Sorry, but this function isn't available to guests",
profile_guest           =>  "We could not find this member in our database, it's possible that the member has been removed.",

#+----------------------------------------------------------
# /* Help Errors */

search_no_input         => "You must enter a keyword(s) to search by!",
no_search_id            => "No search file ID number was recorded, please try again",

#+----------------------------------------------------------
# /* Forum Errors */

no_rules_show           => "There isn't any FAQ/Rule files for this forum",

#+----------------------------------------------------------
# /* Search Errors */

no_search_words         => "You did not enter any keywords to search by",
no_search_forum         => "You did not choose any forums to search in!",
no_search_results       => "Sorry, but we did not find any matches",

#+----------------------------------------------------------------------
#| Do Not remove or edit anything below this line!
#+----------------------------------------------------------------------
  };

  bless $obj, $pkg;
  return $obj;
}




1;
