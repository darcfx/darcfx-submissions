package PostWords;


sub new {
  my $pkg = shift;
  my $obj = {

# added GOLD

too_many_emoticons => "You have posted a message with more emoticons that this board allows. Please reduce the number of emoticons you've added to the message",
stat_max_emo            => "Maximum emoticons per post: ",

##


## new for RC 2

jscode_text_enter_url      => "Enter the complete URL for the hyperlink",
jscode_text_enter_url_name => "Enter the title of the webpage",
jscode_text_enter_image    => "Enter the complete URL for the image",
jscode_text_enter_email    => "Enter the email address",
jscode_text_enter_flash    => "Enter the URL to the Flash movie.",
jscode_text_flash_width    => "Enter the Width of the movie in pixels. Maximum Width= ",
jscode_text_flash_height   => "Enter the Height of the movie in pixels. Maximum Height= ",
jscode_text_code           => "Usage: [CODE] Your Code Here.. [/CODE]",
jscode_text_quote          => "Usage: [QUOTE] Your Quote Here.. [/QUOTE]",
jscode_error_no_url        => "You must enter a URL",
jscode_error_no_title      => "You must enter a title",
jscode_error_no_email      => "You must enter an email address",
jscode_error_no_width      => "You must enter a width",
jscode_error_no_height     => "You must enter a height",

poll_null_vote             => "View Results (Null Vote)",
poll_viewing_results       => "Viewing poll results",
##



## New for RC 1
js_max_length  => "The maximum allowed length is",
js_characters  => "characters",
js_used        => "So far, you have used",
js_post        => "Post",
js_current     => "Current Characters",
js_no_message  => "You must enter a message to post!",

##

poll_s_choices          => "Poll choices",
poll_s_votes            => "Votes",
poll_s_stats            => "Statistics",
poll_s_q                => "Question",
poll_s_total            => "Total Votes",

poll_vote_added         => "Your vote has been added",
poll_vote_created       => "Your poll has been created",

poll_choices            => "<b>Poll Choices</b><br>Please put one answer per line. [ Maximum 10 answers ]",
poll_only               => "<b>Make Poll Only?</b><br>(No replies allowed)",
top_txt_poll            => "Creating a Poll",
submit_poll             => "Add my Poll",
poll_you_voted          => "You have already voted in this poll",

poll_you_created        => "You created this poll",
poll_no_guests          => "Guests cannot vote",
poll_add_vote           => "Vote!",

#/* ERRORS */

no_poll_data            => "There is are no poll questions, that makes for a rubbish poll!",
poll_to_many            => "You have more than 10 poll choices, please reduce them",
poll_not_enough         => "A Poll is a choice, 1 entry is not a choice",

stat_max_img            => "Maximum images per post: ",
stat_max_emo            => "Maximum emoticons per post: ",
stat_flash              => "Flash Movie posting: ",
stat_flash_w            => "Maximum Flash movie width: ",
stat_flash_h            => "Maximum Flash movie height: ",
stat_allow_img          => "[IMG] tag: ",
stat_dyn_img            => "Dynamic image posting: ",

enabled                 => "Enabled",
disabled                => "Disabled",
unlimited               => "( Not restricted )",

post_rules              => "Posting Rules",

ib_code_buttons         => "iB Code Buttons",


too_many_img            => "Sorry, but you have posted more images than you are allowed to",
no_dynamic              => "Sorry, dynamic pages in the [IMG] tags are not allowed",
invalid_ext             => "You are not allowed to use that image extension on this board. A valid format is: http://www.domain.com/picture.gif, an invalid format is: http://www.domain.com/picture.one.gif",

flash_too_big           => "Please reduce the size of the flash movie you are posting",
flash_number            => "The width and height attributes of the flash movie must be numeric in value",
flash_url               => "The URL you posted for the flash movie is not valid",

non_quotes              => "The number of opening quote tags does not match the number of closing quote tags",
upload_title            => "File Attachments",
upload_text              => "You may attach a file to this message.<br>Maximum file size (in bytes):",
upload_to_big           => "The file you requested to upload was too big",
invalid_mime_type       => "You cannot upload this type of file",
no_file_ext             => "Please ensure that the file you are attempting to upload has a file extension",

#/* Other stuff */

buttons_js              => "Click or use the access key once to open and again to close",
click_smilie            => "Clickable Smilies",
no_topic_title          => "You must enter a topic title longer than 2 characters",
topic_title_long        => "Topic titles cannot be longer than 50 characters",
errors_found            => "THE FOLLOWING ERROR(S) WERE FOUND",
no_post                 => "You must enter a post",          

alert_flash             => q|You must enter a parameter for all the values!|,

posting_new_topic       => q|Posting New Topic|,
new_post_added          => q|Your new post has been added|,
replying_in             => q|Replying in|,
reply_added             => q|Your reply has been added|,

email_address           => q|Your registered email address|,

ib_on                   => q|iB Code is <b>on</b>|,
ib_off                  => q|iB Code is <b>off</b>|,

html_on                 => q|Posting HTML is <b>allowed</b>|,
html_off                => q|Posting HTML is <b>NOT</b> allowed|,

quoting_post            => q|Quoting a Post in |,
editing_post            => q|Editing Post |,
post_edited             => q|Your Post has been edited|,

please_log_in           => "You are not authorised to view this forum",

check_length            => "Check Message Length",
max_length              => "Maximum message length in characters:",

submit_new              => q|Post New Topic|,
submit_reply            => q|Add Reply|,
submit_edit             => q|Submit Modified Post|,

top_txt_new             => q|Post a new topic in|,
top_txt_reply           => q|Replying to|,
top_txt_edit            => q|Editing a post in|,

button_spell            => q|Spell Check|,
button_preview          => q|Preview Post|,

reg_username            => q|Your Registered Username|,
guest_name              => q|Enter your Name|,

post_preview            => q|Post Preview|,

topic_title             => q|Topic Title|,
topic_desc              => q|Topic Description|,
post                    => q|Enter your Post|,
posting_cond            => q|Posting Abilities|,

original_post           => q|Original Post|,
post_to_quote           => q|Original Post to Quote|,
post_to_quote_txt       => q|You may edit the post you are quoting here|,
options                 => q|Options|,
post_options            => q|Post Options|,
enable_emo              => q|Do you wish to <b>enable</b> emoticons for this post?|,
enable_sig              => q|Do you wish to <b>enable</b> your signature for this post?|,

last_posts              => q|Last 10 Posts [ In reverse order ]|,
posted_on               => q|Posted on|,
review_topic            => q|Review the complete topic (launches new window)|,

email_title             => q|Reply to Topic Notification|,

post_icon               => q|<b>Post Icons</b>|,
post_icon_txt           => q|You may choose a post icon|,


# New for BETA 7

moderate_post     => "Your post will be previewed by a moderator before it is added to this topic",
moderate_topic    => "Your new topic will be previewed by a moderator before it is added into this forum",

help_cards => "Help Cards:",



#+----------------------------------------------------------------------
#| Do Not remove or edit anything below this line!
#+----------------------------------------------------------------------
  };

  bless $obj, $pkg;
  return $obj;
}




1;

__END__
