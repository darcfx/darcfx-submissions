// Javascript Code
// Written by Matthew Mecham unless otherwise stated.
// Copyright (c) 2001 Ikonboard.com
// <http://www.ikonboard.com>

// Start the subroutines.


var Quote = 0;
var Bold  = 0;
var Italic = 0;
var Underline = 0;
var Code = 0;


// IBC Code stuff
var text_enter_url      = "Enter the complete URL for the hyperlink";
var text_enter_url_name = "Enter the title of the webpage";
var text_enter_image    = "Enter the complete URL for the image";
var text_enter_email    = "Enter the email address";
var text_enter_flash    = "Enter the URL to the Flash movie.";
var text_flash_width    = "Enter the Width of the movie in pixels. Maximum Width= ";
var text_flash_height   = "Enter the Height of the movie in pixels. Maximum Height= ";
var text_code           = "Usage: [CODE] Your Code Here.. [/CODE]";
var text_quote          = "Usage: [QUOTE] Your Quote Here.. [/QUOTE]";

// Error stuff

var error_no_url        = "You must enter a URL";
var error_no_title      = "You must enter a title";
var error_no_email      = "You must enter an email address";
var error_no_width      = "You must enter a width";
var error_no_height     = "You must enter a height";


function PostWrite(NewCode) {
    document.REPLIER.Post.value+=NewCode;
    document.REPLIER.Post.focus();
    return;
}

function IBCurl() {
    var FoundErrors = '';
    var enterURL   = prompt(text_enter_url, "http://");
    var enterTITLE = prompt(text_enter_url_name, "My Webpage");
    if (!enterURL)    {
        FoundErrors += "\n" + error_no_url;
    }
    if (!enterTITLE)  {
        FoundErrors += "\n" + error_no_title;
    }
    if (FoundErrors)  {
        alert("Error!"+FoundErrors);
        return;
    }
    var ToAdd = "[URL="+enterURL+"]"+enterTITLE+"[/URL]";
    document.REPLIER.Post.value+=ToAdd;
	document.REPLIER.Post.focus();
}

function IBCimage() {
    var FoundErrors = '';
    var enterURL   = prompt(text_enter_image, "http://");
    if (!enterURL) {
        FoundErrors += "\n" + error_no_url;
    }
    if (FoundErrors) {
        alert("Error!"+FoundErrors);
        return;
    }
    var ToAdd = "[IMG]"+enterURL+"[/IMG]";
    document.REPLIER.Post.value+=ToAdd;
	document.REPLIER.Post.focus();
}

function IBCemail() {
    var emailAddress = prompt(text_enter_email,"");
    if (!emailAddress) { alert(error_no_email); return; }
    var ToAdd = "[EMAIL]"+emailAddress+"[/EMAIL]";
    PostWrite(ToAdd);
}

function IBCflash(maxWidth, maxHeight) {
   var FoundErrors = '';
   var FlashURL    = prompt(text_enter_flash, "http://");
   var FlashWidth  = prompt(text_flash_width +" "+ maxWidth, "");
   var FlashHeight = prompt(text_flash_height +" "+ maxHeight, "");
   if (!FlashURL)    { FoundErrors+="\n"+error_no_url;      }
   if (!FlashWidth)  { FoundErrors+="\n"+error_no_width;    }
   if (!FlashHeight) { FoundErrors+="\n"+error_no_height;   }
   if (FoundErrors)  { alert("Error!"+FoundErrors); return; }
   var ToAdd = "[FLASH="+FlashWidth+","+FlashHeight+"]"+FlashURL+"[/FLASH]";
   PostWrite(ToAdd);
}


function IBCcode() {
   if (Code == 0) {
      ToAdd = "[CODE]";
      document.REPLIER.code.value = " Code*";
      Code = 1;
   } else {
      ToAdd = "[/CODE]";
      document.REPLIER.code.value = " Code ";
      Code = 0;
   }
   PostWrite(ToAdd);
}

function IBCquote() {
   if (Quote == 0) {
      ToAdd = "[QUOTE]";
      document.REPLIER.quote.value = " Quote*";
      Quote = 1;
   } else {
      ToAdd = "[/QUOTE]";
      document.REPLIER.quote.value = " Quote ";
      Quote = 0;
   }
   PostWrite(ToAdd);
}


function IBCbold() {
   if (Bold == 0) {
      ToAdd = "[B]";
      document.REPLIER.bold.value = " B*";
      Bold = 1;
   } else {
      ToAdd = "[/B]";
      document.REPLIER.bold.value = " B ";
      Bold = 0;
   }
   PostWrite(ToAdd);
}

function IBCitalic() {
   if (Italic == 0) {
      ToAdd = "[I]";
      document.REPLIER.italic.value = " I*";
      Italic = 1;
   } else {
      ToAdd = "[/I]";
      document.REPLIER.italic.value = " I ";
      Italic = 0;
   }
   PostWrite(ToAdd);
}


function IBCunder() {
   if (Underline == 0) {
      ToAdd = "[U]";
      document.REPLIER.under.value = " U*";
      Underline = 1;
   } else {
      ToAdd = "[/U]";
      document.REPLIER.under.value = " U ";
      Underline = 0;
   }
   PostWrite(ToAdd);
}


