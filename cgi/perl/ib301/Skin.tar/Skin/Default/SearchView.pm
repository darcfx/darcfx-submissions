package SearchView;
use strict;



sub Form {
my $select_html = shift;

return qq~
   
    <!-- Search Form -->
    <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Search;CODE=01" method="post" name='sForm'>
    <input type='hidden' name='act' value='Search'>
    <input type='hidden' name='s' value='$iB::SESSION'>
    <input type='hidden' name='CODE' value='01'>
    <table cellpadding='0' cellspacing='1' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='4' cellspacing='1' border='0' width='100%'>
                    <tr>
                        <td bgcolor="$iB::SKIN->{'TITLEBACK'}" colspan='2' id="titlelarge">$Search::lang->{'search_title'}</td>
                    </tr>
                    <tr>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='30%' valign='top'><font class='misc'><b>$Search::lang->{'search_help'}</b></font></td>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='70%' valign='middle'><input type='text' size='50' value='$Search::lang->{'js_def'}' name='summary' style="font-size:8pt;font-family:Verdana;border:$iB::SKIN->{'MISCBACK_TWO'} solid thin;background-color:$iB::SKIN->{'MISCBACK_TWO'};width:100%"></td>
                    </tr>
                    <tr>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' colspan='2' id="titlelarge">$Search::lang->{'enter_search_words'}</td>
                    </tr>
                    <tr>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='30%' valign='top'><b>$Search::lang->{'search_keywords'}</b></td>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='70%' valign='middle'><input type='text' maxlength='100' size='50' name='keywords' class='forminput' onChange="keyword()">$Search::lang->{'keywords_txt'}</td>
                    </tr>
                    <tr>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='30%' valign='top'><b>$Search::lang->{'type_search'}</b></td>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='70%' valign='middle'><select name='type' class='forminput' size='2'><option value='name'>$Search::lang->{'membername'}<option value='post' selected>$Search::lang->{'post'}</select></td>
                    </tr>
                    <tr>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' colspan='2' id="titlelarge">$Search::lang->{'choose_forums'}</td>
                    </tr>
                    <tr>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='30%' valign='top'><b>$Search::lang->{'forums'}</b></td>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='70%' valign='middle'>$select_html<br>$Search::lang->{'select_txt'}</td>
                    </tr>
                    <tr>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' colspan='2' id="titlelarge">$Search::lang->{'refine_search'}</b></td>
                    </tr>
                    <tr>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='30%' valign='top'><b>$Search::lang->{'search_in'}</b></td>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='70%' valign='middle'><select name='search_in' class='forminput'><option value='titles'>$Search::lang->{'topic'}<option value='Posts'>$Search::lang->{'posts'}<option value='all' selected>$Search::lang->{'both'}</select></td>
                    </tr>
                    <tr>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='30%' valign='top'><b>$Search::lang->{'search_from'}</b></td>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='70%' valign='middle'>
                            <select name='prune' class='forminput' onChange="show_prune()">
                            <option value='1'>$Search::lang->{'today'}
                            <option value='7'>$Search::lang->{'this_week'}
                            <option value='30' selected>$Search::lang->{'this_month'}
                            <option value='365'>$Search::lang->{'this_year'}
                            <option value='0'>$Search::lang->{'ever'}
                            </select>
                            &nbsp;&nbsp;$Search::lang->{'and'}&nbsp;<input type='radio' name='prune_type' value='older' class='forminput' style='background-color:$iB::SKIN->{'MISCBACK_ONE'}'>&nbsp;$Search::lang->{'older'}&nbsp;<input type='radio' name='prune_type' value='newer' class='forminput' style='background-color:$iB::SKIN->{'MISCBACK_ONE'}' checked>&nbsp;$Search::lang->{'newer'}
                        </td>
                    </tr>
                    <tr>
                        <td bgcolor="$iB::SKIN->{'MISCBACK_ONE'}" colspan='2' align='center'><input type='submit' value='$Search::lang->{'do_search'}' class='forminput'></td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
    </form>
    <SCRIPT LANGUAGE="JavaScript1.1">
        function show_prune () {
            var prune = document.sForm.prune.value;
            var day_name = "";
            if (prune == "1") { day_name = "$Search::lang->{'today'}"; }
            else if (prune == "7")   { day_name = "$Search::lang->{'this_week'}"; }
            else if (prune == "30")  { day_name = "$Search::lang->{'this_month'}"; }
            else if (prune == "365") { day_name = "$Search::lang->{'this_year'}"; }
            else                     { day_name = "$Search::lang->{'ever'}"; }
            document.sForm.summary.value = "$Search::lang->{'js_searching_posts'} " + day_name;
        }   
        function addForum() {
            var forumselected = document.sForm.forums.value;
            var msg = "";
            if (forumselected == "-") {
                msg = "$Search::lang->{'js_warn_1'}";
            }
            else if (forumselected == "all") {
                msg = "$Search::lang->{'js_search_in_all'}";
            }
            else {
                msg = "$Search::lang->{'js_forum'}";
            }
            document.sForm.summary.value = msg;
        }
        function keyword() {
            var keyword = document.sForm.keywords.value;
            document.sForm.summary.value = "$Search::lang->{'js_words_s'} " + keyword;
        }
        function order() {
            var sort_order = document.sForm.sort_order.value;
            document.sForm.summary.value = sort_order + " $Search::lang->{'js_order'}";
        }
        </SCRIPT>

~;
}


sub start {
    my $Data = shift;

return qq~

   <!-- Cgi-bot Start Forum page unique top -->
   <table cellpadding='0 'cellspacing='4' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
      <tr>
         <td valign='middle' width='50%' nowrap align='left'>$Data->{'SHOW_PAGES'}</td>
      </tr>
     </table>
       <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
              <table cellpadding='2' cellspacing='1' border='0' width='100%'>
                <tr>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}'  id='titlemedium' colspan='2'>&nbsp;</td>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' width='45%' align='left' id='titlemedium'>$Search::lang->{'f_topic'}</td>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' width='45%' align='left' id='titlemedium'>$Search::lang->{'f_forum'}</td>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' width='15%' align='left' id='titlemedium'>$Search::lang->{'f_topic_s'}</td>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='left' width='5%' id='titlemedium'>$Search::lang->{'f_replies'}</td>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='left' width='5%' id='titlemedium'>$Search::lang->{'f_views'}</td>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' width='25%' id='titlemedium'>$Search::lang->{'f_last'}</td>
                </tr>
        <!-- Cgi-bot End Forum page unique top -->

~;
}


sub row {
  my $Data = shift;

return qq~

    <!-- Begin Topic Entry $Data->{'TOPIC_ID'} -->
    <tr>
    <td bgcolor='$iB::SKIN->{'FORUM_COL_TWO'}' width='4%' align='center'>$Data->{'FOLDER_ICON'}</td>
    <td bgcolor='$iB::SKIN->{'FORUM_COL_TWO'}' width='4%' align='center'>$Data->{'TOPIC_ICON'}</td>
    <td bgcolor='$iB::SKIN->{'FORUM_COL_TWO'}' width='40%'><span id="linkthru"><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.cgi?s=$iB::SESSION;act=ST;f=$Data->{'FORUM_ID'};t=$Data->{'TOPIC_ID'};hl=$Data->{'KEYWORDS'}">$Data->{'TOPIC_TITLE'}</a>  $Data->{'PAGES'}</span><br><span id="linkthrudesc">$Data->{'TOPIC_DESC'}</span></td>
    <td bgcolor='$iB::SKIN->{'FORUM_COL_TWO'}' width='40%'><span id="linkthru"><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.cgi?s=$iB::SESSION;act=SF;f=$Data->{'FORUM_ID'}">$Data->{'FORUM_NAME'}</a></span></td>
    <td bgcolor='$iB::SKIN->{'FORUM_COL_TWO'}' align='left' valign='middle'><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.cgi?s=$iB::SESSION;act=Profile;CODE=03;MID=$Data->{'TOPIC_STARTER'}">$Data->{'TOPIC_STARTER_N'}</a></td>
    <td bgcolor='$iB::SKIN->{'FORUM_COL_ONE'}' align='center' valign='middle'><b>$Data->{'TOPIC_POSTS'}</b></td>
    <td bgcolor='$iB::SKIN->{'FORUM_COL_ONE'}' align='center' valign='middle'><b>$Data->{'TOPIC_VIEWS'}</b></td>
    <td bgcolor='$iB::SKIN->{'FORUM_COL_ONE'}' valign='middle'><span id='highlight'>$Data->{'TOPIC_LAST_DATE'}</span><br>$Search::lang->{'f_last'}: $Data->{'LAST_POSTER'}</td>
    </tr>
    <!-- End Topic Entry $Data->{'TOPIC_ID'} -->

~;

}

sub redo_search {
    my $data = shift;

    return qq~
    <table cellpadding='0' cellspacing='4' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
     <tr>
        <td align='left'>$Search::lang->{'search_string'}<br><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.cgi?s=$iB::SESSION;act=Search&CODE=02;SID=$data->{'ID'}">$Search::lang->{'search_str_ahref'}</a></td>
     </tr>
    </table>
    <br>
    ~;
}


sub end {
  my $Data = shift;
   
return qq~
  <tr><td colspan='8' id='titlemedium'>&nbsp;</td></tr>
  </table>
  </td>
  </tr>
  </table>
 
   <table cellpadding='0' cellspacing='4' border='0' width='50%' align='center'>
     <tr>
        <td valign='middle' nowrap>$iB::SKIN->{'B_NEW'}&nbsp;$Search::lang->{'pm_open_new'}</td>
        <td valign='middle' nowrap>$iB::SKIN->{'B_HOT'}&nbsp;$Search::lang->{'pm_hot_new'}</td>
        <td valign='middle' nowrap>$iB::SKIN->{'B_POLL'}&nbsp;$Search::lang->{'pm_poll'}</td>
        <td valign='middle' nowrap>$iB::SKIN->{'B_LOCKED'}&nbsp;$Search::lang->{'pm_locked'}</td>
     </tr>
     <tr>
        <td valign='middle' nowrap>$iB::SKIN->{'B_NORM'}&nbsp;$Search::lang->{'pm_open_no'}</td>
        <td valign='middle' nowrap>$iB::SKIN->{'B_HOT_NN'}&nbsp;$Search::lang->{'pm_hot_no'}</td>
        <td valign='middle' nowrap>$iB::SKIN->{'B_POLL_NN'}&nbsp;$Search::lang->{'pm_poll_no'}</td>
        <td valign='middle' nowrap>$iB::SKIN->{'B_MOVED'}&nbsp;$Search::lang->{'pm_moved'}</td>
      </tr>
   </table>

~;

   }

# ====== Do not touch anything below this line ====== #

1;

__END__
