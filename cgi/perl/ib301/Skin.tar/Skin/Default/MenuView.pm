package MenuView;

my $base_url = qq[$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=UserCP;CODE=];

sub Menu_bar {
    my $Nav_color = shift;

return qq~
    <br>
     <table cellspacing='0' cellpadding='5' border='0' align='center' width='$iB::SKIN->{'TABLE_WIDTH'}'>
        <tr height=16'>
            <td bgcolor='$Nav_color->{'splash'}'    id='tabs' valign='middle' align='center' width='16%' height='16'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=UserCP;CODE=00'>$UserCP::lang->{'splash'}</a></td>
            <td bgcolor='$Nav_color->{'personal'}'  id='tabs' valign='middle' align='center' width='16%' height='16'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=UserCP;CODE=01'>$UserCP::lang->{'personal'}</a></td>
            <td bgcolor='$Nav_color->{'email'}'     id='tabs' valign='middle' align='center' width='16%' height='16'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=UserCP;CODE=02'>$UserCP::lang->{'email'}</a></td>
            <td bgcolor='$Nav_color->{'subs'}'      id='tabs' valign='middle' align='center' width='16%' height='16'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=UserCP;CODE=03'>$UserCP::lang->{'subs'}</a></td>
            <td bgcolor='$Nav_color->{'settings'}'  id='tabs' valign='middle' align='center' width='16%' height='16'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=UserCP;CODE=04'>$UserCP::lang->{'settings'}</a></td>
            <td bgcolor='$Nav_color->{'account'}'   id='tabs' valign='middle' align='center' width='16%' height='16'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=UserCP;CODE=05'>$UserCP::lang->{'account'}</a></td>
        </tr>
     </table>
     <table cellpadding='0' cellspacing='1' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
           <td>
              <table cellpadding='4' cellspacing='1' border='0' width='100%'>
              <tr>
                   
~;
}


sub personal_avatar {
my $data = shift;

return qq~
                <script langauge='javascript'>
                <!--
                  function showavatar(theURL) {
                    if (document.creator.useravatar.value == '*') {
                        return true;
                    }
                    document.images.useravatars.src=theURL+document.creator.useravatar.options[document.creator.useravatar.selectedIndex].value;
                  }
                //-->
                </script>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' valign='left' colspan='2' id='titlelarge'>$UserCP::lang->{'avatar_title'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'><b>$iB::MEMBER->{'MEMBER_NAME'}</b>, $UserCP::lang->{'avatar_sub'} $UserCP::lang->{'avatar_url_allowed'}</td>
                </tr>
                <form action='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}' method='post' name='creator'>
                <input type='hidden' name='act' value='Profile'><input type='hidden' name='CODE' value='10'><input type='hidden' name='s' value='$iB::SESSION'>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' align='left' colspan='2' id='titlelarge'><b>$UserCP::lang->{'av_current'}</b></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='40%' valign='middle'>$UserCP::lang->{'this_avatar'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='60%' valign='middle'>$data->{'CUR_AV'}</td>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' valign='left' colspan='2' id='titlelarge'><b>$UserCP::lang->{'avatar_pre_title'}</b></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%' valign='top'>$UserCP::lang->{'avatar_pre_txt'} <a href="javascript:PopUp('$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION&act=Legends&CODE=avatars','HelpCard','200','400','0','1','1','1')">$UserCP::lang->{'avatar_show_all'}</a></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='top'>$data->{'AVATARS'} &nbsp; &nbsp; $data->{'SHOW_AVS'}  $UserCP::lang->{'current_avatar'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='center' colspan='2'><input type="submit" value="$UserCP::lang->{'avatar_pre_submit'}" class='forminput'></td>
                </tr>              
                </form>
               
~;


}



sub personal_avatar_URL {
my ($Profile, $avatar, $allowed_ext) = @_;

return qq~
                <form action='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}' method='post' name='url_avatar'>
                <input type='hidden' name='act' value='Profile'><input type='hidden' name='CODE' value='11'><input type='hidden' name='s' value='$iB::SESSION'>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' valign='left' colspan='2' id='titlelarge'><b>$UserCP::lang->{'avatar_url_title'}</b></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'>$UserCP::lang->{'avatar_url_txt'}<br>$UserCP::lang->{'avatar_dims_txt'}<br> ($UserCP::lang->{'maximum'} $UserCP::lang->{'width'} = $iB::INFO->{'AV_WIDTH'} $UserCP::lang->{'pixels'} | $UserCP::lang->{'maximum'} $UserCP::lang->{'height'} = $iB::INFO->{'AV_HEIGHT'} $UserCP::lang->{'pixels'})</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%' valign='top'>$UserCP::lang->{'avatar'}<br>$UserCP::lang->{'avatar_url_ext'}<br><b>$allowed_ext</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' size='55' maxlength='80' name='useravatar' value='$avatar' class='forminput'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%' valign='top'>$UserCP::lang->{'avatar_dims'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$UserCP::lang->{'width'} &nbsp; <input type='text' size='3' maxlength='3' name='Avatar_width' value='$Profile->{'AVATAR_WIDTH'}' class='forminput'>&nbsp; x &nbsp; $UserCP::lang->{'height'} &nbsp; <input type='text' size='3' maxlength='3' name='Avatar_height' value='$Profile->{'AVATAR_HEIGHT'}' class='forminput'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='center' colspan='2'><input type="submit" value="$UserCP::lang->{'avatar_url_submit'}" name='URL' class='forminput'></td>
                </tr>              
                </form>
~;

}








sub personal_splash {
#+------------------------------------------------------------------------------------------------------------
return qq~

                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' colspan='2' id='titlelarge'>$UserCP::lang->{'personal_ops'}</td>                
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'><b>$iB::MEMBER->{'MEMBER_NAME'}</b>, $UserCP::lang->{'personal_ops_txt'}</td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2'><span id='usermenu'><u><b><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=UserCP;CODE=01;MODE=2'>$UserCP::lang->{'edit_profile'}</a></b></u></span><br><br>$UserCP::lang->{'edit_profile_txt'}</td>
                 </tr>
                 

~; # >> END OF HTML - DO NOT EDIT THIS LINE!
#+------------------------------------------------------------------------------------------------------------
}


sub personal_splash_av {
#+------------------------------------------------------------------------------------------------------------
return qq~

                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2'><span id='usermenu'><b><u><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=UserCP;CODE=01;MODE=1'>$UserCP::lang->{'avatar_ops'}</a></u></b></span><br><br>$UserCP::lang->{'avatar_ops_txt'}</td>
                 </tr>


~; # >> END OF HTML - DO NOT EDIT THIS LINE!
#+------------------------------------------------------------------------------------------------------------
}


sub member_title {

return qq~
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%'>$UserCP::lang->{'member_title'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' size='40' maxlength='120' name='member_title' value='$iB::MEMBER->{'MEMBER_TITLE'}' class='forminput'></td>
                </tr> 
~;
}


sub birthday {

return qq~
            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='40%'><b>$UserCP::lang->{'birthday'}</b></td>
            <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'>
            <select name='day' class='forminput'>$iB::MEMBER->{'DAY'}</select> 
            <select name='month' class='forminput'>$iB::MEMBER->{'MONTH'}</select> 
            <select name='year' class='forminput'>$iB::MEMBER->{'YEAR'}</select>
            </td>
            </tr>
~;
}




sub personal_panel {
my $Profile = shift;


return qq~
<script language="javascript">
<!--

var LocationMax  = "$iB::INFO->{'MAX_LOCATION_LENGTH'}";
var InterestMax  = "$iB::INFO->{'MAX_INTEREST_LENGTH'}";
var SignatureMax = "$iB::INFO->{'MAX_SIG_LENGTH'}";

function CheckLength(Type) {
    LocationLength  = document.theForm.Location.value.length;
    InterestLength  = document.theForm.Interests.value.length;
    SignatureLength = document.theForm.Signature.value.length;
    message  = "";

    if (Type == "location") {
        if (LocationMax !=0) {
            message = "$UserCP::lang->{'js_location'}:\\n$UserCP::lang->{'js_max'} " + LocationMax + " $UserCP::lang->{'js_characters'}.";
        } else {
            message = "";
        }
        alert(message + "\\n$UserCP::lang->{'js_used'} " + LocationLength + " $UserCP::lang->{'js_so_far'}.");
    }
    else if (Type == "interest") {
        if (InterestMax !=0) {
            message = "$UserCP::lang->{'js_interests'}:\\n$UserCP::lang->{'js_max'} " + InterestMax + " $UserCP::lang->{'js_characters'}.";
        } else {
            message = "";
        }
        alert(message + "\\n$UserCP::lang->{'js_used'} " + InterestLength + " $UserCP::lang->{'js_so_far'}.");
    }
    else if (Type == "signature") {
        if (SignatureMax !=0) {
            message = "$UserCP::lang->{'js_signature'}:\\n$UserCP::lang->{'js_max'} " + SignatureMax + " $UserCP::lang->{'js_characters'}.";
        } else {
            message = "";
        }
        alert(message + "\\n$UserCP::lang->{'js_used'} " + SignatureLength + " $UserCP::lang->{'js_so_far'}.");
    }
}

function ValidateProfile() {

    LocationLength  = document.theForm.Location.value.length;
    InterestLength  = document.theForm.Interests.value.length;
    SignatureLength = document.theForm.Signature.value.length;

    errors = "";

    if (LocationMax !=0) {
        if (LocationLength > LocationMax) {
            errors = "$UserCP::lang->{'js_location'}:\\n$UserCP::lang->{'js_max'} " + LocationMax + " $UserCP::lang->{'js_characters'}.\\n$UserCP::lang->{'js_used'}: " + LocationLength;
        }
    }
    if (InterestMax !=0) {
        if (InterestLength > InterestMax) {
            errors = errors + "\\n$UserCP::lang->{'js_interests'}:\\n$UserCP::lang->{'js_max'} " + InterestMax + " $UserCP::lang->{'js_characters'}.\\n$UserCP::lang->{'js_used'}: " + InterestLength;
        }
    } 
    if (SignatureMax !=0) {
        if (SignatureLength > SignatureMax) {
            errors = errors + "\\n$UserCP::lang->{'js_signature'}:\\n$UserCP::lang->{'js_max'} " + SignatureMax + " $UserCP::lang->{'js_characters'}.\\n$UserCP::lang->{'js_used'}: " + SignatureLength;
        }
    }

    if (errors != "") {
        alert(errors);
        return false;
    } else {
        return true;
    }
}
//-->
</script>
<form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='theForm' onSubmit='return ValidateProfile()'>
     <input type='hidden' name='act' value='Profile'>
     <input type='hidden' name='CODE' value='02'>
     <input type='hidden' name='s' value='$iB::SESSION'>

                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' valign='left' colspan='2' id='titlelarge'>$UserCP::lang->{'profile_title'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'><b>$iB::MEMBER->{'MEMBER_NAME'}</b> $UserCP::lang->{'profile_header'}</td>
                </tr>
                <!--{MEMBERTITLE}-->
                <!--{BIRTHDAY}-->
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%'>$UserCP::lang->{'photo'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' size='40' maxlength='120' name='Photo' value='$Profile->{'PHOTO'}' class='forminput'></td>
                </tr>  
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='40%'>$UserCP::lang->{'website'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'><input type='text' size='40' maxlength='1200' name='WebSite' value='$Profile->{'WEBSITE'}' class='forminput'></td>
                </tr>  
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%'>$UserCP::lang->{'icq'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' size='40' maxlength='20' name='ICQNumber' value='$Profile->{'ICQNUMBER'}' class='forminput'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='40%'>$UserCP::lang->{'aol'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'><input type='text' size='40' maxlength='30' name='AOLName' value='$Profile->{'AOLNAME'}' class='forminput'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%'>$UserCP::lang->{'yahoo'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' size='40' maxlength='30' name='YahooName' value='$Profile->{'YAHOONAME'}' class='forminput'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='40%'>$UserCP::lang->{'msn'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'><input type='text' size='40' maxlength='30' name='MSNName' value='$Profile->{'MSNNAME'}' class='forminput'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%'>$UserCP::lang->{'location'}<br>(<a href='javascript:CheckLength("location");'>$UserCP::lang->{'check_length'}</a>)</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' size='40' name='Location' value='$Profile->{'LOCATION'}' class='forminput'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='40%' valign='top'>$UserCP::lang->{'interests'}<br>(<a href='javascript:CheckLength("interest");'>$UserCP::lang->{'check_length'}</a>)</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}'><textarea cols='60' rows='10' wrap='soft' name='Interests' class='forminput'>$Profile->{'INTERESTS'}</textarea></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%' valign='top'>$UserCP::lang->{'signature'}<br>(<a href='javascript:CheckLength("signature");'>$UserCP::lang->{'check_length'}</a>)</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><textarea cols='60' rows='10' wrap='soft' name='Signature' class='forminput'>$Profile->{'SIGNATURE'}</textarea></td>
                </tr>
                <tr>
                <td bgcolor=$iB::SKIN->{'MISCBACK_TWO'} align='center' colspan='2'>
                <input type="submit" value="$UserCP::lang->{'submit_profile'}" class='forminput'>
                </td></tr>
                </form>

~;




}



sub email    {
my $Profile = shift;

return qq~

<form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post">
     <input type='hidden' name='act' value='Profile'>
     <input type='hidden' name='CODE' value='04'>
     <input type='hidden' name='s' value='$iB::SESSION'>
     
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' valign='left' colspan='2' id='titlelarge'>$UserCP::lang->{'email_title'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'><b>$iB::MEMBER->{'MEMBER_NAME'}</b> $UserCP::lang->{'email_header'}</td>
                </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' valign='left' colspan='2' id='titlelarge'><b>$UserCP::lang->{'privacy_settings'}</b></td>
                 </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='right' valign='top'><input type='checkbox' name='hide_email' value='1' $Profile->{'HIDE_EMAIL'}></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left' width='100%'>$UserCP::lang->{'hide_email'}</td>
                </tr>  
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='right' valign='top'><input type='checkbox' name='admin_send' value='1' $Profile->{'ALLOW_ADMIN_EMAILS'}></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'  width='100%'>$UserCP::lang->{'admin_send'}</td>
                </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' valign='left' colspan='2' id='titlelarge'><b>$UserCP::lang->{'board_prefs'}</b></td>
                 </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='right' valign='top'><input type='checkbox' name='send_full_msg' value='1' $Profile->{'EMAIL_FULL_POST'}></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'  width='100%'>$UserCP::lang->{'send_full_msg'}</td>
                </tr>
                <!-- Not available until 3.1<tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='right' valign='top'><input type='checkbox' name='pm_reminder' value='1' $Profile->{'PM_REMINDER'}></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'  width='100%'>$UserCP::lang->{'pm_reminder'}</td>
                </tr>-->
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='right' valign='top'><input type='text' size='3' maxlength='3' name='end_subs' value='$Profile->{'CANCEL_SUBS'}'></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'  width='100%'>$UserCP::lang->{'end_subs'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='center' colspan='2'>
                <input type="submit" value="$UserCP::lang->{'submit_email'}" class='forminput'>
                </td></tr>
                </form>

~;



}


sub subs_header {

return qq~

                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' colspan='2' id='titlelarge'><b>$UserCP::lang->{'subs_title'} $iB::MEMBER->{'MEMBER_NAME'}</b></td>                
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'><b>$iB::MEMBER->{'MEMBER_NAME'}</b>, $UserCP::lang->{'subs_text'}</td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' colspan='2' id='titlelarge'><b>$UserCP::lang->{'subs_header'}</b></td>
                 </tr>
                 <tr>
                 <td valign='top' bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2' >
                 <table cellpadding='4' cellspacing='1' align='center' width='100%' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}'>
                 <tr id='titlemedium'>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='left' width='5%'>&nbsp;</td>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='left' width='40%'>$UserCP::lang->{'subs_topic'}</td>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='center' width='5%'>$UserCP::lang->{'subs_replies'}</td>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='center' width='5%'>$UserCP::lang->{'subs_view'}</td>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='left' width='20%'>$UserCP::lang->{'subs_last_post'}</td>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='left' width='10%'>$UserCP::lang->{'subs_left'}</td>
                 </tr>


~;
}


sub subs_row {
    my $data = shift;

return qq~
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='center' width='5%'><img src="$data->{'TOPIC_ICON'}" border='0'></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'><span id='linkthru'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=ST;f=$data->{'FORUM_ID'};t=$data->{'TOPIC_ID'}'>$data->{'TOPIC_TITLE'}</a></span><br>$UserCP::lang->{'subs_start'} $data->{'DATE_START'} [ <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=UserCP;CODE=06;ID=$data->{'ID'}'>$UserCP::lang->{'subs_cancel'}</a> ]</td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='center'>$data->{'TOPIC_POSTS'}</td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='center'>$data->{'TOPIC_VIEWS'}</td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'>$data->{'TOPIC_LAST_DATE'}<br>$UserCP::lang->{'subs_by'} $data->{'LAST_POSTER'}</td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'><b>$data->{'DAYS_LEFT'}</b></td>
                 </tr>
~;
}



sub subs_end {

return qq~</table></td></tr>~;


}





sub account    {
my $Profile = shift;

return qq~

                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' colspan='2' id='titlelarge'><b>$UserCP::lang->{'account_title'} $iB::MEMBER->{'MEMBER_NAME'}</b></font></td>                
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2' align='left'><b>$iB::MEMBER->{'MEMBER_NAME'}</b>, $UserCP::lang->{'account_text'}</td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' colspan='2' id='titlelarge'><b>$UserCP::lang->{'account_email_title'}</b></td>
                 </tr>

                 <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='form1'>
                 <input type='hidden' name='act' value='Profile'>
                 <input type='hidden' name='CODE' value='06'>
                 <input type='hidden' name='s' value='$iB::SESSION'>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' nowrap><b>$UserCP::lang->{'account_email_txt'}</b></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='70%' align='left'><input type='text' name='u_email' value='$Profile->{'MEMBER_EMAIL'}' class='forminput'></td>
                 </tr>
                 <tr>
                     <td bgcolor=$iB::SKIN->{'MISCBACK_TWO'} align='center' colspan='2'><input type="submit" name='s_email' value="$UserCP::lang->{'account_email_submit'}" class='forminput'></td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' colspan='2' id='titlelarge'><b>$UserCP::lang->{'account_pass_title'}</b></td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' nowrap><b>$UserCP::lang->{'account_pass_old'}</b></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'><input type='password' name='u_o_pass' value='' class='forminput'></td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' nowrap><b>$UserCP::lang->{'account_pass_new'}</b></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'><input type='password' name='u_new_pass_1' value='' class='forminput'></td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' nowrap><b>$UserCP::lang->{'account_pass_new2'}</b></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'><input type='password' name='u_new_pass_2' value='' class='forminput'></td>
                 </tr>
                 <tr>
                    <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='center' colspan='2'><input type="submit" name='s_pass' value="$UserCP::lang->{'account_pass_submit'}" class='forminput'></td>
                 </tr>
                 </form>

~;
}




#+------------------------------------------------------------------------------------------------------------







sub splash {
my $member = shift;

#+------------------------------------------------------------------------------------------------------------
return qq~

                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' colspan='2' id='titlelarge'><b>$UserCP::lang->{'welcome'} $iB::MEMBER->{'MEMBER_NAME'}</b></td>                
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'><b>$iB::MEMBER->{'MEMBER_NAME'}</b>, $UserCP::lang->{'welcome_text'}</td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' colspan='2' id='titlelarge'><b>$UserCP::lang->{'stats_header'}</b></td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='20%'><b>$UserCP::lang->{'email_address'}</b></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='80%'>$member->{'MEMBER_EMAIL'}</td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='20%'><b>$UserCP::lang->{'number_posts'}</b></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='80%'>$member->{'MEMBER_POSTS'}</td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='20%'><b>$UserCP::lang->{'registered'}</b></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='80%'>$member->{'DATE_REGISTERED'}</td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='20%'><b>$UserCP::lang->{'daily_average'}</b></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' width='80%'>$member->{'DAILY_AVERAGE'}</td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' colspan='2' id='titlelarge'><b>$UserCP::lang->{'quick_help'}</b></td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'><b>$UserCP::lang->{'personal'}:</b> $UserCP::lang->{'personal_help'}<br><br><b>$UserCP::lang->{'email'}:</b> $UserCP::lang->{'email_help'}<br><br><b>$UserCP::lang->{'subs'}:</b> $UserCP::lang->{'subs_help'}<br><br><b>$UserCP::lang->{'settings'}:</b> $UserCP::lang->{'settings_help'}<br><br><b>$UserCP::lang->{'account'}:</b> $UserCP::lang->{'account_help'}</td>
                 </tr>









~; # >> END OF HTML - DO NOT EDIT THIS LINE!
#+------------------------------------------------------------------------------------------------------------
}





sub settings_header {
my ($Profile, $time_select, $time, $lang_select) = @_;

return qq~
     <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post">
     <input type='hidden' name='act' value='Profile'>
     <input type='hidden' name='CODE' value='05'>
     <input type='hidden' name='s' value='$iB::SESSION'>

                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' colspan='2' id='titlelarge'><b>$UserCP::lang->{'settings_title'} $iB::MEMBER->{'MEMBER_NAME'}</b></td>                
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2' align='left'><b>$iB::MEMBER->{'MEMBER_NAME'}</b>, $UserCP::lang->{'settings_text'}</td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' colspan='2' id='titlelarge'><b>$UserCP::lang->{'settings_time'}</b></td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' nowrap><b>$UserCP::lang->{'settings_time_txt'}</b></font> &nbsp; <span id='highlight'>$time</span></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='70%' align='left'>$time_select &nbsp; $UserCP::lang->{'settings_hour'}</td>
                 </tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' colspan='2' id='titlelarge'><b>$UserCP::lang->{'settings_lang'}</b></td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' nowrap><b>$UserCP::lang->{'settings_lang_txt'}</b></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'>$lang_select</td>
                 </tr>
~;
}


sub settings_skin {
    my $skin = shift;

return qq~
                 </tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' colspan='2' id='titlelarge'><b>$UserCP::lang->{'settings_skin'}</b></td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' nowrap><b>$UserCP::lang->{'settings_skin_txt'}</b></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'>$skin</td>
                 </tr>
~;
}



sub settings_end {
my ($data) = @_;

return qq~
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' colspan='2' id='titlelarge'><b>$UserCP::lang->{'settings_display'}</b></td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' nowrap><b>$UserCP::lang->{'settings_viewsig'}</b></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='70%' align='left'>$data->{'SIG'}</td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' nowrap><b>$UserCP::lang->{'settings_viewimg'}</b></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='70%' align='left'>$data->{'IMG'}</td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' nowrap><b>$UserCP::lang->{'settings_viewava'}</b></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='70%' align='left'>$data->{'AVA'}</td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' nowrap><b>$UserCP::lang->{'settings_dopopup'}</b></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='70%' align='left'>$data->{'POP'}</td>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2' align='center'><input type='submit' name='submit' value='$UserCP::lang->{'settings_submit'}' class='forminput'></form></td>
                 </tr>
~;
}





sub CP_end {

return qq~

    </table></td></tr></table>


~;
}






1;
