package HelpWords;


sub new {
  my $pkg = shift;
  my $obj = {
   
#+----------------------------------------------------------------------
#| Do Not remove or edit anything above this line!
#| Only Edit the words on the right of the => arrow
#+----------------------------------------------------------------------

page_title      => "Ikonboard Help Files",
help_txt        => "Welcome to the Ikonboard help database.<br><br>Simply choose from one of the titles to learn more about how Ikonboard works. Or, simply search for help files",

submit          => "Search!",
search_txt      => "Enter keywords to search for",
help_topics     => "Help Topics",
search_results  => "Search Results",
results_txt     => "Here are the results of the search you performed.",
results_title   => "Your Help Search Results",
no_results      => "Sorry, we could not find any help topics that matched your search criteria, please try again",

help_topic      => "Help Topic",
topic_text      => "Here is the topic you chose to view",

choose_file     => "Choose a topic",


#+----------------------------------------------------------------------
#| Do Not remove or edit anything below this line!
#+----------------------------------------------------------------------
  };

  bless $obj, $pkg;
  return $obj;
}




1;

__END__
