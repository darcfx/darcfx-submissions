package LegendsWords;


sub new {
  my $pkg = shift;
  my $obj = {
   
#+----------------------------------------------------------------------
#| Do Not remove or edit anything above this line!
#| Only Edit the words on the right of the => arrow
#+----------------------------------------------------------------------

## Added RC 2 ##

 B       => "Bold Text",
 U       => "Underlined Text",
 I       => "Italic Text",
 S       => "Strikethrough Text",
 QUOTE   => "Quoting text.......",

 SIZE    => "Font Size(1-10)",
 COLOR   => "red",
 COLOR2  => "Font Color",
 ME      => "runs!",
 FONT    => "Font Face",




help_card   => "Help Card: ",


emo_title   => "Emoticons",
emo_text    => "Emoticons are used to express emotions when posting. They are a graphical representation of the classic web 'smilie'; <b>:-)</b>.",
emo_type    => "You Type",
emo_used    => "Converted Emoticon",
avatar_title => "Currently Installed Avatars",
avatar_type => "Avatar Name",
avatar_img  => "Avatar Image",
avatar_text => "These are all the avatars currently installed",


ibc_title   => "iB Code",
ibc_text    => "iB Code is just like posting HTML. Instead, square brackets are used and certain tags invoke special features.",
ibc_type    => "You Type",
ibc_used    => "Converted Text",


};


#+----------------------------------------------------------------------
#| Do Not remove or edit anything below this line!
#+----------------------------------------------------------------------


  bless $obj, $pkg;
  return $obj;
}




1;

__END__
