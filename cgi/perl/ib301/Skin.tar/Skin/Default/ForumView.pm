package ForumView;


use strict;


sub PageTop {
    my $Data = shift;

return qq~

   <!-- Cgi-bot Start Forum page unique top -->
   <form action='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=SF;f=$Data->{'FORUM_ID'}' method='POST'>
   <table cellpadding='0' cellspacing='4' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
      <tr>
         <td valign='middle' width='50%' nowrap align='left'>$Data->{'SHOW_PAGES'}</td>
         <td valign='middle' width='50%' nowrap align='right'><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Post;CODE=00;f=$Data->{'FORUM_ID'}">$iB::SKIN->{'A_POST'}</a>&nbsp;$Data->{'POLL_BUTTON'}</td>
      </tr>
     </table>
       <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
              <table cellpadding='2' cellspacing='1' border='0' width='100%'>
                <tr>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' colspan='2' id='titlemedium'>
                   &nbsp;
                   <!-- Tuck away hidden form elements -->
                     <input type='hidden' name='act' value='SF'>
                     <input type='hidden' name='f'   value='$Data->{'FORUM_ID'}'>
                     <input type='hidden' name='s'   value='$iB::SESSION'>
                     <input type='hidden' name='st'  value='$iB::IN{'st'}'>
                   <!-- End of tucking :D -->
                   </td>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' width='45%' align='left' id='titlemedium' valign='middle'>$Forum::lang->{'h_topic_title'}</td>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' width='14%' align='center' id='titlemedium' valign='middle'>$Forum::lang->{'h_topic_starter'}</td>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='center' width='6%' id='titlemedium' valign='middle'>$Forum::lang->{'h_replies'}</td>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='center' width='5%' id='titlemedium' valign='middle'>$Forum::lang->{'h_hits'}</td>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='center' width='25%' id='titlemedium' valign='middle'>$Forum::lang->{'h_last_action'}</td>
                </tr>
        <!-- Cgi-bot End Forum page unique top -->

~;
}

sub Mod_Panel {
my $data = shift;

return qq~
    <br>
    <table cellpadding='3' cellspacing='1' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
        <tr>
          <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='center'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModCP;f=$data'>$Forum::lang->{'mod_cp'}</a></td>
        </tr>
    </table>
~;
}




sub show_rules_link {
my $rules = shift;

return qq~

    <!-- Show FAQ/Forum Rules -->
    <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
        <tr>
          <td align='left' valign='middle'><b>&gt;&gt;<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.cgi?s=$iB::SESSION;act=SR;f=$iB::IN{'f'}">$rules->{'RULES_TITLE'}</a></b></td>
      </tr>
   </table>
   <!-- End FAQ/Forum Rules -->

~;

}

sub show_rules_full {
my $rules = shift;

return qq~

    <!-- Show FAQ/Forum Rules -->
    <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
        <tr>
          <td align='left' ><b>$rules->{'RULES_TITLE'}</b><br><br>$rules->{'RULES_TEXT'}</td>
      </tr>
   </table>
   <!-- End FAQ/Forum Rules -->

~;

}


sub show_rules {
my $rules = shift;

return qq~

   <!-- Show Forum FAQ/Rules -->
    <br>
     <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='3' cellspacing='1' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' valign='left' id='titlelarge'>$rules->{'RULES_TITLE'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$rules->{'RULES_TEXT'}<br><br>$Forum::lang->{'last_updated'} $rules->{'LAST_UPDATE'}<br><br>&gt;&gt;<a href="$iB::INFO->{'BOARD_URL'}/ikonboard.cgi?s=$iB::SESSION;act=SF;f=$iB::IN{'f'}">$Forum::lang->{'back_to_forum'}</td>
               </tr>
               </table>
            </td>
      </tr>
   </table>
   <!-- End Forum FAQ/Rules -->

~;
}



sub show_no_matches {

return qq~

      <tr>
        <td bgcolor="$iB::SKIN->{'FORUM_COL_TWO'}" align='center' colspan='7'><br><br><b>$Forum::lang->{'no_topics'}</b><br><br>&nbsp;</td>
     </tr>
 ~;
}



sub RenderRow {
  my $Data = shift;

return qq~

    <!-- Begin Topic Entry $Data->{'TOPIC_ID'} -->
    <tr>
    <td bgcolor='$iB::SKIN->{'FORUM_COL_TWO'}' width='4%' align='center'>$Data->{'FOLDER_ICON'}</td>
    <td bgcolor='$iB::SKIN->{'FORUM_COL_ONE'}' width='4%' align='center'>$Data->{'TOPIC_ICON'}</td>
    <td bgcolor='$iB::SKIN->{'FORUM_COL_TWO'}' width='40%'><span id="linkthru">$Data->{'PREFIX'} <a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ST;f=$Data->{'FORUM_ID'};t=$Data->{'TOPIC_ID'}" title='$Forum::lang->{'topic_started_on'} $Data->{'TOPIC_START_DATE'}'>$Data->{'TOPIC_TITLE'}</a></span>  $Data->{'PAGES'}<br><span id='desc'>$Data->{'TOPIC_DESC'}</span></td>
    <td bgcolor='$iB::SKIN->{'FORUM_COL_ONE'}' align='center' valign='middle'>$Data->{'STARTER'}</td>
    <td bgcolor='$iB::SKIN->{'FORUM_COL_TWO'}' align='center' valign='middle'>$Data->{'TOPIC_POSTS'}</td>
    <td bgcolor='$iB::SKIN->{'FORUM_COL_ONE'}' align='center' valign='middle'>$Data->{'TOPIC_VIEWS'}</td>
    <td bgcolor='$iB::SKIN->{'FORUM_COL_ONE'}' valign='middle' align='left'><span id='highlight'>$Data->{'TOPIC_LAST_DATE'}</span><br>$Data->{'LASTPOST_LINK'} $Data->{'LAST_TEXT'} $Data->{'LAST_POSTER'}</td>
    </tr>
    <!-- End Topic Entry $Data->{'TOPIC_ID'} -->

~;

}




sub Render_p_Row {
  my $Data = shift;

return qq~

    <!-- Begin Topic Entry $Data->{'TOPIC_ID'} -->
    <tr>
    <td bgcolor='$iB::SKIN->{'PIN_COL_TWO'}' width='4%' align='center'>$Data->{'FOLDER_ICON'}</td>
    <td bgcolor='$iB::SKIN->{'PIN_COL_ONE'}' width='4%' align='center'>$Data->{'TOPIC_ICON'}</td>
    <td bgcolor='$iB::SKIN->{'PIN_COL_TWO'}' width='40%'><span id="linkthru">$iB::INFO->{'PRE_PINNED'} <a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ST;f=$Data->{'FORUM_ID'};t=$Data->{'TOPIC_ID'}" title='$Forum::lang->{'topic_started_on'} $Data->{'TOPIC_START_DATE'}'>$Data->{'TOPIC_TITLE'}</a></span>  $Data->{'PAGES'}<br><span id='desc'>$Data->{'TOPIC_DESC'}</span></td>
    <td bgcolor='$iB::SKIN->{'PIN_COL_ONE'}' align='center' valign='middle'>$Data->{'STARTER'}</td>
    <td bgcolor='$iB::SKIN->{'PIN_COL_TWO'}' align='center' valign='middle'>$Data->{'TOPIC_POSTS'}</td>
    <td bgcolor='$iB::SKIN->{'PIN_COL_ONE'}' align='center' valign='middle'>$Data->{'TOPIC_VIEWS'}</td>
    <td bgcolor='$iB::SKIN->{'PIN_COL_ONE'}' valign='middle' align='left'><span id='highlight'>$Data->{'TOPIC_LAST_DATE'}</span><br>$Data->{'LASTPOST_LINK'} $Data->{'LAST_TEXT'} $Data->{'LAST_POSTER'}</td>
    </tr>
    <!-- End Topic Entry $Data->{'TOPIC_ID'} -->

~;

}


sub TableEnd {
  my $Data = shift;
   
return qq~

     <tr>
        <td bgcolor="$iB::SKIN->{'TITLEBACK'}" align='center' colspan='7' id='titlemedium'>$Forum::lang->{'showing_text'}$Forum::lang->{'sort_text'}&nbsp;&nbsp;<input type='submit' value='$Forum::lang->{'sort_submit'}' class='forminput'></td>
     </tr>
  </table>
  </td>
  </tr>
  </table>

  </form>

      <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
      <tr>
         <td valign='middle' width='33%' nowrap align='left'>$Data->{'SHOW_PAGES'}</td>
         <td valign='middle' width='34%' align='center'>[ <a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION&act=Cookies&f=$iB::IN{f}">$Forum::lang->{'mark_as_read'}</a> ]</td>
         <td valign='middle' width='33%' nowrap align='right'><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Post;CODE=00;f=$Data->{'FORUM_ID'}">$iB::SKIN->{'A_POST'}</a>&nbsp;$Data->{'POLL_BUTTON'}</td>
      </tr>
     </table>

   <script language='javascript'>
   <!--
    function jumpMenu(targ,selObj,restore){
        eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
        if (restore) selObj.selectedIndex=0;
    }
    //-->
    </script>

   <br>

   <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
      <tr>
         <td valign='middle' align='right'>$Data->{'FORUM_JUMP'}</td>
      </tr>
   </table>

   <br>

   <table cellpadding='0' cellspacing='4' border='0' width='50%' align='center'>
     <tr>
        <td valign='middle' nowrap>$iB::SKIN->{'B_NEW'}&nbsp;$Forum::lang->{'pm_open_new'}</td>
        <td valign='middle' nowrap>$iB::SKIN->{'B_HOT'}&nbsp;$Forum::lang->{'pm_hot_new'}</td>
        <td valign='middle' nowrap>$iB::SKIN->{'B_POLL'}&nbsp;$Forum::lang->{'pm_poll'}</td>
        <td valign='middle' nowrap>$iB::SKIN->{'B_LOCKED'}&nbsp;$Forum::lang->{'pm_locked'}</td>
     </tr>
     <tr>
        <td valign='middle' nowrap>$iB::SKIN->{'B_NORM'}&nbsp;$Forum::lang->{'pm_open_no'}</td>
        <td valign='middle' nowrap>$iB::SKIN->{'B_HOT_NN'}&nbsp;$Forum::lang->{'pm_hot_no'}</td>
        <td valign='middle' nowrap>$iB::SKIN->{'B_POLL_NN'}&nbsp;$Forum::lang->{'pm_poll_no'}</td>
        <td valign='middle' nowrap>$iB::SKIN->{'B_MOVED'}&nbsp;$Forum::lang->{'pm_moved'}</td>
      </tr>
   </table>
        
~;

   }




sub Forum_log_in {
my $Data = shift;

return qq~

     <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=SF&f=$Data" method="post">
     <input type='hidden' name='act' value='SF'>
     <input type='hidden' name='f' value='$Data'>
     <input type='hidden' name='L' value='1'>
     <input type='hidden' name='s' value='$iB::SESSION'>
     <table cellpadding='0' cellspacing='1' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='4' cellspacing='0' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='left' colspan='2' id='titlelarge'>$Forum::lang->{'need_password'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'>$Forum::lang->{'need_password_txt'}</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='40%'><b>$Forum::lang->{'enter_pass'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='password' size='20' name='f_password'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='center' colspan='2'><input type="submit" value="$Forum::lang->{'f_pass_submit'}"></td>
                </tr>
                </table>
            </td>
       </tr>
    </table>
    </form>

~;
}





# ====== Do not touch anything below this line ====== #

1;
