package OnlineWords;


sub new {
  my $pkg = shift;
  my $obj = {
   
#+----------------------------------------------------------------------
#| Do Not remove or edit anything above this line!
#| Only Edit the words on the right of the => arrow
#+----------------------------------------------------------------------

### Added RC 1

pages => "Pages:",

WHERE_SC      => "Viewing Category:",
WHERE_SF      => "Viewing Forum:",
WHERE_ST      => "Viewing a topic in:",
WHERE_SR      => "Viewing Forum Rules:",
WHERE_Post    => "Posting in forum:",
WHERE_Profile => "Viewing Profile:",
WHERE_Invite  => "Inviting a friend to the board",
WHERE_Members => "Viewing the members list",
WHERE_Help    => "Viewing the help files",
WHERE_Search  => "Searching",

board_index     => "Viewing Board index",
page_title      => "Online Users",

member_name     => "Member Name",
where           => "Location",
time            => "Time",
user_ops        => "Options",
guest           => "Guest",
n_a             => "[ N/A ]",












#+----------------------------------------------------------------------
#| Do Not remove or edit anything below this line!
#+----------------------------------------------------------------------
  };

  bless $obj, $pkg;
  return $obj;
}




1;

__END__
