package SearchWords;


sub new {
  my $pkg = shift;
  my $obj = {
   
#+----------------------------------------------------------------------
#| Do Not remove or edit anything above this line!
#| Only Edit the words on the right of the => arrow
#+----------------------------------------------------------------------

and => "and",

pm_open_new => "Open Topic (new replies)",
pm_hot_new  => "Hot Topic (new replies)",
pm_poll     => "Poll (new votes)",
pm_locked   => "Locked Topic",
pm_open_no  => "Open Topic (no new replies)",
pm_hot_no   => "Hot Topic (no new replies)",
pm_poll_no  => "Poll (no new votes)",
pm_moved    => "Moved Topic",


f_topic  => "Topic Title",
f_forum  => "Forum",
f_topic_s => "Topic Starter",
f_replies  => "Replies",
f_views    => "Views",
f_last     => "Last Post",

search_string => "You last searched on <#DATE#> when you searched for <#TYPE#> during a <#IN#> search for '<#WORDS#>'. This search returned <#MATCHES#> unique matches.",
search_str_ahref => "View these results again?",

search_completed => "Search completed, taking you to your search results",
search_results   => "Your Search Results",
search_form      => "Search Form",
search_title     =>  "Search",
search_help      =>  "Search Help",
enter_search_words => "Enter the Search Keywords",
keywords_txt       => "<br>You may use 'AND', 'OR' to define your query.<br>You may also use * as a wildcard character (Example: foo* matches foo and foobar)",
search_keywords    => "Search Keywords",
type_search        => "Type of Search",
membername         => "Member name",
post               => "Posts and or topic titles",
choose_forums      => "Choose the forum(s) to search in",
js_def           => "Please choose from the options below",
forums           => "Forums",
select_txt       => "<b>Windows Users:</b>Hold down [CTRL] to select multiple forums<br><b>Macintosh Users:</b>Hold down [SHIFT] or [APPLE] to select multiple forums",
refine_search    => "Refine the Search",
search_in        => "Search in...",
topic            => "Topic Titles",
posts            => "Posts",
both             => "Topic Titles and Posts",
search_from      => "Search From",

today  => "Today",
this_week => "This week",
this_month => "This Month",
this_year => "This year",
ever      => "The beginning",

older => "Older",
newer => "Newer",
do_search  => "Search!",

js_searching_posts => "Searching posts made",

js_warn_1    => "This is only a title, you cannot search using this option",
js_search_in_all => "Searching in all forums",
js_forum     => "Forum chosen, you may choose more than one",
js_words_s   => "Keywords to search by:",
js_order     => "Order chosen",


ll_name      => "member names",
ll_post      => "posts",
ll_new       => "new posts",
ll_titles    => "topic titles",
ll_Posts     => "post",
ll_all       => "topic title and post",

#+----------------------------------------------------------------------
#| Do Not remove or edit anything below this line!
#+----------------------------------------------------------------------
  };

  bless $obj, $pkg;
  return $obj;
}




1;

__END__
