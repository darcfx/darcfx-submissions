package CalendarView;
use strict;

sub head {

return qq~
<table cellspacing=0 cellpadding=0 width='$iB::SKIN->{'TABLE_WIDTH'}' align=center bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' border=0>
  <tbody> 
  <tr> 
    <td valign='top'> 
      <table width='100%' border='0' cellspacing='1' cellpadding='1'>
        <tr> 
          <td bgcolor="$iB::SKIN->{'TITLEBACK'}" id=titlemedium colspan='7'> &nbsp; $Calendar::lang->{'page_titles'}</td>
        </tr>
        <tr>  
          <td id=category bgcolor='$iB::SKIN->{'CAT_BACK'}' width='14%'> 
            <div align='center'>$Calendar::lang->{'mon'}</div>
          </td>
          <td id=category bgcolor='$iB::SKIN->{'CAT_BACK'}' width='14%'> 
            <div align='center'>$Calendar::lang->{'tue'}</div>
          </td>
          <td id=category bgcolor='$iB::SKIN->{'CAT_BACK'}' width='14%'> 
            <div align='center'>$Calendar::lang->{'wed'}</div>
          </td>
          <td id=category bgcolor='$iB::SKIN->{'CAT_BACK'}' width='14%'> 
            <div align='center'>$Calendar::lang->{'thu'}</div>
          </td>
          <td id=category bgcolor='$iB::SKIN->{'CAT_BACK'}' width='14%'> 
            <div align='center'>$Calendar::lang->{'fri'}</div>
          </td>
          <td id=category bgcolor='$iB::SKIN->{'CAT_BACK'}' width='14%'> 
            <div align='center'>$Calendar::lang->{'sat'}</div>
          </td>
          <td id=category bgcolor='$iB::SKIN->{'CAT_BACK'}' width='14%'> 
            <div align='center'>$Calendar::lang->{'sun'}</div>
          </td>
        </tr>
~;

}

sub bottom {

my $select_m = shift;
my $select_y = shift;
my $next_m = shift;
my $next_y = shift;
my $prev_m = shift;
my $prev_y = shift;

return qq~
      <tr>
        <td bgcolor="$iB::SKIN->{'TITLEBACK'}" colspan='7' id='titlemedium'>
        <table border='0' cellpadding='2' cellspacing='0' width='100%'>
          <form method='post' action='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Calendar;CODE=1'>
          <input type='hidden' name='s' value='$iB::SESSION'>
          <input type='hidden' name='CODE' value='1'>
          <input type='hidden' name='act' value='Calendar'>
          <tr>
            <td width='50%'><select name='m' size='1' class='forminput'>$select_m            </select>
            <select name='y' size='1' class='forminput'>$select_y            </select> 
            <input type='submit' value='$Calendar::lang->{'show'}' class='forminput'>
            </td>
            <td id='category' width='50%' align='right'><small><b>&lt;</b><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Calendar;CODE=1;m=$prev_m;y=$prev_y' title='$Calendar::lang->{'prev'}'> $UserCP::lang->{"month$prev_m"} $prev_y</a> | <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Calendar;CODE=1;m=$next_m;y=$next_y' title='$Calendar::lang->{'next'}'>$UserCP::lang->{"month$next_m"} $next_y</a> <b>&gt;</b></small></td>
          </tr>
        </table>
        </td>
      </tr>
    </table>
    </td>
  </tr>
</tbody>
</table>
~;

}




# ====== Do not touch anything below this line ====== #

1;
