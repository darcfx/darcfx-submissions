package MailView;
use strict;


sub show_address {
my $data = shift;

return qq~

     <table cellpadding='0' cellspacing='1' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='4' cellspacing='0' border='0' width='100%'>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2' id='usermenu'><img src='$iB::INFO->{'IMAGES_URL'}/images/cp_redtri.gif' border='0' height='15' width='15' align='middle' alt=''>&nbsp;<b>$MailMember::lang->{'send_email_to'} $data->{'NAME'}</b><hr noshade size='1' color='#000000'></td>
                 </tr>
                <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><img src='$iB::INFO->{'IMAGES_URL'}/images/cp_guy.gif' border='0' height='50' width='50' alt=''></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$MailMember::lang->{'show_address_text'}</td>
                 </tr>
                    <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>&nbsp;</td>
                    <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>&gt;&gt;<b><a href="mailto:$data->{'ADDRESS'}" class='misc'>$MailMember::lang->{'send_email_to'} $data->{'NAME'}</a></b></td>
                 </tr>
               </table>
            </td>
         </tr>
      </table>
~;

}


sub send_form    {
my $data = shift;

return qq~

     <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION" method="post" name='REPLIER'>
     <input type='hidden' name='act' value='Mail'>
     <input type='hidden' name='CODE' value='01'>
     <input type='hidden' name='s' value='$iB::SESSION'>
     <input type='hidden' name='to' value='$data->{'TO'}'>
     <table cellpadding='0' cellspacing='1' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
               <table cellpadding='4' cellspacing='1' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='left' colspan='2' id='titlelarge'>$MailMember::lang->{'send_title'}</td>
                </tr>
                <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2' id='usermenu'><b>$MailMember::lang->{'send_email_to'} $data->{'NAME'}</b></td>
                 </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'  width='20%' valign='top'><b>$MailMember::lang->{'subject'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='80%'><input type='text' name='subject' value='' size='50' maxlength='50' class='forminput'>
                </td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='left'  width='20%' valign='top'><b>$MailMember::lang->{'message'}</b><br><br>$MailMember::lang->{'msg_txt'}</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' width='80%'><textarea cols='60' rows='12' wrap='soft' name='message' class='textinput'></textarea>
                </td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='center' colspan='2'>
                <input type="submit" value="$MailMember::lang->{'submit_send'}" class='forminput'>
                </tr>
               </table>
            </td>
         </tr>
      </table>
      </form>

~;
}


sub sent_screen {
my ($member_name) = @_;

#+------------------------------------------------------------------------------------------------------------
return qq~
     <table cellpadding='0' cellspacing='1' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
               <table cellpadding='4' cellspacing='0' border='0' width='100%'>
                <tr>
                   <td bgcolor='$iB::SKIN->{'TITLEBACK'}' colspan='2' id='titlelarge'><b>$MailMember::lang->{'email_sent'}</b></td>                
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2' id='usermenu'><img src='$iB::INFO->{'IMAGES_URL'}/images/cp_redtri.gif' border='0' height='15' width='15' align='middle' alt=''>&nbsp;<b>$MailMember::lang->{'email_sent'}</b></td>
                 </tr>
                 </tr>
                 <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='middle'><img src='$iB::INFO->{'IMAGES_URL'}/images/msg_sent.gif' border='0' height='32' width='32' alt=''></td>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='middle'><b>$MailMember::lang->{'email_sent_txt'} $member_name</td>
                 </tr>
                </table>
            </td>
         </tr>
      </table>


~; # >> END OF HTML - DO NOT EDIT THIS LINE!
#+------------------------------------------------------------------------------------------------------------
}




# ====== Do not touch anything below this line ====== #

1;
