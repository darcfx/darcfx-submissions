package LoginWords;


sub new {
  my $pkg = shift;
  my $obj = {
   
#+----------------------------------------------------------------------
#| Do Not remove or edit anything above this line!
#| Only Edit the words on the right of the => arrow
#+----------------------------------------------------------------------

force_login          => "The board administrator requires that all members log in before viewing the board",
errors_found         => "The following errors were found:",
wrong_name           => "Sorry, we could not find a member called <#NAME#>, are you sure it's correct?",
wrong_pass           => "Sorry, the password was wrong. All passwords are case sensitive",
thanks_for_login     => "You are now logged in!",
please_log_in        => "Please enter your details below to log in",
log_out              => "Log Out",
log_in               => "Log In",
thanks_for_logout    => "You are now logged out",
admin_force_log_in   => "The board administrator requires all members to log in",
sess_interupt        => "Your session has been interupted, please log back in",

not_registered       => "Not Registered? ",
reg_link             => "Register Now!",
forgot_pass          => "Forgotton your password and/or log in details?",
pass_link            => "Click here!",

enter_name           => "Please enter your name",
enter_pass           => "Please enter your password",
options              => "Options",
cookies              => "<b>Remember my log in details?</b><br>If enabled, you will be automatically logged in again when you visit",
cookie_yes           => "Yes",
cookie_no            => "No",

privacy              => "<b>Privacy</b>, do you want to appear on the active users list?",
add_name             => "Yes, add my name to the active users list",
anon_name            => "Don't add me to the active users list",

log_in_submit        => "Log me in",

log_out_txt          => "Logging out will remove you from the active users list (if you are not anonymous). It will also remove any cookies set by this board, so you will have to log back in on your next visit",
log_out_submit       => "Log me out",

blank_fields         => "Please enter your name and password before continuing",



#+----------------------------------------------------------------------
#| Do Not remove or edit anything below this line!
#+----------------------------------------------------------------------
  };

  bless $obj, $pkg;
  return $obj;
}




1;

__END__
