package RegisterWords;


sub new {
  my $pkg = shift;
  my $obj = {
   
#+----------------------------------------------------------------------
#| Do Not remove or edit anything above this line!
#| Only Edit the words on the right of the => arrow
#+----------------------------------------------------------------------


## added to RC2

nav_reg  => "Registration",
title_reg => "Registration",

reg_success => "Registration Successful",

done_reg_1  => "Your account has been activated! Proceeding to the board rules",
done_reg_2 =>  "Your account has been activated! Proceeding to log in",

preview_reg_text => "Your registration has been successful. The administrator wishes to preview all new registered accounts before posting permissions are granted. The administrator has been notified of your registration.",


## added to RC1

intro_proceed => "Proceed to log in",


##

reg_header              => "Registration Instructions",
std_text                => "Please ensure that you complete all the fields fully, taking particular care over the password fields.",
email_validate_text     => "You will be sent an email to the email address you give after registering. Please read the email carefully, you will need to validate your account by clicking on a link in the email.",
user_validate_text      => "The board administrator wishes to preview all accounts before allowing you to register fully. Register now then please wait until you receive an email from the board administrator before attempting to log in.",
registration_form       => "Registration Form",
registration_agree      => "Registration Agreement",

#+--------------------------------------------
# /* Form Stuff */

complete_form           => "Please complete the form fully",
user_name               => "<b>Please choose a Username</b><br>Usernames must be between 3 and 32 characters long",
pass_word               => "<b>Please choose a Password</b><br>Passwords must be between 3 and 32 characters long",
re_enter_pass           => "<b>Please re-enter your password</b><br>It must match <i>exactly</i>",
email_address           => "<b>Please enter your email address</b><br>You will need to enter a <i>real</i> email address",
submit_form             => "Submit my registration",

#+--------------------------------------------
# /* Board Rules */

board_rules             => "Board Rules",

#+--------------------------------------------
# /* Agreement Form */

terms_service           => "<b>Terms of Service</b><br>Please read fully and check the 'I agree' box ONLY if you agree to the terms",
agree_submit            => "I agree",

#+--------------------------------------------
# /* Authorisation */

registration_process    => "Registration Process",
thank_you               => "Thank you",
auth_text               => "Your registration has been submitted.<br><br>The board administrator has chosen to require validation for all email addresses. Within the next 10 minutes (usually instantly) you'll receive an email with instructions on the next step. Don't worry, it won't take long before you can post!<br><br>The email has been sent to",

js_no_check             => "You cannot register unless you agree to the terms and check the 'I agree' checkbox",
js_blanks               => "You must complete all of the form",

#+--------------------------------------------
# /* Dumb Form */

dumb_text              => "Please ensure that you complete the form fully. The information you need will be in the email that was sent to you.",
dumb_name              => "Please enter the name you registered with",
dumb_email             => "Please enter the Email Address you registered with",
dumb_code              => "Please enter the unique code",
dumb_submit            => "Complete the registration process",
dumb_header            => "Registration",

#+----------------------------------------------------------------------
#| Do Not remove or edit anything below this line!
#+----------------------------------------------------------------------
  };

  bless $obj, $pkg;
  return $obj;
}




1;

__END__
