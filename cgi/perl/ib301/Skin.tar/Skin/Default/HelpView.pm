package HelpView;
use strict;


sub start {
my ($one_text, $two_text, $three_text) = @_;

return qq~
     <table cellpadding=4 cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' align='center'>
      <tr><td>$two_text</td></tr>
     </table>

     <table cellpadding=0 cellspacing='1' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
      <tr>
        <td>
          <table cellpadding='4' cellspacing='1' border='0' width='100%'>
          <tr>
          <td bgcolor='$iB::SKIN->{'TITLEBACK'}' align='left' colspan='2' id='titlemedium'>$one_text</td>
          </tr>
          <tr>
              <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'>
               <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Help;s=$iB::SESSION;CODE=02" method="post">
               <input type='hidden' name='act' value='Help'>
               <input type='hidden' name='CODE' value='02'>
               <input type='hidden' name='s' value='$iB::SESSION'>
               $Help::lang->{'search_txt'}&nbsp;&nbsp;<input type='text' maxlength='60' size='30' class='forminput' name='search_q'>&nbsp;<input type='submit' value='$Help::lang->{'submit'}' class='forminput'>
              </form>
             </td>
           </tr>
           </table>
          </td>
         </tr>
      </table>
      <br>
     <table cellpadding=0 cellspacing='1' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
      <tr>
        <td>
          <table cellpadding='4' cellspacing='1' border='0' width='100%'>
           <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2' id='titlemedium'><b>$three_text</b></td>
           </tr>
 
~;
}


sub display {
my $text = shift;

return qq~

          <!-- Displaying Help Topic -->
          <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2' id='postcolor'>$text</td>
          </tr>
          <!-- End Display -->

~;
}




sub row {
my $entry = shift;

return qq~

          <!-- Help Entry ID:$entry->{'ID'} -->
          <tr>
            <td bgcolor='$entry->{cell_colour}' align='center' width='10%'>$iB::SKIN->{'C_ON'}</td>
            <td bgcolor='$entry->{cell_colour}' style='height:28px'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?act=Help;s=$iB::SESSION;CODE=01;HID=$entry->{'ID'}'>$entry->{'TITLE'}</a></td>
          </tr>
          <!-- End Help Entry -->

~;
}

sub no_results {

return qq~

                <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'><b>$Help::lang->{'no_results'}</b></td>
                 </tr>
~;
}




sub end {

return qq~
          </table>
          </td>
          </tr>
          </table>
        ~;
}













# ====== Do not touch anything below this line ====== #

1;

__END__
