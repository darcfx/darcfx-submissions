package PagerView;
use strict;


sub aol_body {
my $data = shift;

return qq~

<!-- Begin AIM Remote -->
<table width='140' align='center'>
<tr align='right'><td><a href="http://www.aol.co.uk/aim/index.html"><img src="http://www.aol.co.uk/aim/remote/gr/aimver_man.gif" width=44 height=55 border=0 alt="Download AIM"></a><img src="http://www.aol.co.uk/aim/remote/gr/aimver_topsm.gif" width=73 height=55 border=0 alt="AIM Remote"><br><a href="aim:goim?screenname=$data->{'AOLNAME'}&message=Hi.+Are+you+there?"><img src="http://www.aol.co.uk/aim/remote/gr/aimver_im.gif" width=117 height=39 border=0 alt="Send me an Instant Message"></a><br><a href="aim:addbuddy?screenname=$data->{'AOLNAME'}"><img src="http://www.aol.co.uk/aim/remote/gr/aimver_bud.gif" width=117 height=39 border=0 alt="Add me to Your Buddy List"></a><br><a href="http://www.aol.co.uk/aim/remote.html"><img src="http://www.aol.co.uk/aim/remote/gr/aimver_botadd.gif" width=117 height=23 border=0 alt="Add Remote to Your Page"></a><br><a href="http://www.aol.co.uk/aim/index.html"><img src="http://www.aol.co.uk/aim/remote/gr/aimver_botdow.gif" width=117 height=29 border=0 alt="Download AOL Instant Messenger"></a><br><br></td></tr></table>
<!-- End AIM Remote -->
~;
}
	


sub pager_header {
my $data = shift;

return qq~
       <table cellpadding='0' cellspacing='0' border='0' width='100%' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
              <table cellpadding='4' cellspacing='0' border='0' width='100%'>
                <tr>
                   <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' colspan='2' align='center' id='titlemedium'>$data->{'TITLE'}</td>
                
~;

}


sub icq_body {
my $data = shift;

return qq~
              <form action="http://msg.mirabilis.com/scripts/WWPMsg.dll" METHOD="POST" name="frmPager">
			      <INPUT TYPE="hidden" NAME="subject" VALUE="From WebPager Panel">
              <input type="hidden" name="to" value="$data->{'UIN'}">
              <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left'><b>$Pager::lang->{'name'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left'><input type='text' name='from' value='$iB::MEMBER->{'MEMBER_NAME'}' size='40' class='forminput' onMouseOver="this.focus()" onFocus="this.select()"></td>
              </tr>
              <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left'><b>$Pager::lang->{'email'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left'><input type='text' name='fromemail' value='$iB::MEMBER->{'MEMBER_EMAIL'}' size='40' class='forminput' onMouseOver="this.focus()" onFocus="this.select()"></td>
              </tr>
              <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left' valign='top'><b>$Pager::lang->{'msg'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='left'><textarea wrap='virtual' cols='50' rows='12' wrap='soft' name='body' class='textinput' onMouseOver="this.focus()" onFocus="this.select()"></textarea></td>
              </tr>
              <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='center' colspan='2'><input type='submit' value='$Pager::lang->{'submit'}' class='forminput'></td>
              </tr>
              </form>
~;
        

}



sub end_table {

return qq~

            <!-- End content Table -->
            </table>
            </td>
            </tr>
            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_TITLE'}' colspan='2'>&nbsp;</td>
            </tr>
            </table>
        ~;
}



# ====== Do not touch anything below this line ====== #

1;
