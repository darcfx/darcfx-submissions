package BoardsView;



sub PageTop {
    my $Data = shift;

return qq~
      <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
          <td>
            <table cellpadding='4' cellspacing='1' border='0' width='100%'>
            <tr>
              <td bgcolor="$iB::SKIN->{'TITLEBACK'}" width='5%' id="titlemedium">&nbsp;</td>
              <td bgcolor="$iB::SKIN->{'TITLEBACK'}" width='50%' id="titlemedium">$Boards::lang->{'cat_name'}</td>
              <td bgcolor="$iB::SKIN->{'TITLEBACK'}" width='1%' align='center' id="titlemedium">$Boards::lang->{'topics'}</td>
              <td bgcolor="$iB::SKIN->{'TITLEBACK'}" width='1%' align='center' id="titlemedium">$Boards::lang->{'replies'}</td>
              <td bgcolor="$iB::SKIN->{'TITLEBACK'}" width='15%' align='center' id="titlemedium">$Boards::lang->{'last_post_info'}</td>
            </tr>
~;
}

sub CatHeader_Expanded {
    my $Data = shift;

   return qq~<tr>
             <td bgcolor="$iB::SKIN->{'CAT_BACK'}" colspan='5' id='category'>
               <table cellspacing='0' cellpadding='0' align='center' width='100%'>
                <tr>
                  <td align='left'  id='category'><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=SC;c=$Data->{'CAT_ID'}">$Data->{'CAT_NAME'}</a></td>
                  <td align='right' id='category'>$Data->{'CAT_SPONSOR'}</td>
                </tr>
               </table>
             </td>
            </tr>
~;

}



sub CatHeader_Collapsed {
    my $Data = shift;

return qq~
    <!-- Category $Data->{'CAT_ID'} entry -->
    <tr>
        <td bgcolor="$iB::SKIN->{'EXP_CAT_TWO'}" align="center" width="5%">$Data->{'NEW_POST_IMG'}</td>
        <td bgcolor="$iB::SKIN->{'EXP_CAT_TWO'}" align="left" width='45%'><span id='linkthru'><b><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=SC;c=$Data->{'CAT_ID'}">$Data->{'CAT_NAME'}</a></b></span><br>$Data->{'CAT_DESC'}<br>$Boards::lang->{'total_forums'} $Data->{'TOTAL_FORUMS'}</td>
        <td bgcolor="$iB::SKIN->{'EXP_CAT_ONE'}" align='center' valign='middle' width='10%'>$Data->{'TOPICS'}</td>
        <td bgcolor="$iB::SKIN->{'EXP_CAT_ONE'}" align='center' valign='middle' width='10%' id='highlight'>$Data->{'POSTS'}</td>
        <td bgcolor="$iB::SKIN->{'EXP_CAT_ONE'}" align="left" valign='middle' width='35%'><span id='highlight'>$Data->{'LAST_POST'}</span><br>$Boards::lang->{'in'}: $Data->{'N_LINK'}<br>$Boards::lang->{'by'}: $Data->{'P_LINK'}</td>
    </tr>
    <!-- Category $Data->{'CAT_ID'} entry -->
    
~;

}





sub ForumRow {
    my $Data = shift;

return qq~
    <!-- Forum $Data->{'FORUM_ID'} entry -->
    <tr>
        <td bgcolor="$iB::SKIN->{'FORUM_COL_TWO'}" align="center" width="5%">$Data->{'NEW_POST_IMG'}</td>
        <td bgcolor="$iB::SKIN->{'FORUM_COL_TWO'}" align="left" width='45%'><span id="linkthru"><b><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=SF;f=$Data->{'FORUM_ID'}">$Data->{'FORUM_NAME'}</a></b></span><br>$Data->{'FORUM_DESC'}<span id='highlight'><br>$Data->{'MODERATOR'}</span><br>$Boards::lang->{'forum_users'} : $Data->{'FORUM_USERS'}</td>
        <td bgcolor="$iB::SKIN->{'FORUM_COL_ONE'}" align='center' valign='middle' width='10%'>$Data->{'FORUM_TOPICS'}</td>
        <td bgcolor="$iB::SKIN->{'FORUM_COL_ONE'}" align='center' valign='middle' width='10%' id='highlight'>$Data->{'FORUM_POSTS'}</td>
        <td bgcolor="$iB::SKIN->{'FORUM_COL_ONE'}" align="left" valign='middle' width='35%'><span id='highlight'>$Data->{'FORUM_LAST_POST'}</span><br>$Boards::lang->{'in'}: $Data->{'N_LINK'}<br>$Boards::lang->{'by'}: $Data->{'P_LINK'}</td>
    </tr>
    <!-- End of Forum $Data->{'FORUM_ID'} entry -->
~;

}



sub ActiveUsers {
    my ($names, $link, $members, $guests, $anon, $total) = @_;

   
return qq~

    <!-- Cgi-bot Active Users -->
    <tr>
        <td bgcolor="$iB::SKIN->{'CAT_BACK'}" colspan='5' id='category'>$total $Boards::lang->{'active_users'}</td>
    </tr>
    <tr>
        <td bgcolor="$iB::SKIN->{'FORUM_COL_TWO'}" width="100%" colspan='5'>
           <table cellspacing="4" cellpadding="1" border="0" width='100%'>
            <tr>
                <td width="5%">$iB::SKIN->{'F_ACTIVE'}</td>
                <td bgcolor="$iB::SKIN->{'FORUM_COL_TWO'}"  width='95%'><b>$guests</b> $Boards::lang->{'guests'}, <b>$members</b> $Boards::lang->{'public_members'} <b>$anon</b> $Boards::lang->{'anon_members'} $link<br>$names<!--BIRTHDAY HTML--></td>
            </tr>
           </table>
        </td>
    </tr>
    <!-- Cgi-bot End of Active Users -->
    
    
~;

}


sub birthday {
    my ($birthusers, $total, $birth_lang) = @_;
    
    return qq~<hr noshade size="1"><b>$total</b> $birth_lang&nbsp;&nbsp;&nbsp;[ <a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Calendar;CODE=1'>$Boards::lang->{'calendar'}</a> ]<br>$birthusers~;
}



sub ShowStats {
   my $Stats = shift;
   my $total = $Stats->{'TOTAL_TOPICS'} + $Stats->{'TOTAL_REPLIES'};
   
return qq~

    <!-- Cgi-bot Board Stats -->
    <tr>
        <td bgcolor="$iB::SKIN->{'CAT_BACK'}" colspan='5' id='category'>$Boards::lang->{'board_stats'}</td>
    </tr>
    <tr>
        <td bgcolor="$iB::SKIN->{'FORUM_COL_TWO'}" width="100%" colspan='5'>
          <table cellspacing='4' cellpadding="1" border="0" width='100%'>
            <tr>
                <td width='5%' valign='middle' rowspan='3'>$iB::SKIN->{'F_STATS'}</td>
                <td bgcolor="$iB::SKIN->{'FORUM_COL_TWO'}" width="95%" align='left'>$iB::INFO->{'BOARDNAME'} $Boards::lang->{'newest_member'} <span id='highlight'>$Stats->{'LAST_REG_MEMBER_N'}</span> $Boards::lang->{'making_total'} <span id='highlight'>$Stats->{'TOTAL_MEMBERS'}</span> $Boards::lang->{'registered_mems'}.</td>
            </tr>
            <tr>
               <td bgcolor="$iB::SKIN->{'FORUM_COL_TWO'}" width="95%" align='left'>$iB::INFO->{'BOARDNAME'} $Boards::lang->{'total_of'} <span id='highlight'><b>$total</b> $Boards::lang->{'posts'} ($Stats->{'TOTAL_REPLIES'} $Boards::lang->{'replies_to'} $Stats->{'TOTAL_TOPICS'} $Boards::lang->{'topics'})</span></td>
            </tr>
            <tr>
               <td bgcolor="$iB::SKIN->{'FORUM_COL_TWO'}" width="95%" align='left'>$Boards::lang->{'most_online'}</td>
            </tr>
          </table>
        </td>
    </tr>
    <!-- Cgi-bot End of Board Stats -->
    
    
~;
}


sub Invite_Friend {
   
return qq~

    <!-- Cgi-bot Invite Friend -->
    <tr>
        <td bgcolor="$iB::SKIN->{'CAT_BACK'}" colspan='5' id='category'>$Boards::lang->{'invite_friend'}</td>
    </tr>
    <tr>
        <td bgcolor='$iB::SKIN->{'FORUM_COL_TWO'}' width='100%' colspan='5'>

        <script language="javascript">
        <!--
        function DoDisplay(element) {

            MyName  = "$iB::MEMBER->{'MEMBER_NAME'}";
            MyEmail = "$iB::MEMBER->{'MEMBER_EMAIL'}";

            if (MyEmail == "") {
                MyEmail = "you\@domain.com";
            }

            if (element == "NAME") {
                document.REPLIER.SenderName.value = MyName;
                return true;
            }
            if (element == "EMAIL") {
                document.REPLIER.SendersEmail.value = MyEmail;
                return true;
            }

        }
        //-->
        </script>

            <table cellspacing='4' cellpadding='1' border='0' width='100%'>
            <tr>
                <td width='5%' valign='middle' rowspan='2'>$iB::SKIN->{'F_INVITE'}</td>
                <td bgcolor="$iB::SKIN->{'FORUM_COL_TWO'}" width="95%" align='left' colspan='4'>$Boards::lang->{'invite_txt_a'} $iB::INFO->{'BOARDNAME'}$Boards::lang->{'complete_form'}</td>
            </tr>
            <tr>
               <form name='REPLIER' method='post' action='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}'>
               <input type='hidden' name='act' value='Invite'>
               <td bgcolor="$iB::SKIN->{'FORUM_COL_TWO'}" width="30%" align='left' valign='middle'>
               <input type='text' name='SenderName' size='20' maxlength='80' value='$Boards::lang->{'your_name'}' class='forminput' onMouseOver="this.focus()" onFocus="DoDisplay('NAME')">
               </td>
               <td bgcolor="$iB::SKIN->{'FORUM_COL_TWO'}" width="32%" align='left' valign='middle'>
               <input type='text' name='SendersEmail' size='25' maxlength='80' value='$Boards::lang->{'email_addy_from'}' class='forminput' onMouseOver="this.focus()" onFocus="DoDisplay('EMAIL')">
               </td>
               <td bgcolor="$iB::SKIN->{'FORUM_COL_TWO'}" width="32%" align='left' valign='middle'>
               <input type='text' name='RecipientEmail' size='25' maxlength='80' value='$Boards::lang->{'email_addy_to'}' class='forminput' onMouseOver="this.focus()" onFocus="this.select()">
               </td>
               <td bgcolor="$iB::SKIN->{'FORUM_COL_TWO'}" width="5%" align='left' valign='middle'>
               <input type='submit' name='submit' value='$Boards::lang->{'invite_submit'}' class='forminput'>
               </td>
               </form>
            </tr>
            </table>
        </td>
    </tr>
    <!-- Cgi-bot End Invite Friend -->
    
    
~;
}





sub BoardInformation {

return qq~

<!-- Cgi-bot Script page footer -->
   </table>
   </td>
   </tr>
   </table>

   <br><br>
   <table cellspacing='0' cellpadding='0' align='center' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}'>
   <tr>
     <td>
       <table cellspacing='2' cellpadding='0' width='50%' border='0' align='center'>
          <tr>
            <td valign='middle' align='left'>$iB::SKIN->{'C_ON'}</td>
            <td valign='middle' align='left'>$Boards::lang->{'new_posts'}</td>
            <td valign='middle' align='left'>$iB::SKIN->{'C_OFF'}</td>
            <td valign='middle' align='left'>$Boards::lang->{'no_new'}</td>
            <td valign='middle' align='left'>$iB::SKIN->{'C_LOCKED'}</td>
            <td valign='middle' align='left'>$Boards::lang->{'forum_off'}</td>
          </tr>
       </table>
      </td>
     </tr>
   </table>
   <br>
   <table cellspacing='4' cellpadding='0' width='70%' border='0' align='center'>
      <tr>
       <td align='center'>[ <a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Cookies">$Boards::lang->{'d_delete_cookies'}</a> ] :: [ <a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=PMarkers;MID=$iB::MEMBER->{'MEMBER_ID'}">$Boards::lang->{'d_post_read'}</a> ]</td>
    </tr>
   </table>
<!-- Cgi-bot End of script page footer -->
        
~;
}










# ====== Do not touch anything below this line ====== #

1;
