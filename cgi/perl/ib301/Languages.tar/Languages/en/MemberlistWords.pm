package MemberlistWords;


sub new {
  my $pkg = shift;
  my $obj = {
   
#+----------------------------------------------------------------------
#| Do Not remove or edit anything above this line!
#| Only Edit the words on the right of the => arrow
#+----------------------------------------------------------------------

sort_by_name        => "Member Name",
sort_by_posts       => "Total Posts",
sort_by_joined      => "Join Date",
sort_by_level       => "Member Level",
descending_order    => "Descending Order",
ascending_order     => "Ascending Order",

show_all            => "All Members",
show_staff          => "Board Staff",
show_admin          => "Administrators",

member_name         => "Name",
member_email        => "Email",
member_aol          => "AOL",
member_icq          => "ICQ",
member_level        => "Level",
member_group        => "Group",
member_posts        => "Posts",
member_joined       => "Joined",

multi_pages         => "Multiple Pages",
page_title          => "Member List",

sorting_text        => "Showing <#FILTER#> by <#SORT_KEY#> in <#SORT_ORDER#> with <#MAX_RESULTS#> results per page",

sort_submit         => "Go!",


#+----------------------------------------------------------------------
#| Do Not remove or edit anything below this line!
#+----------------------------------------------------------------------
  };

  bless $obj, $pkg;
  return $obj;
}




1;

__END__
