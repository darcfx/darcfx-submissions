package MailFunctionsWords;


sub new {
  my $pkg = shift;
  my $obj = {
   
#+----------------------------------------------------------------------
#| Do Not remove or edit anything above this line!
#| Only Edit the words on the right of the => arrow
#+----------------------------------------------------------------------

invite_subject      => qq|An Invitation|,
invite_redirect     => qq|The email has been sent to  |,
subs_redirect       => qq|You have subscribed to this topic|,

invite_subject      => "<#MEMBER_NAME#> thought you would like to see this",

sub_added           => "Your subscription has been added",





#+----------------------------------------------------------------------
#| Do Not remove or edit anything below this line!
#+----------------------------------------------------------------------
  };

  bless $obj, $pkg;
  return $obj;
}




1;

__END__
