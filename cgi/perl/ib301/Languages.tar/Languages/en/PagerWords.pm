package PagerWords;


sub new {
  my $pkg = shift;
  my $obj = {
   
#+----------------------------------------------------------------------
#| Do Not remove or edit anything above this line!
#| Only Edit the words on the right of the => arrow
#+----------------------------------------------------------------------

icq_title     => "ICQ Pager",
name          => "Your Name",
email         => "Your Email",
msg           => "Enter your message",
submit        => "Send this message",

aol_title     => "AOL Pager",









#+----------------------------------------------------------------------
#| Do Not remove or edit anything below this line!
#+----------------------------------------------------------------------
  };

  bless $obj, $pkg;
  return $obj;
}




1;

__END__
