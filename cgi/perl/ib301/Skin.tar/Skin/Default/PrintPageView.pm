package PrintPageView;
use strict;
#+-----------------------------------------------------------------+
#| Ikonboard v3 by Jarvis Entertainment Group, Inc.
#|
#| No parts of this script can be used outside Ikonboard without prior consent.
#|
#| More information available from <ib-license@jarvisgroup.net>
#| (c)2001 Jarvis Entertainment Group, Inc.
#| 
#| http://www.ikonboard.com
#|
#| Please Read the license for more information
#+-----------------------------------------------------------------+

# This is the HTML module for the Print Page Function
#
# You may edit any of the HTML between the tidles (~).
# Do not edit the names of any strings ($).




sub pp_header {
my ($forum_name, $topic_title, $topic_starter) = @_;
#-------->> PRINT PAGE HEADER     (You may edit the HTML below 'return qq~')
return qq~

    <html>
    <head>
    <title>$iB::INFO->{'BOARDNAME'} [Powered by Ikonboard]</title>
    </head>
    <body bgcolor='#FFFFFF' alink='#000000' vlink='#000000' link='#000000'>
    <table width='90%' border='0' align='center'>
    <tr>
    <td>
    <font face='arial' size='3' color='#000000'>
    <b>$Print::lang->{'title'}</b>
    <br><br>
    -$iB::INFO->{'BOARDNAME'}<br>
    +--$Print::lang->{'forum'}: $forum_name<br>
    +---$Print::lang->{'topic'}: $topic_title $Print::lang->{'start'} $topic_starter
    <hr noshade size='1' color='#000000'>
    <br>
    <br>

~;
}  #----->> END OF ROUTINE, do not edit this line


#+-----------------------------------------------------------------------


sub pp_postentry {
my ($poster, $entry) = @_;
#-------->> PRINT PAGE POST ENTRY     (You may edit the HTML below 'return qq~')
return  qq~

        <b>$Print::lang->{'by'}: $poster->{'MEMBER_NAME'}</b> $Print::lang->{'on'} $entry->{'POST_DATE'}
        <br><br>
        $entry->{'POST'}
        <hr>

~;
}  #----->> END OF ROUTINE, do not edit this line




sub pp_end {
#-------->> PRINT PAGE END     (You may edit the HTML below 'return qq~')
return qq~

    <i>$Print::lang->{'end'}</i>
    </td>
    </tr>
    </table>

~;
}  #----->> END OF ROUTINE, do not edit this line





#--- END OF MODULE, NOTHING EDITABLE BELOW THIS LINE
1;
