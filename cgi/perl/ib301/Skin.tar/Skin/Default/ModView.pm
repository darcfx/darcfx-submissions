package ModView;
use strict;



sub delete_js {

return qq~
          <script language='JavaScript'>
          <!--
          function ValidateForm() {
             document.REPLIER.submit.disabled = true;
             return true;
          }
          //-->
          </script>
          ~;
}



sub table_top {
my $posting_title = shift;

return qq~
  
 
     <table cellpadding='0' cellspacing='0' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
        <tr>
            <td>
                <table cellpadding='5' cellspacing='1' border='0' width='100%'>
                <tr>
                <td bgcolor='$iB::SKIN->{'TITLEBACK'}' valign='left' colspan='2' id='titlelarge'>$posting_title</td>
                </tr>

~;
}


sub mod_exp {
my $words = shift;

return qq~


                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'>$words</td>
                </tr>

~;
}

sub topictitle_fields {
my ($title, $desc) = @_;

return qq~

                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><font class='misc'><b>$Moderate::lang->{'edit_f_title'}</b></font></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' size='40' maxlength='50' name='TopicTitle' value='$title'></td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><font class='misc'><b>$Moderate::lang->{'edit_f_desc'}</b></font></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' size='40' maxlength='40' name='TopicDesc' value='$desc'></td>
                </tr>

~;
}

sub move_form {
my ($html, $forum_name) = @_;

return qq~

                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$Moderate::lang->{'move_from'} <b>$forum_name</b> $Moderate::lang->{'to'}:</td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$html</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><b>$Moderate::lang->{'delete_old'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>
                  <select name='leave' class='forminput'>
                  <option value='leave_full'  selected>$Moderate::lang->{'leave_locked'}
                  <option value='leave_empty'>$Moderate::lang->{'leave_empty'}
                  <option value='delete'>$Moderate::lang->{'dont_leave'}
                  </select>
                </td>
                </tr>

~;

}




sub end_form {
my $action = shift;


return qq~

                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' align='center' colspan='2'>
                <input type="submit" name="submit" value="$action" class='forminput'>
                </td></tr></table>
                </td></tr></table>
                </form>

~;


}









1;