package ModCPView;



sub startcp {


return qq~
     <script langauge="javascript">
     <!--
        function check_prune() {
            var message = "$ModCP::lang->{'prune_confirm'} "+document.theForm.DAYS.value+"\\n$ModCP::lang->{'prune_confirm_b'}";
            if ( confirm( message ) ) {
                document.theForm.submit();
            } else {
                return false;
            }
        }
        function PopUp(url, name, width,height,center,resize,scroll,posleft,postop) {
            if (posleft != 0) { x = posleft }
            if (postop  != 0) { y = postop  }
        
            if (!scroll) { scroll = 1 }
            if (!resize) { resize = 1 }
        
            if ((parseInt (navigator.appVersion) >= 4 ) && (center)) {
              X = (screen.width  - width ) / 2;
              Y = (screen.height - height) / 2;
            }
            if (scroll != 0) { scroll = 1 }
        
            var Win = window.open( url, name, 'width='+width+',height='+height+',top='+Y+',left='+X+',resizable='+resize+',scrollbars='+scroll+',location=no,directories=no,status=no,menubar=no,toolbar=no');
        }
     //-->
     </script>
     <table cellpadding='0' cellspacing='1' border='0' width='$iB::SKIN->{'TABLE_WIDTH'}' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}' align='center'>
      <tr>
        <td width='20%' bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='top'>
          <table cellspacing='0' cellpadding='4' border='0' width='100%' align='center'>
            <tr>
             <td bgcolor='$iB::SKIN->{'TITLEBACK'}' valign='left' id='titlelarge'>$ModCP::lang->{'menu'}</td>
            </tr>
          <!--menu goes here-->
          </table>
        </td>
        <td width='80%' bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='top'>
          <table cellspacing='0' cellpadding='4' border='0' width='100%' align='center'>
            <tr>
             <td bgcolor='$iB::SKIN->{'TITLEBACK'}' valign='left' id='titlelarge'>$ModCP::lang->{'display'}</td>
            </tr>
          <!--main content-->

~;


}


sub show_topic_results {
    my $data = shift;

return qq~
            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>
                <b>$ModCP::lang->{'a_post_results'}</b><hr noshade size=1 color='$iB::SKIN->{'TABLE_BORDER_COL'}'>
                $ModCP::lang->{'a_post_deleted'} $data->{'DELETED'}<br><br>
                $ModCP::lang->{'a_post_approved'} $data->{'APPROVED'}<br><br>
                $ModCP::lang->{'a_post_left'} $data->{'LEFT'}<br><br>
            </td>
            </tr>

~;
}


sub show_open_results {
    my $data = shift;

return qq~
            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>
                <b>$ModCP::lang->{'a_topic_results'}</b><hr noshade size=1 color='$iB::SKIN->{'TABLE_BORDER_COL'}'>
                $ModCP::lang->{'a_topic_open'} $data->{'open'}<br><br>
                $ModCP::lang->{'a_topic_close'} $data->{'closed'}<br><br>
            </td>
            </tr>

~;
}

sub show_delete_results {
    my $data = shift;

return qq~
            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>
                <b>$ModCP::lang->{'a_topic_results'}</b><hr noshade size=1 color='$iB::SKIN->{'TABLE_BORDER_COL'}'>
                $ModCP::lang->{'a_topic_d_delete'} $data->{'delete'}<br><br>
            </td>
            </tr>

~;
}

sub show_post_results {
    my $data = shift;

return qq~
            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>
                <b>$ModCP::lang->{'a_topic_results'}</b><hr noshade size=1 color='$iB::SKIN->{'TABLE_BORDER_COL'}'>
                $ModCP::lang->{'a_topic_deleted'} $data->{'DELETED'}<br><br>
                $ModCP::lang->{'a_topic_approved'} $data->{'APPROVED'}<br><br>
                $ModCP::lang->{'a_topic_left'} $data->{'LEFT'}<br><br>
            </td>
            </tr>

~;
}

sub show_move_results {
    my $data = shift;

return qq~
            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>
                <b>$ModCP::lang->{'a_topic_results'}</b><hr noshade size=1 color='$iB::SKIN->{'TABLE_BORDER_COL'}'>
                $ModCP::lang->{'a_topic_d_left'} $data->{'leave'}<br><br>
                $ModCP::lang->{'a_topic_moved'} $data->{'move'}<br><br>
            </td>
            </tr>

~;
}

sub search_header {
    my $data = shift;

return qq~
            <tr>
             <td><b>$ModCP::lang->{'f_moderate'} $data->{'FORUM_NAME'}</b><br>$ModCP::lang->{'f_moderate_t'}
               <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='theForm'>
               <input type='hidden' name='act' value='ModCP'>
               <input type='hidden' name='CODE' value='$data->{'search_type'}'>
               <input type='hidden' name='s' value='$iB::SESSION'>
               <input type='hidden' name='f' value='$iB::IN{'f'}'>
            </td>
            </tr>
            <tr>
              <td>
               <table cellspacing='1' cellpadding='0' border='0' width='95%' align='center' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}'>
                 <tr>
                  <td>
                    <table cellspacing='1' cellpadding='4' border='0' width='100%' align='center'>
                     <tr>
                       <td width='15%' bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium'>$ModCP::lang->{'tt_action'}</td>
                       <td width='85%' bgcolor='$iB::SKIN->{'TITLEBACK'}'  id='titlemedium'>$ModCP::lang->{'tt_details'}</td>
                     </tr>
~;
}


sub topic_header {
    my $data = shift;

return qq~
            <tr>
             <td><b>$ModCP::lang->{'f_moderate'} $data->{'FORUM_NAME'}</b><br>$ModCP::lang->{'f_moderate_t'}
               <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='theForm'>
               <input type='hidden' name='act' value='ModCP'>
               <input type='hidden' name='CODE' value='$data->{'search_type'}'>
               <input type='hidden' name='s' value='$iB::SESSION'>
               <input type='hidden' name='f' value='$iB::IN{'f'}'>
            </td>
            </tr>
            <tr>
              <td>
               <table cellspacing='1' cellpadding='0' border='0' width='95%' align='center' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}'>
                 <tr>
                  <td>
                    <table cellspacing='1' cellpadding='4' border='0' width='100%' align='center'>
                     <tr>
                       <td width='15%' bgcolor='$iB::SKIN->{'TITLEBACK'}'  id='titlemedium'>$ModCP::lang->{'tt_action'}</td>
                       <td width='45%' bgcolor='$iB::SKIN->{'TITLEBACK'}'  id='titlemedium'>$ModCP::lang->{'st_topic'}</td>
                       <td width='5%'  bgcolor='$iB::SKIN->{'TITLEBACK'}'  id='titlemedium'>$ModCP::lang->{'st_posts'}</td>
                       <td width='35%' bgcolor='$iB::SKIN->{'TITLEBACK'}'  id='titlemedium'>$ModCP::lang->{'st_last'}</td>
                     </tr>
~;
}


sub render_opentopic {
    my $data = shift;

return qq~
                 <tr>
                  <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='middle'>$data->{'SELECT'}</td>
                  <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><span id="linkthru"><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ST;f=$data->{'FORUM_ID'};t=$data->{'TOPIC_ID'}" target='_blank'>$data->{'TOPIC_TITLE'}</a></span><br>$data->{'TOPIC_DESC'}</td>
                  <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' align='center' valign='middle'>$data->{'TOPIC_POSTS'}</td>
                  <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><span id='highlight'>$data->{'TOPIC_LAST_DATE'}</span><br>$ModCP::lang->{'st_by'} $data->{'LAST_POSTER'}</td>
                 </tr>
~;
}

sub topic_footer {
return qq~
        <tr>
          <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='4' align='center'><input type='submit' value='$ModCP::lang->{'process_records'}' class='forminput'></td>
        </tr> 
       </table>
      </td>
     </tr>
    </table>
~;
}

sub render_topic_title {
    my $data = shift;

return qq~
                    <tr>
                      <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2'>$ModCP::lang->{'ss_topic_title'} <b>$data->{'TOPIC_TITLE'}</b></td>
                    </tr>
~;
}


sub render_topic_post {
    my $data = shift;
return qq~
                     <tr>
                      <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='middle'><input type='hidden' name='POST_$data->{'POST'}->{'ID'}' value='$data->{'POST'}->{'POST_ID'}'><input type='hidden' name='TOPIC_$data->{'POST'}->{'ID'}' value='$data->{'TOPIC'}->{'TOPIC_ID'}'><select name='CHOICE_$data->{'POST'}->{'ID'}' class='forminput'><option value='APPROVE' selected>$ModCP::lang->{'c_approve'}</option>$data->{'TOPIC'}->{'DELETE'}<option value='LEAVE' selected>$ModCP::lang->{'c_leave'}</option></select></td>
                      <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='top'>
                        <table cellspacing='1' cellpadding='4' border='0' width='100%' align='center'>
                        <tr>
                          <td valign='top' width='15%'>$data->{'POST'}->{'MEMBER_NAME'}</td>
                          <td valign='top' width='85%'><b>$ModCP::lang->{'ss_posted_on'}</b> $data->{'POST'}->{'POST_DATE'}<hr noshade size=1 color='$iB::SKIN->{'TABLE_BORDER_COL'}'>$data->{'POST'}->{'POST'} ( <a href="javascript:PopUp('$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION&act=ModCP&f=$iB::IN{'f'}&CODE=readpost&ID=$data->{'POST'}->{'ID'}','ViewPost','400','200','0','1','1','1')">$ModCP::lang->{'ss_read_more'}</a> )</td>
                        </tr>
                        </table>
                      </td>
                    </tr>
~;
}




sub render_newtopic {
    my $data = shift;

return qq~
                    <tr>
                      <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2'>$ModCP::lang->{'ss_topic_title'} <b>$data->{'TOPIC'}->{'TOPIC_TITLE'}</b></td>
                    </tr>
                      <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='middle'><input type='hidden' name='R_POST_$data->{'TOPIC'}->{'TOPIC_ID'}' value='$data->{'POST'}->{'POST_ID'}'><input type='hidden' name='POST_$data->{'TOPIC'}->{'TOPIC_ID'}' value='$data->{'POST'}->{'ID'}'><select name='CHOICE_$data->{'TOPIC'}->{'TOPIC_ID'}' class='forminput'><option value='APPROVE' selected>$ModCP::lang->{'c_approve'}</option>$data->{'TOPIC'}->{'DELETE'}<option value='LEAVE' selected>$ModCP::lang->{'c_leave'}</option></select></td>
                      <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' valign='top'>
                        <table cellspacing='1' cellpadding='4' border='0' width='100%' align='center'>
                        <tr>
                          <td valign='top' width='15%'><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=Profile;CODE=03;MID=$data->{'TOPIC'}->{'TOPIC_STARTER'}" target='_blank'><b>$data->{'TOPIC'}->{'TOPIC_STARTER_N'}</b></a></td>
                          <td valign='top' width='85%'><b>$ModCP::lang->{'ss_posted_on'}</b> $data->{'TOPIC'}->{'TOPIC_START_DATE'}<hr noshade size=1 color='$iB::SKIN->{'TABLE_BORDER_COL'}'>$data->{'POST'}->{'POST'} ( <a href="javascript:PopUp('$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION&act=ModCP&f=$iB::IN{'f'}&CODE=readpost&ID=$data->{'POST'}->{'ID'}','ViewPost','400','200','0','1','1','1')">$ModCP::lang->{'ss_read_more'}</a> )</td>
                        </tr>
                        </table>
                      </td>
                    </tr>
~;
}


sub search_footer {
return qq~
        <tr>
          <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2' align='center'><input type='submit' value='$ModCP::lang->{'process_records'}' class='forminput'></td>
        </tr> 
       </table>
      </td>
     </tr>
    </table>
~;
}


sub endcp {

return qq~
      </td>
     </tr>
    </table>
   </td>
  </tr>
 </table>
~;



}



sub offline_menu {

return qq~
    <tr>
     <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><b>$ModCP::lang->{'menu_off'}</b></td>
    </tr>
~;

}

sub online_menu {

return qq~
    <tr>
     <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' id='controlpanel'>$ModCP::lang->{'m_moderate'}</td>
    </tr>
    <tr>
     <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModCP;f=$iB::IN{'f'}'>$ModCP::lang->{'m_approve'}</a></td>
    </tr>
    <tr>
     <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModCP;f=$iB::IN{'f'};CODE=prune'>$ModCP::lang->{'m_prune'}</a></td>
    </tr>
    <tr>
     <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModCP;f=$iB::IN{'f'};CODE=delete'>$ModCP::lang->{'m_delete'}</a></td>
    </tr>
    <tr>
     <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModCP;f=$iB::IN{'f'};CODE=open'>$ModCP::lang->{'m_open'}</a></td>
    </tr>
    <tr>
     <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModCP;f=$iB::IN{'f'};CODE=move'>$ModCP::lang->{'m_move'}</a></td>
    </tr>
    <!-- To be added later
    <tr>
     <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' id='controlpanel'>$ModCP::lang->{'m_prefs'}</td>
    </tr>
    <tr>
     <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><a href='$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModCP;CODE=eprefs;f=$iB::IN{'f'}'>$ModCP::lang->{'m_email'}</a></td>
    </tr>
    -->
~;

}


sub main_splash {

return qq~
            <tr>
             <td><b>$ModCP::lang->{'mod_forum_t'}</b><br>$ModCP::lang->{'mod_forum'}</td>
            </tr>
            <tr>
              <td>
               <table cellspacing='1' cellpadding='0' border='0' width='95%' align='center' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}'>
                 <tr>
                  <td>
                    <table cellspacing='1' cellpadding='4' border='0' width='100%' align='center'>
                     <tr>
                       <td width='54%' bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium'>$ModCP::lang->{'forum_name'}</td>
                       <td width='6%' bgcolor='$iB::SKIN->{'TITLEBACK'}'  id='titlemedium'>$ModCP::lang->{'forum_topics'}</td>
                       <td width='5%' bgcolor='$iB::SKIN->{'TITLEBACK'}'  id='titlemedium'>$ModCP::lang->{'forum_posts'}</td>
                       <td width='35%' bgcolor='$iB::SKIN->{'TITLEBACK'}'  id='titlemedium'>$ModCP::lang->{'last_post'}</td>
                     </tr>
~;

}

sub end_main_splash {

return qq~
       </table>
      </td>
     </tr>
    </table>
~;
}




sub render_cat {
my $data = shift;

return qq~
     <tr>
       <td bgcolor="$iB::SKIN->{'CAT_BACK'}" id='category' colspan='4'>$data->{'CAT_NAME'}</td>
     </tr>
~;


}


sub render_forum {
my $data = shift;

return qq~
     <tr>
       <td bgcolor="$iB::SKIN->{'FORUM_COL_TWO'}"><span id="linkthru"><b><a href="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}?s=$iB::SESSION;act=ModCP;f=$data->{'FORUM_ID'}">$data->{'FORUM_NAME'}</a></b></span><br>$ModCP::lang->{'topic_to_mod'}&nbsp;<b>$data->{'TOPICS_NOT_APPROVED'}</b></td>
        <td bgcolor="$iB::SKIN->{'FORUM_COL_ONE'}" align='center' valign='middle'>$data->{'FORUM_TOPICS'}</td>
        <td bgcolor="$iB::SKIN->{'FORUM_COL_ONE'}" align='center' valign='middle' id='highlight'>$data->{'FORUM_POSTS'}</td>
        <td bgcolor="$iB::SKIN->{'FORUM_COL_ONE'}" align="left" valign='middle'><span id='highlight'>$data->{'FORUM_LAST_POST'}</span>
     </tr>
~;

}


sub forum_splash {
my $data = shift;

return qq~
            <tr>
             <td><b>$ModCP::lang->{'f_moderate'} $data->{'FORUM_NAME'}</b><br>$ModCP::lang->{'f_moderate_t'}</td>
            </tr>
            <tr>
              <td>
               <table cellspacing='1' cellpadding='0' border='0' width='95%' align='center' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}'>
                 <tr>
                  <td>
                    <table cellspacing='1' cellpadding='4' border='0' width='100%' align='center'>
~;

}

sub end_forum_splash {
return qq~
       </table>
      </td>
     </tr>
    </table>
~;
}


sub topic_form_header {
my $count = shift;

return qq~
            <tr>
             <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' colspan='2'>$ModCP::lang->{'q_topics'} $count</td>
            </tr>
         ~;

}

sub open_form_header {

return qq~
            <tr>
             <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' colspan='2'>$ModCP::lang->{'search_openclose'} $count</td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'>
               <i>$ModCP::lang->{'define_search'}</i>
               <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='theForm'>
               <input type='hidden' name='act' value='ModCP'>
               <input type='hidden' name='CODE' value='process_open'>
               <input type='hidden' name='s' value='$iB::SESSION'>
               <input type='hidden' name='f' value='$iB::IN{'f'}'>
            </td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_topics_cutoff'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' name='DAYS' size='5' maxlength='10' class='forminput'></td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_sort'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><select name='ORDER' class='forminput'><option value='asc'>$ModCP::lang->{'s_topics_asc'}</option><option value='desc' selected>$ModCP::lang->{'s_topics_desc'}</option></select></td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_limit'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' name='LIMIT' size='5' maxlength='10' class='forminput'></td>
            </tr>
            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2' align='center'><input type='submit' class='forminput' value='$ModCP::lang->{'submit_topics'}'></form></td>
            </tr>
         ~;
}

sub move_ops {
my ($html, $forum_name) = @_;
return qq~
                <tr>
                  <td><table cellspacing='0' cellpadding='4' border='0' width='100%' align='center'>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'move_topics_from'} <b>$forum_name</b> $Moderate::lang->{'to'}:
               <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='theForm'>
               <input type='hidden' name='act' value='ModCP'>
               <input type='hidden' name='CODE' value='do_move'>
               <input type='hidden' name='s' value='$iB::SESSION'>
               <input type='hidden' name='f' value='$iB::IN{'f'}'>
                </td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$html</td>
                </tr>
                <tr>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><b>$Moderate::lang->{'delete_old'}</b></td>
                <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>
                  <select name='leave' class='forminput'>
                  <option value='leave_full'  selected>$Moderate::lang->{'leave_locked'}
                  <option value='leave_empty'>$Moderate::lang->{'leave_empty'}
                  <option value='delete'>$Moderate::lang->{'dont_leave'}
                  </select>
                </td>
                </tr>
                </table>
                </td>
                </tr>
~;
}

sub move_form_header {

return qq~
            <tr>
             <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' colspan='2'>$ModCP::lang->{'search_move'}</td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'>
               <i>$ModCP::lang->{'define_search'}</i>
               <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='theForm'>
               <input type='hidden' name='act' value='ModCP'>
               <input type='hidden' name='CODE' value='process_move'>
               <input type='hidden' name='s' value='$iB::SESSION'>
               <input type='hidden' name='f' value='$iB::IN{'f'}'>
            </td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_topics_cutoff'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' name='DAYS' size='5' maxlength='10' class='forminput'></td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_sort'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><select name='ORDER' class='forminput'><option value='asc'>$ModCP::lang->{'s_topics_asc'}</option><option value='desc' selected>$ModCP::lang->{'s_topics_desc'}</option></select></td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_limit'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' name='LIMIT' size='5' maxlength='10' class='forminput'></td>
            </tr>
            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2' align='center'><input type='submit' class='forminput' value='$ModCP::lang->{'submit_topics'}'></form></td>
            </tr>
         ~;
}

sub prune_form_header {

return qq~
            <tr>
             <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' colspan='2'>$ModCP::lang->{'search_prune'}</td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'>
               <i>$ModCP::lang->{'define_search'}</i>
               <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='theForm'>
               <input type='hidden' name='act' value='ModCP'>
               <input type='hidden' name='CODE' value='process_prune'>
               <input type='hidden' name='s' value='$iB::SESSION'>
               <input type='hidden' name='f' value='$iB::IN{'f'}'>
            </td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_prune_cutoff'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' name='DAYS' size='5' maxlength='10' class='forminput'></td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_prune_perpage'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' name='PAGE' size='5' maxlength='10' value='20' class='forminput'></td>
            </tr>
            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2' align='center'><input type='button' class='forminput' value='$ModCP::lang->{'prune_forum'}' onClick='check_prune();'></form></td>
            </tr>
         ~;
}



sub delete_form_header {

return qq~
            <tr>
             <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' colspan='2'>$ModCP::lang->{'search_delete'} $count</td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'>
               <i>$ModCP::lang->{'define_search'}</i>
               <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='theForm'>
               <input type='hidden' name='act' value='ModCP'>
               <input type='hidden' name='CODE' value='process_delete'>
               <input type='hidden' name='s' value='$iB::SESSION'>
               <input type='hidden' name='f' value='$iB::IN{'f'}'>
            </td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_topics_cutoff'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' name='DAYS' size='5' maxlength='10' class='forminput'></td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_sort'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><select name='ORDER' class='forminput'><option value='asc'>$ModCP::lang->{'s_topics_asc'}</option><option value='desc' selected>$ModCP::lang->{'s_topics_desc'}</option></select></td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_limit'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' name='LIMIT' size='5' maxlength='10' class='forminput'></td>
            </tr>
            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2' align='center'><input type='submit' class='forminput' value='$ModCP::lang->{'submit_topics'}'></form></td>
            </tr>
         ~;
}


sub topic_form {
return qq~
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'>
               <i>$ModCP::lang->{'define_search'}</i>
               <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='theForm'>
               <input type='hidden' name='act' value='ModCP'>
               <input type='hidden' name='CODE' value='topic_search'>
               <input type='hidden' name='s' value='$iB::SESSION'>
               <input type='hidden' name='f' value='$iB::IN{'f'}'>
            </td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_topics_cutoff'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' name='DAYS' size='5' maxlength='10' class='forminput'></td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_sort'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><select name='ORDER' class='forminput'><option value='asc'>$ModCP::lang->{'s_topics_asc'}</option><option value='desc' selected>$ModCP::lang->{'s_topics_desc'}</option></select></td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_limit'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' name='LIMIT' size='5' maxlength='10' class='forminput'></td>
            </tr>
            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2' align='center'><input type='submit' name='TOPICS' class='forminput' value='$ModCP::lang->{'submit_topics'}'></form></td>
            </tr>
         ~;
}





sub topic_none {
return qq~
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'><i>$ModCP::lang->{'q_t_n'}</i></td>
            </tr>
         ~;
}

sub post_form_header {
my $count = shift;

return qq~
            <tr>
             <td bgcolor='$iB::SKIN->{'TITLEBACK'}' id='titlemedium' colspan='2'>$ModCP::lang->{'q_posts'} $count</td>
            </tr>
         ~;
}

sub post_form {
return qq~
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'>
               <i>$ModCP::lang->{'define_search'}</i>
               <form action="$iB::INFO->{'BOARD_URL'}/ikonboard.$iB::INFO->{'CGI_EXT'}" method="post" name='theForm'>
               <input type='hidden' name='act' value='ModCP'>
               <input type='hidden' name='CODE' value='post_search'>
               <input type='hidden' name='s' value='$iB::SESSION'>
               <input type='hidden' name='f' value='$iB::IN{'f'}'>
            </td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_posts_cutoff'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' name='DAYS' size='5' maxlength='10' class='forminput'></td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_sort'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><select name='ORDER' class='forminput'><option value='asc'>$ModCP::lang->{'s_topics_asc'}</option><option value='desc' selected>$ModCP::lang->{'s_topics_desc'}</option></select></td>
            </tr>
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$ModCP::lang->{'s_limit'}</td>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'><input type='text' name='LIMIT' size='5' maxlength='10' class='forminput'></td>
            </tr>
            <tr>
            <td bgcolor='$iB::SKIN->{'MISCBACK_TWO'}' colspan='2' align='center'><input type='submit' name='POSTS' value='$ModCP::lang->{'submit_posts'}' class='forminput'></form></td>
            </tr>
         ~;
}

sub post_none {
return qq~
            <tr>
             <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}' colspan='2'><i>$ModCP::lang->{'q_p_n'}</i></td>
            </tr>
         ~;
}



sub read_post {
    my $data = shift;
return qq~
               <table cellspacing='1' cellpadding='0' border='0' width='100%' align='center' bgcolor='$iB::SKIN->{'TABLE_BORDER_COL'}'>
                 <tr>
                  <td>
                    <table cellspacing='1' cellpadding='4' border='0' width='100%' align='center'>
                     <tr>
                        <td bgcolor='$iB::SKIN->{'MISCBACK_ONE'}'>$data->{'POST'}</td>
                     </tr>
                    </table>
                   </td>
                 </tr>
                </table>
~;
}



1;